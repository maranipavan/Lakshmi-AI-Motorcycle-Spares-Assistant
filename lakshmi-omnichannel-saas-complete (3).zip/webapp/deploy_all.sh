#!/usr/bin/env bash
set -euo pipefail

echo "🚀 Deploying 100% Rust Omnichannel SaaS & Storefront to VPS..."

echo "📦 Uploading Rust workspace (telegram_sync & lakshmi_search) and SQL migrations..."
scp -r telegram_sync lakshmi_search migrations ubuntu@spare:~/webapp/

echo "🌐 Uploading frontend assets (index.html, admin.html, saas_dashboard.html, css, js)..."
scp frontend/index.html frontend/admin.html frontend/saas_dashboard.html frontend/privacy.html frontend/placeholder.svg frontend/sw.js ubuntu@spare:~/webapp/frontend/
scp -r frontend/css frontend/js ubuntu@spare:~/webapp/frontend/

echo "🦀 Building optimized Rust release binaries on VPS (saas_server, tg_bot, chat_ws, telegram_sync)..."
ssh ubuntu@spare "cd ~/webapp/telegram_sync && cargo build --release --bins"

echo "🔄 Restarting Rust systemd services..."
ssh ubuntu@spare "sudo cp ~/webapp/lakshmi.service /etc/systemd/system/lakshmi.service && sudo systemctl daemon-reload && sudo systemctl restart lakshmi && sleep 2 && sudo systemctl status lakshmi --no-pager | head -20"

echo "✅ Rust deployment complete!"
