-- ============================================================
-- Lakshmi Motorcycle Spares — Full Production Schema
-- Run this in Supabase SQL Editor on the new project
-- ============================================================

-- Enable UUID extension (Supabase has this by default, but just in case)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";


-- ============================================================
-- 1. spare_parts
-- ============================================================
CREATE TABLE IF NOT EXISTS spare_parts (
    id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    part_name       text        NOT NULL,
    bike_brand      text        NOT NULL,
    bike_model      text        NOT NULL,
    part_category   text,
    price           numeric(10,2) NOT NULL DEFAULT 0,
    stock_qty       integer     NOT NULL DEFAULT 0,
    description     text,
    color           text,
    year_from       integer,
    year_to         integer,
    image_url       text,           -- raw Telegram / original URL (internal only)
    web_image_url   text,           -- CDN / public URL served to frontend
    is_active       boolean     NOT NULL DEFAULT true,
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now()
);

-- Indexes for the hot query paths
CREATE INDEX IF NOT EXISTS idx_spare_parts_brand       ON spare_parts (bike_brand);
CREATE INDEX IF NOT EXISTS idx_spare_parts_model       ON spare_parts (bike_model);
CREATE INDEX IF NOT EXISTS idx_spare_parts_category    ON spare_parts (part_category);
CREATE INDEX IF NOT EXISTS idx_spare_parts_is_active   ON spare_parts (is_active);
CREATE INDEX IF NOT EXISTS idx_spare_parts_brand_model ON spare_parts (bike_brand, bike_model);
CREATE INDEX IF NOT EXISTS idx_spare_parts_stock       ON spare_parts (stock_qty);

-- Full-text search index (used by search_parts)
CREATE INDEX IF NOT EXISTS idx_spare_parts_fts ON spare_parts
    USING gin(to_tsvector('english',
        coalesce(part_name,'') || ' ' ||
        coalesce(bike_brand,'') || ' ' ||
        coalesce(bike_model,'') || ' ' ||
        coalesce(part_category,'') || ' ' ||
        coalesce(description,'')
    ));

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_spare_parts_updated_at
    BEFORE UPDATE ON spare_parts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================
-- 2. orders
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
    id               bigserial   PRIMARY KEY,
    order_id         text        NOT NULL UNIQUE,   -- e.g. 20032026-W-ODR1
    order_token      text        NOT NULL,
    user_id          bigint      NOT NULL DEFAULT 0,
    full_name        text        NOT NULL,
    phone            text        NOT NULL,
    email            text        DEFAULT '',
    address          text,
    delivery_address text,
    items            jsonb       NOT NULL DEFAULT '[]',
    subtotal         numeric(10,2) NOT NULL DEFAULT 0,
    delivery_charge  numeric(10,2) NOT NULL DEFAULT 50,
    total_amount     numeric(10,2) NOT NULL DEFAULT 0,
    status           text        NOT NULL DEFAULT 'Pending',
    payment_method   text        NOT NULL DEFAULT 'cod',
    payment_status   text        NOT NULL DEFAULT 'pending',
    payment_id       text,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_order_id    ON orders (order_id);
CREATE INDEX IF NOT EXISTS idx_orders_phone       ON orders (phone);
CREATE INDEX IF NOT EXISTS idx_orders_status      ON orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at  ON orders (created_at DESC);

CREATE TRIGGER trg_orders_updated_at
    BEFORE UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================
-- 3. chat_messages
-- ============================================================
CREATE TABLE IF NOT EXISTS chat_messages (
    id          bigserial   PRIMARY KEY,
    session_id  text        NOT NULL,
    sender      text        NOT NULL,   -- 'customer' | 'bot' | 'support'
    message     text        NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chat_session    ON chat_messages (session_id);
CREATE INDEX IF NOT EXISTS idx_chat_created_at ON chat_messages (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_chat_tg_session ON chat_messages (session_id)
    WHERE session_id LIKE 'tg_%';


-- ============================================================
-- 4. bot_training
-- ============================================================
CREATE TABLE IF NOT EXISTS bot_training (
    key        text        PRIMARY KEY,
    value      text        NOT NULL,
    kind       text        NOT NULL,    -- 'spelling' | 'learned'
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bot_training_kind ON bot_training (kind);

CREATE TRIGGER trg_bot_training_updated_at
    BEFORE UPDATE ON bot_training
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================
-- 5. service_bookings
-- ============================================================
CREATE TABLE IF NOT EXISTS service_bookings (
    id                   bigserial   PRIMARY KEY,
    booking_ref          text        NOT NULL UNIQUE,   -- SVC-YYYYMMDD-XXXX
    date                 date        NOT NULL,
    time_slot            text        NOT NULL,
    customer_name        text        NOT NULL,
    phone                text        NOT NULL,
    bike_make            text        NOT NULL,
    bike_model           text        NOT NULL,
    telegram_contact     text        NOT NULL,
    customer_notes       text,
    status               text        NOT NULL DEFAULT 'pending',
    -- 'pending' | 'confirmed' | 'completed' | 'cancelled'
    razorpay_order_id    text,
    razorpay_payment_id  text,
    amount               integer     NOT NULL DEFAULT 50000,  -- paise
    confirmed_at         timestamptz,
    completed_at         timestamptz,
    cancelled_at         timestamptz,
    review_requested_at  timestamptz,
    review_pending       text,       -- PENDING_TEXT:{chat_id}:{booking_ref}
    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now()
);

-- Partial unique index: only one confirmed booking per slot per date
CREATE UNIQUE INDEX IF NOT EXISTS idx_service_bookings_slot_unique
    ON service_bookings (date, time_slot)
    WHERE status = 'confirmed';

CREATE INDEX IF NOT EXISTS idx_service_bookings_phone      ON service_bookings (phone);
CREATE INDEX IF NOT EXISTS idx_service_bookings_status     ON service_bookings (status);
CREATE INDEX IF NOT EXISTS idx_service_bookings_date       ON service_bookings (date);
CREATE INDEX IF NOT EXISTS idx_service_bookings_review_pnd ON service_bookings (review_pending)
    WHERE review_pending IS NOT NULL;

CREATE TRIGGER trg_service_bookings_updated_at
    BEFORE UPDATE ON service_bookings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================
-- 6. service_reminders
-- ============================================================
CREATE TABLE IF NOT EXISTS service_reminders (
    id            bigserial   PRIMARY KEY,
    booking_ref   text        NOT NULL REFERENCES service_bookings(booking_ref) ON DELETE CASCADE,
    reminder_type text        NOT NULL,   -- 'day_before' | 'periodic'
    next_due_date date        NOT NULL,
    is_active     boolean     NOT NULL DEFAULT true,
    last_sent_at  timestamptz,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reminders_booking_ref  ON service_reminders (booking_ref);
CREATE INDEX IF NOT EXISTS idx_reminders_due_active   ON service_reminders (next_due_date, is_active);
CREATE INDEX IF NOT EXISTS idx_reminders_type         ON service_reminders (reminder_type);

CREATE TRIGGER trg_service_reminders_updated_at
    BEFORE UPDATE ON service_reminders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================
-- 7. service_reviews
-- ============================================================
CREATE TABLE IF NOT EXISTS service_reviews (
    id            bigserial   PRIMARY KEY,
    booking_ref   text        NOT NULL UNIQUE REFERENCES service_bookings(booking_ref) ON DELETE CASCADE,
    rating        integer     NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_text   text,
    photo_url     text,
    customer_name text,
    bike_make     text,
    bike_model    text,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reviews_rating     ON service_reviews (rating);
CREATE INDEX IF NOT EXISTS idx_reviews_created_at ON service_reviews (created_at DESC);

CREATE TRIGGER trg_service_reviews_updated_at
    BEFORE UPDATE ON service_reviews
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================
-- 8. service_job_parts  (used by admin job card feature)
-- ============================================================
CREATE TABLE IF NOT EXISTS service_job_parts (
    id          bigserial   PRIMARY KEY,
    booking_ref text        NOT NULL REFERENCES service_bookings(booking_ref) ON DELETE CASCADE,
    part_name   text        NOT NULL,
    quantity    integer     NOT NULL DEFAULT 1,
    unit_price  numeric(10,2) NOT NULL DEFAULT 0,
    total_price numeric(10,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_job_parts_booking_ref ON service_job_parts (booking_ref);


-- ============================================================
-- Row Level Security (RLS)
-- Enable RLS on all tables and allow anon key full access
-- (same as Supabase default for new projects — tighten later)
-- ============================================================
ALTER TABLE spare_parts        ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders             ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages      ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_training       ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_bookings   ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_reminders  ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_reviews    ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_job_parts  ENABLE ROW LEVEL SECURITY;

-- Allow anon + service_role full access (backend uses anon key)
CREATE POLICY "anon_all_spare_parts"      ON spare_parts        FOR ALL TO anon, service_role USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_orders"           ON orders             FOR ALL TO anon, service_role USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_chat_messages"    ON chat_messages      FOR ALL TO anon, service_role USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_bot_training"     ON bot_training       FOR ALL TO anon, service_role USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_service_bookings" ON service_bookings   FOR ALL TO anon, service_role USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_service_reminders"ON service_reminders  FOR ALL TO anon, service_role USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_service_reviews"  ON service_reviews    FOR ALL TO anon, service_role USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_job_parts"        ON service_job_parts  FOR ALL TO anon, service_role USING (true) WITH CHECK (true);


-- ============================================================
-- Storage bucket  (run separately in Supabase Storage UI
-- or via the management API — SQL can't create buckets)
-- ============================================================
-- Bucket name: web_image_urls
-- Public: true
-- Allowed MIME types: image/jpeg, image/png, image/webp
-- File size limit: 5 MB
--
-- After creating the bucket, add this storage policy:
--   Name: public_read
--   Operation: SELECT
--   Role: anon
--   Definition: true



-- ============================================================
-- 9. delivery_zones  (pincode → delivery info)
-- ============================================================
CREATE TABLE IF NOT EXISTS delivery_zones (
    pincode          text        PRIMARY KEY,   -- 6-digit Indian pincode
    area_name        text        NOT NULL,      -- e.g. "Nellore"
    district         text        NOT NULL,      -- e.g. "SPSR Nellore"
    state            text        NOT NULL DEFAULT 'Andhra Pradesh',
    km_from_shop     numeric(7,1),              -- road distance from shop
    delivery_days    integer     NOT NULL DEFAULT 3,
    delivery_charge  numeric(8,2) NOT NULL DEFAULT 50,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_delivery_zones_district ON delivery_zones (district);
CREATE INDEX IF NOT EXISTS idx_delivery_zones_state    ON delivery_zones (state);

CREATE TRIGGER trg_delivery_zones_updated_at
    BEFORE UPDATE ON delivery_zones
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

ALTER TABLE delivery_zones ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anon_all_delivery_zones" ON delivery_zones FOR ALL TO anon, service_role USING (true) WITH CHECK (true);

-- ── Seed: Nellore district pincodes (shop is in Nellore) ──────────────────
-- Adjust km_from_shop and delivery_charge as needed
INSERT INTO delivery_zones (pincode, area_name, district, state, km_from_shop, delivery_days, delivery_charge) VALUES
  ('524001', 'Nellore',            'SPSR Nellore', 'Andhra Pradesh',   2,  1,  0),
  ('524002', 'Nellore',            'SPSR Nellore', 'Andhra Pradesh',   3,  1,  0),
  ('524003', 'Nellore',            'SPSR Nellore', 'Andhra Pradesh',   4,  1,  0),
  ('524004', 'Nellore',            'SPSR Nellore', 'Andhra Pradesh',   5,  1,  0),
  ('524101', 'Atmakur',            'SPSR Nellore', 'Andhra Pradesh',  45,  2, 40),
  ('524121', 'Kavali',             'SPSR Nellore', 'Andhra Pradesh',  60,  2, 40),
  ('524131', 'Allur',              'SPSR Nellore', 'Andhra Pradesh',  35,  2, 40),
  ('524132', 'Akbarnivasa Khandrika','SPSR Nellore','Andhra Pradesh',  1,  1,  0),
  ('524201', 'Gudur',              'SPSR Nellore', 'Andhra Pradesh',  80,  2, 50),
  ('524202', 'Sullurpeta',         'SPSR Nellore', 'Andhra Pradesh',  90,  2, 50),
  ('524203', 'Tada',               'SPSR Nellore', 'Andhra Pradesh', 100,  2, 50),
  ('524301', 'Venkatagiri',        'SPSR Nellore', 'Andhra Pradesh',  70,  2, 50),
  ('524302', 'Naidupeta',          'SPSR Nellore', 'Andhra Pradesh',  65,  2, 50),
  ('524401', 'Kovur',              'SPSR Nellore', 'Andhra Pradesh',  25,  1, 40),
  ('524402', 'Muthukur',           'SPSR Nellore', 'Andhra Pradesh',  20,  1, 40),
  ('524403', 'Podalakur',          'SPSR Nellore', 'Andhra Pradesh',  30,  2, 40),
  ('524421', 'Marripadu',          'SPSR Nellore', 'Andhra Pradesh',  55,  2, 40),
  ('524501', 'Udayagiri',          'SPSR Nellore', 'Andhra Pradesh', 110,  3, 60),
  ('524502', 'Sydapuram',          'SPSR Nellore', 'Andhra Pradesh',  40,  2, 40),
-- Prakasam district
  ('523001', 'Ongole',             'Prakasam',     'Andhra Pradesh', 100,  2, 60),
  ('523002', 'Ongole',             'Prakasam',     'Andhra Pradesh', 102,  2, 60),
  ('523101', 'Chirala',            'Prakasam',     'Andhra Pradesh', 130,  3, 70),
  ('523155', 'Bapatla',            'Bapatla',      'Andhra Pradesh', 150,  3, 70),
  ('523201', 'Markapur',           'Prakasam',     'Andhra Pradesh', 160,  3, 80),
  ('523301', 'Kandukur',           'Prakasam',     'Andhra Pradesh',  80,  2, 50),
-- Tirupati / Chittoor
  ('517001', 'Tirupati',           'Tirupati',     'Andhra Pradesh', 200,  3, 80),
  ('517501', 'Chittoor',           'Chittoor',     'Andhra Pradesh', 250,  4, 90),
-- Krishna / Guntur
  ('520001', 'Vijayawada',         'Krishna',      'Andhra Pradesh', 280,  3, 90),
  ('522001', 'Guntur',             'Guntur',       'Andhra Pradesh', 260,  3, 90),
-- Visakhapatnam
  ('530001', 'Visakhapatnam',      'Visakhapatnam','Andhra Pradesh', 500,  4,120),
-- Telangana
  ('500001', 'Hyderabad',          'Hyderabad',    'Telangana',      350,  3,100),
  ('500002', 'Hyderabad',          'Hyderabad',    'Telangana',      350,  3,100),
  ('500003', 'Secunderabad',       'Hyderabad',    'Telangana',      355,  3,100),
  ('500016', 'Ameerpet',           'Hyderabad',    'Telangana',      352,  3,100),
  ('500032', 'Kukatpally',         'Hyderabad',    'Telangana',      360,  3,100),
  ('500072', 'Gachibowli',         'Hyderabad',    'Telangana',      365,  3,100),
  ('500081', 'Kondapur',           'Hyderabad',    'Telangana',      368,  3,100),
  ('501301', 'Shadnagar',          'Ranga Reddy',  'Telangana',      380,  3,100),
  ('508001', 'Nalgonda',           'Nalgonda',     'Telangana',      320,  3,100),
  ('506001', 'Warangal',           'Warangal',     'Telangana',      400,  4,110),
  ('504001', 'Adilabad',           'Adilabad',     'Telangana',      550,  5,130)
ON CONFLICT (pincode) DO NOTHING;

-- ============================================================
-- Realtime — enable for bookings + orders
-- Run this in Supabase SQL editor to enable realtime events
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE service_bookings;
ALTER PUBLICATION supabase_realtime ADD TABLE orders;
