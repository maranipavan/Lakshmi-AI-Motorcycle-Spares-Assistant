-- =============================================================================
-- Migration 0002: Multi-Tenant Omnichannel Automation SaaS Schema & RLS
-- =============================================================================
BEGIN;

CREATE TABLE IF NOT EXISTS public.tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug TEXT UNIQUE NOT NULL,
    business_name TEXT NOT NULL,
    industry_preset TEXT NOT NULL DEFAULT 'automobile_spare_parts',
    timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata',
    currency TEXT NOT NULL DEFAULT 'INR',
    plan_id TEXT NOT NULL DEFAULT 'pro_max',
    subscription_status TEXT NOT NULL DEFAULT 'active',
    enabled_modules JSONB NOT NULL DEFAULT '{"catalog_commerce":true,"service_booking":true,"comment_automation":true,"ai_assistant":true,"whatsapp":true,"instagram":true,"facebook":true,"telegram":true,"webchat":true}'::jsonb,
    branding JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.tenants (id, slug, business_name, industry_preset, timezone, currency, plan_id, subscription_status)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'lakshmi-motorcycle-spares',
    'Lakshmi Motorcycle Spares',
    'automobile_spare_parts',
    'Asia/Kolkata',
    'INR',
    'pro_max',
    'active'
) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.tenant_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    is_super_admin BOOLEAN NOT NULL DEFAULT FALSE,
    totp_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.tenant_memberships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.tenant_users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('super_admin','workspace_owner','admin','manager','support_agent','analyst','billing_manager','developer')),
    UNIQUE(tenant_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.channel_connections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    channel_type TEXT NOT NULL CHECK (channel_type IN ('instagram','facebook','whatsapp','telegram','webchat','webhook')),
    display_name TEXT NOT NULL,
    external_account_id TEXT NOT NULL,
    encrypted_credentials TEXT NOT NULL DEFAULT '',
    webhook_verify_token TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'connected',
    health_meta JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, channel_type, external_account_id)
);

CREATE TABLE IF NOT EXISTS public.workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft','published','archived')),
    active_version INTEGER NOT NULL DEFAULT 1,
    trigger_type TEXT NOT NULL,
    definition JSONB NOT NULL DEFAULT '{}'::jsonb,
    version_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.comment_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    platform TEXT NOT NULL CHECK (platform IN ('instagram','facebook')),
    post_id TEXT NOT NULL DEFAULT '*',
    match_type TEXT NOT NULL DEFAULT 'contains' CHECK (match_type IN ('exact','contains','regex','intent')),
    keywords JSONB NOT NULL DEFAULT '[]'::jsonb,
    public_reply_templates JSONB NOT NULL DEFAULT '[]'::jsonb,
    private_dm_template TEXT NOT NULL DEFAULT '',
    cooldown_seconds INTEGER NOT NULL DEFAULT 300,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    channel_type TEXT NOT NULL,
    external_thread_id TEXT NOT NULL,
    customer_name TEXT DEFAULT '',
    customer_handle TEXT DEFAULT '',
    customer_phone TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','pending','snoozed','resolved','escalated')),
    assigned_agent_id UUID,
    automation_paused_until TIMESTAMPTZ,
    tags JSONB NOT NULL DEFAULT '[]'::jsonb,
    last_message_preview TEXT DEFAULT '',
    last_message_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, channel_type, external_thread_id)
);

CREATE TABLE IF NOT EXISTS public.inbox_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    external_message_id TEXT NOT NULL,
    direction TEXT NOT NULL CHECK (direction IN ('inbound','outbound','internal_note')),
    sender_type TEXT NOT NULL CHECK (sender_type IN ('customer','bot','agent','system')),
    body TEXT NOT NULL DEFAULT '',
    attachments JSONB NOT NULL DEFAULT '[]'::jsonb,
    delivery_status TEXT NOT NULL DEFAULT 'delivered',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, external_message_id)
);

CREATE TABLE IF NOT EXISTS public.subscription_plans (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    monthly_price_inr INTEGER NOT NULL,
    yearly_price_inr INTEGER NOT NULL,
    limits JSONB NOT NULL
);

INSERT INTO public.subscription_plans (id, name, monthly_price_inr, yearly_price_inr, limits) VALUES
('standard', 'Standard', 999, 9990, '{"channels":2,"monthly_messages":10000,"team_seats":3,"workflows":5,"catalog_items":1000,"ai_tokens":100000}'::jsonb),
('pro', 'Pro', 2499, 24990, '{"channels":5,"monthly_messages":50000,"team_seats":10,"workflows":25,"catalog_items":10000,"ai_tokens":500000}'::jsonb),
('pro_max', 'Pro Max', 5999, 59990, '{"channels":25,"monthly_messages":250000,"team_seats":50,"workflows":200,"catalog_items":100000,"ai_tokens":2500000}'::jsonb)
ON CONFLICT (id) DO UPDATE SET
    monthly_price_inr = EXCLUDED.monthly_price_inr,
    yearly_price_inr = EXCLUDED.yearly_price_inr,
    limits = EXCLUDED.limits;

CREATE TABLE IF NOT EXISTS public.usage_counters (
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    period_month TEXT NOT NULL,
    metric TEXT NOT NULL,
    used_count BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (tenant_id, period_month, metric)
);

CREATE TABLE IF NOT EXISTS public.webhook_events (
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    provider TEXT NOT NULL,
    event_id TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    processed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (tenant_id, provider, event_id)
);

CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    actor_id TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    ip_address TEXT DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE IF EXISTS public.parts ADD COLUMN IF NOT EXISTS tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001';
ALTER TABLE IF EXISTS public.orders ADD COLUMN IF NOT EXISTS tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001';
ALTER TABLE IF EXISTS public.bot_orders ADD COLUMN IF NOT EXISTS tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001';
ALTER TABLE IF EXISTS public.service_appointments ADD COLUMN IF NOT EXISTS tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001';

CREATE INDEX IF NOT EXISTS idx_parts_tenant_id ON public.parts(tenant_id);
CREATE INDEX IF NOT EXISTS idx_conversations_tenant_status ON public.conversations(tenant_id, status, last_message_at DESC);
CREATE INDEX IF NOT EXISTS idx_inbox_messages_conv ON public.inbox_messages(tenant_id, conversation_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant ON public.audit_logs(tenant_id, created_at DESC);

COMMIT;
