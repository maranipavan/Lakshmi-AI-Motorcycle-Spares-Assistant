-- =============================================================================
-- Migration 0001: Reconcile Production Schema Drift & Harden RLS Policies
-- Safe, additive, idempotent migration preserving Lakshmi Motorcycle Spares data
-- =============================================================================
BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE IF EXISTS public.parts
    ADD COLUMN IF NOT EXISTS aliases TEXT DEFAULT '',
    ADD COLUMN IF NOT EXISTS compatibility TEXT DEFAULT '';

CREATE TABLE IF NOT EXISTS public.bot_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.bot_orders (
    id TEXT PRIMARY KEY,
    platform TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    customer_name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    address TEXT DEFAULT '',
    pincode TEXT DEFAULT '',
    items JSONB NOT NULL DEFAULT '[]'::jsonb,
    subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
    delivery_charge NUMERIC(12,2) NOT NULL DEFAULT 0,
    total NUMERIC(12,2) NOT NULL DEFAULT 0,
    payment_method TEXT DEFAULT 'upi',
    payment_status TEXT DEFAULT 'pending',
    order_status TEXT DEFAULT 'pending',
    razorpay_link_id TEXT DEFAULT '',
    razorpay_payment_id TEXT DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform TEXT NOT NULL,
    external_id TEXT NOT NULL,
    name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(platform, external_id)
);

CREATE TABLE IF NOT EXISTS public.chat_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    state JSONB NOT NULL DEFAULT '{}'::jsonb,
    automation_paused_until TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(platform, chat_id)
);

DROP POLICY IF EXISTS "Anon can update parts" ON public.parts;
DROP POLICY IF EXISTS "Anon can insert parts" ON public.parts;
DROP POLICY IF EXISTS "Anon can delete parts" ON public.parts;
DROP POLICY IF EXISTS "Anon full access orders" ON public.orders;
DROP POLICY IF EXISTS "Anon full access store_config" ON public.store_config;

COMMIT;
