//! chat_ws — Rust WebSocket + REST sidecar
//!
//! Lives in the same crate as telegram_sync (main.rs).
//! Build both with: cargo build --release
//!   → target/release/telegram_sync  (Telegram channel sync)
//!   → target/release/chat_ws        (WebSocket + REST chat layer)
//!
//! Systemd runs them as two separate services sharing the same binary folder.
//! They share zero runtime state — each is a standalone process.
//!
//! Routes exposed (nginx proxies /ws/chat/* and /api/chat/* here):
//!   WS   /ws/chat/admin           admin WebSocket
//!   WS   /ws/chat/:session_id     customer WebSocket
//!   POST /api/chat/send           customer REST fallback
//!   POST /api/chat/reply          admin reply (text + image)
//!   GET  /api/chat/messages/:sid  message history
//!   GET  /api/chat/sessions       session list (admin)
//!   POST /api/chat/set-name       set display name
//!   DEL  /api/chat/sessions/:sid  delete session
//!   PAT  /api/chat/message/:id    edit message
//!   GET  /health                  liveness probe
//!
//! Auto-reply calls Python at PYTHON_API_URL/internal/auto-reply (loopback).
//! Add internal_endpoints.py to your Flask app — see MIGRATION.md.
//!
//! Required env vars (read from .env same as telegram_sync):
//!   CHAT_WS_PORT          default 8765
//!   PYTHON_API_URL        default http://127.0.0.1:5000
//!   SUPABASE_URL
//!   SUPABASE_SERVICE_KEY  (or SUPABASE_KEY)
//!   ADMIN_PIN             default 1234
//!   TELEGRAM_TOKEN        (optional, for Telegram reply forwarding)

use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use anyhow::{Context, Result};
use axum::{
    extract::{
        ws::{Message, WebSocket, WebSocketUpgrade},
        Path, Query, State,
    },
    http::{HeaderMap, Method, StatusCode},
    response::{IntoResponse, Response},
    routing::{delete, get, patch, post},
    Json, Router,
};
use base64::{engine::general_purpose::STANDARD as B64, Engine as _};
use dashmap::DashMap;
use reqwest::header::{HeaderValue, AUTHORIZATION, CONTENT_TYPE};
use serde::Deserialize;
use serde_json::{json, Value};
use tokio::sync::{broadcast, RwLock};
use tower_http::{
    cors::CorsLayer,
    limit::RequestBodyLimitLayer,
};
use tracing::{error, info, warn};
use uuid::Uuid;

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS  (match chat.py exactly)
// ─────────────────────────────────────────────────────────────────────────────
const MAX_MESSAGE_LEN:  usize = 2_000;
const MAX_IMAGE_LEN:    usize = 1_500_000;
const MAX_SESSION_LEN:  usize = 80;
const MAX_NAME_LEN:     usize = 80;
const SESSION_NAME_MAX: usize = 500;

// ─────────────────────────────────────────────────────────────────────────────
// UNICODE-SAFE TRUNCATION
// Standard &str[..n] panics if n splits a multi-byte char (emoji, Telugu, etc).
// Use this everywhere instead.
// ─────────────────────────────────────────────────────────────────────────────
fn trunc(s: &str, max_bytes: usize) -> &str {
    if s.len() <= max_bytes { return s; }
    let mut end = max_bytes;
    while end > 0 && !s.is_char_boundary(end) { end -= 1; }
    &s[..end]
}
struct Config {
    supabase_url:    String,
    service_key:     String,
    admin_pin:       String,
    telegram_token:  String,
    python_url:      String,
}

impl Config {
    fn from_env() -> Self {
        Self {
            supabase_url:   std::env::var("SUPABASE_URL")
                                .expect("SUPABASE_URL missing"),
            service_key:    std::env::var("SUPABASE_SERVICE_KEY")
                                .or_else(|_| std::env::var("SUPABASE_KEY"))
                                .expect("SUPABASE_SERVICE_KEY missing"),
            admin_pin:      std::env::var("ADMIN_PIN")
                                .unwrap_or_default(),
            telegram_token: std::env::var("TELEGRAM_TOKEN")
                                .unwrap_or_default(),
            python_url:     std::env::var("PYTHON_API_URL")
                                .unwrap_or_else(|_| "http://127.0.0.1:5000".into()),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED STATE
// ─────────────────────────────────────────────────────────────────────────────

/// One broadcast::Sender per customer session.
/// All WebSocket connections for the same session_id share one channel.
type SessionBus = Arc<DashMap<String, broadcast::Sender<String>>>;

/// Single channel all admin WebSocket connections subscribe to.
type AdminTx = Arc<broadcast::Sender<String>>;

/// Display names: session_id → human name (LRU-evicted at 500 entries).
type SessionNames = Arc<RwLock<HashMap<String, String>>>;

#[derive(Clone)]
struct AppState {
    session_bus:   SessionBus,
    admin_tx:      AdminTx,
    session_names: SessionNames,
    http:          reqwest::Client,  // shared pool — all Supabase + Telegram calls
    cfg:           Arc<Config>,
}

// ─────────────────────────────────────────────────────────────────────────────
// SUPABASE REST  (thin wrapper, no SDK)
// ─────────────────────────────────────────────────────────────────────────────
struct Db<'a> {
    http: &'a reqwest::Client,
    base: String,
    auth: reqwest::header::HeaderMap,
}

impl<'a> Db<'a> {
    fn new(http: &'a reqwest::Client, cfg: &Config) -> Self {
        let mut h = reqwest::header::HeaderMap::new();
        h.insert(AUTHORIZATION,
            HeaderValue::from_str(&format!("Bearer {}", cfg.service_key)).unwrap());
        h.insert("apikey",
            HeaderValue::from_str(&cfg.service_key).unwrap());
        h.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
        Self { http, base: format!("{}/rest/v1", cfg.supabase_url), auth: h }
    }

    async fn insert_message(&self, session_id: &str, sender: &str, message: &str) {
        let url  = format!("{}/chat_messages", self.base);
        let body = json!({ "session_id": session_id, "sender": sender, "message": message });
        match self.http.post(&url).headers(self.auth.clone()).json(&body).send().await {
            Ok(r) if !r.status().is_success() => {
                let txt = r.text().await.unwrap_or_default();
                if !txt.contains("23505") && !txt.contains("duplicate key") {
                    warn!("[db] insert failed: {}", trunc(&txt, 200));
                }
            }
            Ok(_)  => info!("[db] 💾 {} in {}…→ {}",
                sender, trunc(session_id, 12), trunc(message, 50)),
            Err(e) => error!("[db] insert error: {}", e),
        }
    }

    async fn get_history(&self, session_id: &str) -> Vec<Value> {
        let url = format!(
            "{}/chat_messages?select=id,sender,message,created_at\
             &session_id=eq.{}&order=created_at.asc&limit=100",
            self.base, urlencoding::encode(session_id)
        );
        match self.http.get(&url).headers(self.auth.clone()).send().await {
            Ok(r)  => r.json::<Vec<Value>>().await.unwrap_or_default(),
            Err(e) => { error!("[db] get_history: {}", e); vec![] }
        }
    }

    async fn get_messages(&self, session_id: &str, after_id: Option<&str>) -> Vec<Value> {
        let mut url = format!(
            "{}/chat_messages?select=id,sender,message,created_at\
             &session_id=eq.{}&order=created_at.asc&limit=100",
            self.base, urlencoding::encode(session_id)
        );
        if let Some(aid) = after_id {
            url.push_str(&format!("&id=gt.{}", urlencoding::encode(aid)));
        }
        match self.http.get(&url).headers(self.auth.clone()).send().await {
            Ok(r)  => r.json::<Vec<Value>>().await.unwrap_or_default(),
            Err(e) => { error!("[db] get_messages: {}", e); vec![] }
        }
    }

    async fn get_recent_rows(&self) -> Vec<Value> {
        let url = format!(
            "{}/chat_messages?select=session_id,sender,message,created_at\
             &order=created_at.desc&limit=1000",
            self.base
        );
        match self.http.get(&url).headers(self.auth.clone()).send().await {
            Ok(r)  => r.json::<Vec<Value>>().await.unwrap_or_default(),
            Err(e) => { error!("[db] get_recent_rows: {}", e); vec![] }
        }
    }

    async fn delete_session(&self, session_id: &str) -> usize {
        let url = format!(
            "{}/chat_messages?session_id=eq.{}&select=id",
            self.base, urlencoding::encode(session_id)
        );
        let mut h = self.auth.clone();
        h.insert("Prefer", HeaderValue::from_static("return=representation"));
        match self.http.delete(&url).headers(h).send().await {
            Ok(r)  => r.json::<Vec<Value>>().await.unwrap_or_default().len(),
            Err(e) => { error!("[db] delete_session: {}", e); 0 }
        }
    }

    async fn get_message(&self, msg_id: &str) -> Option<Value> {
        let url = format!(
            "{}/chat_messages?select=id,session_id,sender,message&id=eq.{}&limit=1",
            self.base, urlencoding::encode(msg_id)
        );
        match self.http.get(&url).headers(self.auth.clone()).send().await {
            Ok(r)  => r.json::<Vec<Value>>().await.unwrap_or_default().into_iter().next(),
            Err(e) => { error!("[db] get_message: {}", e); None }
        }
    }

    async fn update_message(&self, msg_id: &str, new_text: &str) -> bool {
        let url  = format!("{}/chat_messages?id=eq.{}", self.base, urlencoding::encode(msg_id));
        let body = json!({ "message": new_text, "edited": true });
        self.http.patch(&url).headers(self.auth.clone()).json(&body).send().await
            .map(|r| r.status().is_success()).unwrap_or(false)
    }

    async fn get_tg_msg_id(&self, msg_id: &str) -> Option<i64> {
        let url = format!(
            "{}/chat_messages?select=telegram_message_id&id=eq.{}&limit=1",
            self.base, urlencoding::encode(msg_id)
        );
        match self.http.get(&url).headers(self.auth.clone()).send().await {
            Ok(r) => r.json::<Vec<Value>>().await.unwrap_or_default()
                        .into_iter().next()
                        .and_then(|r| r.get("telegram_message_id").cloned())
                        .and_then(|v| v.as_i64()),
            Err(e) => { error!("[db] get_tg_msg_id: {}", e); None }
        }
    }

    async fn get_recent_for_training(&self, session_id: &str) -> Vec<Value> {
        let url = format!(
            "{}/chat_messages?select=sender,message\
             &session_id=eq.{}&order=created_at.desc&limit=10",
            self.base, urlencoding::encode(session_id)
        );
        match self.http.get(&url).headers(self.auth.clone()).send().await {
            Ok(r)  => r.json::<Vec<Value>>().await.unwrap_or_default(),
            Err(e) => { error!("[db] get_recent_for_training: {}", e); vec![] }
        }
    }

    async fn upload_image(
        &self, cfg: &Config, filename: &str, bytes: Vec<u8>, content_type: &str,
    ) -> Result<String> {
        let upload_url = format!(
            "{}/storage/v1/object/chat-images/{}",
            cfg.supabase_url, filename
        );
        let public_url = format!(
            "{}/storage/v1/object/public/chat-images/{}",
            cfg.supabase_url, filename
        );
        self.http
            .post(&upload_url)
            .header(AUTHORIZATION, format!("Bearer {}", cfg.service_key))
            .header("Content-Type", content_type)
            .header("x-upsert", "true")
            .header("cache-control", "86400")
            .body(bytes)
            .send().await
            .context("Storage upload failed")?;
        Ok(public_url)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────────────────────────────────────────
fn constant_time_eq(a: &str, b: &str) -> bool {
    if a.is_empty() || b.is_empty() || a.len() != b.len() {
        return false;
    }
    a.as_bytes().iter().zip(b.as_bytes().iter()).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

fn check_pin(headers: &HeaderMap, query: Option<&str>, body: Option<&str>, cfg: &Config) -> bool {
    if cfg.admin_pin.is_empty() { return false; }
    if let Some(auth) = headers.get("Authorization").and_then(|v| v.to_str().ok()) {
        if let Some(tok) = auth.strip_prefix("Bearer ") {
            return constant_time_eq(tok.trim(), &cfg.admin_pin);
        }
    }
    if let Some(p) = query { return constant_time_eq(p.trim(), &cfg.admin_pin); }
    if let Some(p) = body  { return constant_time_eq(p.trim(), &cfg.admin_pin); }
    false
}

// ─────────────────────────────────────────────────────────────────────────────
// IMAGE DECODE
// ─────────────────────────────────────────────────────────────────────────────
struct Img { bytes: Vec<u8>, ext: String, ct: String }

fn decode_image(b64: &str) -> Option<Img> {
    let (hdr, data) = if b64.contains(',') {
        let mut it = b64.splitn(2, ',');
        (it.next().unwrap_or(""), it.next().unwrap_or(""))
    } else { ("", b64) };
    let ext = if hdr.contains("png") { "png" } else if hdr.contains("gif") { "gif" }
              else if hdr.contains("webp") { "webp" } else { "jpg" };
    Some(Img { bytes: B64.decode(data).ok()?, ct: format!("image/{}", ext), ext: ext.into() })
}

async fn upload_img(b64: &str, sid: &str, http: &reqwest::Client, cfg: &Config) -> String {
    let img = match decode_image(b64) { Some(i) => i, None => return String::new() };
    let fname = format!(
        "{}_{}_{}.{}",
        trunc(sid, 20),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_secs(),
        &Uuid::new_v4().to_string()[..8],
        img.ext
    );
    let db = Db::new(http, cfg);
    db.upload_image(cfg, &fname, img.bytes, &img.ct).await.unwrap_or_default()
}

// ─────────────────────────────────────────────────────────────────────────────
// PYTHON SIDECAR CALLS  (loopback HTTP)
// ─────────────────────────────────────────────────────────────────────────────
async fn auto_reply(http: &reqwest::Client, py: &str, msg: &str, sid: &str)
    -> (Option<String>, Option<String>)
{
    let url = format!("{}/internal/auto-reply", py);
    match http.post(&url)
        .json(&json!({ "message": msg, "session_id": sid, "source": "web" }))
        .timeout(Duration::from_secs(30)).send().await
    {
        Ok(r) if r.status().is_success() => {
            match r.json::<Value>().await {
                Ok(v) => (
                    v["reply"].as_str().map(str::to_string),
                    v["part_id"].as_str().map(str::to_string),
                ),
                Err(e) => { error!("[auto_reply] parse: {}", e); (None, None) }
            }
        }
        Ok(r)  => { warn!("[auto_reply] status {}", r.status()); (None, None) }
        Err(e) => { error!("[auto_reply] http: {}", e);          (None, None) }
    }
}

async fn save_learned(http: &reqwest::Client, py: &str, q: &str, a: &str) {
    let _ = http.post(&format!("{}/internal/save-learned-reply", py))
        .json(&json!({ "question": q, "answer": a }))
        .timeout(Duration::from_secs(10)).send().await;
}

async fn push_admin(http: &reqwest::Client, py: &str, title: &str, body: &str) {
    let _ = http.post(&format!("{}/internal/push-admin", py))
        .json(&json!({ "title": title, "body": body }))
        .timeout(Duration::from_secs(5)).send().await;
}

// ─────────────────────────────────────────────────────────────────────────────
// TELEGRAM FORWARDING
// ─────────────────────────────────────────────────────────────────────────────
async fn tg_send(http: &reqwest::Client, token: &str, chat_id: &str, text: &str) {
    if token.is_empty() { return; }
    let _ = http.post(&format!("https://api.telegram.org/bot{}/sendMessage", token))
        .json(&json!({ "chat_id": chat_id, "text": text }))
        .timeout(Duration::from_secs(10)).send().await;
}

async fn tg_send_photo(http: &reqwest::Client, token: &str, chat_id: &str, bytes: Vec<u8>) {
    if token.is_empty() { return; }
    let part = reqwest::multipart::Part::bytes(bytes)
        .file_name("image.jpg").mime_str("image/jpeg").unwrap();
    let form = reqwest::multipart::Form::new()
        .text("chat_id", chat_id.to_string())
        .part("photo", part);
    let _ = http.post(&format!("https://api.telegram.org/bot{}/sendPhoto", token))
        .multipart(form).timeout(Duration::from_secs(30)).send().await;
}

async fn tg_edit(http: &reqwest::Client, token: &str, chat_id: &str, tg_id: i64, text: &str) {
    if token.is_empty() { return; }
    let _ = http.post(&format!("https://api.telegram.org/bot{}/editMessageText", token))
        .json(&json!({
            "chat_id": chat_id, "message_id": tg_id,
            "text": format!("{}\n_(edited)_", text), "parse_mode": "Markdown"
        }))
        .timeout(Duration::from_secs(5)).send().await;
}

// ─────────────────────────────────────────────────────────────────────────────
// BROADCAST HELPERS
// ─────────────────────────────────────────────────────────────────────────────
fn bcast_session(bus: &SessionBus, sid: &str, msg: &Value) {
    if let Some(tx) = bus.get(sid) { let _ = tx.send(msg.to_string()); }
}

fn bcast_admins(tx: &AdminTx, msg: &Value) { let _ = tx.send(msg.to_string()); }

fn session_sub(bus: &SessionBus, sid: &str) -> broadcast::Receiver<String> {
    if let Some(tx) = bus.get(sid) { return tx.subscribe(); }
    let (tx, rx) = broadcast::channel(64);
    bus.insert(sid.to_string(), tx);
    rx
}

fn session_gc(bus: &SessionBus, sid: &str) {
    if let Some(tx) = bus.get(sid) {
        if tx.receiver_count() == 0 { drop(tx); bus.remove(sid); }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SESSION NAME HELPER
// ─────────────────────────────────────────────────────────────────────────────
async fn upsert_name(names: &SessionNames, sid: &str, name: &str) {
    let mut w = names.write().await;
    if w.len() >= SESSION_NAME_MAX {
        if let Some(k) = w.keys().next().cloned() { w.remove(&k); }
    }
    w.insert(sid.to_string(), trunc(name, MAX_NAME_LEN).to_string());
}

async fn get_name(names: &SessionNames, sid: &str) -> String {
    names.read().await.get(sid).cloned()
        .unwrap_or_else(|| format!("{}…", trunc(sid, 14)))
}

// ─────────────────────────────────────────────────────────────────────────────
// WS PROXY TASK
// Owns the WebSocket socket and provides send_tx / recv_rx channels.
// This lets separate tokio::select! arms handle inbound and outbound cleanly.
// ─────────────────────────────────────────────────────────────────────────────
struct WsConn {
    send_tx: tokio::sync::mpsc::Sender<String>,
    recv_rx: tokio::sync::mpsc::Receiver<String>,
    task:    tokio::task::JoinHandle<()>,
}

fn ws_proxy(mut socket: WebSocket) -> WsConn {
    let (send_tx, mut send_rx) = tokio::sync::mpsc::channel::<String>(64);
    let (recv_tx,     recv_rx) = tokio::sync::mpsc::channel::<String>(128);

    let task = tokio::spawn(async move {
        loop {
            tokio::select! {
                Some(msg) = send_rx.recv() => {
                    if socket.send(Message::Text(msg)).await.is_err() { break; }
                }
                item = socket.recv() => match item {
                    Some(Ok(Message::Text(t))) => {
                        if recv_tx.send(t).await.is_err() { break; }
                    }
                    Some(Ok(Message::Close(_))) | None => break,
                    Some(Ok(_))  => {}   // ping/pong/binary — ignore
                    Some(Err(_)) => break,
                }
            }
        }
    });

    WsConn { send_tx, recv_rx, task }
}

// ─────────────────────────────────────────────────────────────────────────────
// CUSTOMER WEBSOCKET  /ws/chat/:session_id
// ─────────────────────────────────────────────────────────────────────────────
async fn ws_customer_upgrade(
    ws: WebSocketUpgrade,
    Path(session_id): Path<String>,
    State(st): State<AppState>,
) -> Response {
    if session_id.len() > MAX_SESSION_LEN {
        return (StatusCode::BAD_REQUEST, "session_id too long").into_response();
    }
    ws.on_upgrade(move |socket| ws_customer(socket, session_id, st))
}

async fn ws_customer(socket: WebSocket, sid: String, st: AppState) {
    let mut bcast = session_sub(&st.session_bus, &sid);
    let mut conn  = ws_proxy(socket);

    loop {
        tokio::select! {
            // ── Broadcast → customer ─────────────────────────────────────────
            Ok(msg) = bcast.recv() => {
                if conn.send_tx.send(msg).await.is_err() { break; }
            }
            // ── Customer → server ────────────────────────────────────────────
            item = conn.recv_rx.recv() => {
                let raw = match item { Some(r) => r, None => break };
                let d: Value = match serde_json::from_str(&raw) { Ok(v) => v, Err(_) => continue };
                let t = d["type"].as_str().unwrap_or("");

                // auth — send history
                if t == "auth" {
                    if let Some(n) = d["name"].as_str().filter(|s| !s.is_empty()) {
                        upsert_name(&st.session_names, &sid, n).await;
                    }
                    let db  = Db::new(&st.http, &st.cfg);
                    let his = db.get_history(&sid).await;
                    let _   = conn.send_tx.send(json!({"type":"history","messages":his}).to_string()).await;
                    continue;
                }

                // text message
                if t == "message" {
                    let text = d["text"].as_str().unwrap_or("").trim().to_string();
                    if text.is_empty() || text.len() > MAX_MESSAGE_LEN { continue; }

                    Db::new(&st.http, &st.cfg).insert_message(&sid, "customer", &text).await;

                    bcast_session(&st.session_bus, &sid, &json!({
                        "type":"message","sender":"customer","text":text,"session_id":sid
                    }));

                    let name = get_name(&st.session_names, &sid).await;
                    bcast_admins(&st.admin_tx, &json!({
                        "type":"new_message","session_id":sid,
                        "name":name,"text":trunc(&text,80)
                    }));

                    // push + auto-reply — both non-blocking spawns
                    {
                        let (h2,py,n2,t2) = (st.http.clone(),st.cfg.python_url.clone(),name.clone(),text.clone());
                        tokio::spawn(async move {
                            push_admin(&h2, &py, "💬 New Chat Message", &format!("{}: {}", n2, trunc(&t2,80))).await;
                        });
                    }
                    {
                        let st2 = st.clone(); let sid2 = sid.clone(); let msg2 = text.clone();
                        tokio::spawn(async move { do_auto_reply(st2, sid2, msg2).await; });
                    }
                    continue;
                }

                // image
                if t == "image" {
                    let img = d["data"].as_str().unwrap_or("").to_string();
                    if img.is_empty() || img.len() > MAX_IMAGE_LEN { continue; }
                    let st2 = st.clone(); let sid2 = sid.clone();
                    tokio::spawn(async move { do_customer_image(st2, sid2, img).await; });
                    continue;
                }
            }
        }
    }

    conn.task.abort();
    session_gc(&st.session_bus, &sid);
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN WEBSOCKET  /ws/chat/admin
// ─────────────────────────────────────────────────────────────────────────────
async fn ws_admin_upgrade(
    ws: WebSocketUpgrade,
    State(st): State<AppState>,
) -> Response {
    ws.on_upgrade(move |socket| ws_admin(socket, st))
}

async fn ws_admin(mut socket: WebSocket, st: AppState) {
    // First frame must be auth within 10s
    let raw = match tokio::time::timeout(Duration::from_secs(10), socket.recv()).await {
        Ok(Some(Ok(Message::Text(t)))) => t,
        _ => { let _ = socket.close().await; return; }
    };
    let auth: Value = match serde_json::from_str(&raw) {
        Ok(v)  => v,
        Err(_) => { let _ = socket.close().await; return; }
    };
    let pin = auth["pin"].as_str().unwrap_or("");
    if auth["type"].as_str() != Some("auth") || pin != st.cfg.admin_pin {
        let _ = socket.send(Message::Text(
            json!({"type":"error","text":"Unauthorized"}).to_string()
        )).await;
        let _ = socket.close().await;
        return;
    }
    let _ = socket.send(Message::Text(json!({"type":"auth_ok"}).to_string())).await;

    let mut bcast = st.admin_tx.subscribe();
    let mut conn  = ws_proxy(socket);

    loop {
        tokio::select! {
            Ok(msg) = bcast.recv() => {
                if conn.send_tx.send(msg).await.is_err() { break; }
            }
            item = conn.recv_rx.recv() => {
                let raw = match item { Some(r) => r, None => break };
                let d: Value = match serde_json::from_str(&raw) { Ok(v) => v, Err(_) => continue };
                if d["type"].as_str() != Some("reply") { continue; }

                let sid  = d["session_id"].as_str().unwrap_or("").trim().to_string();
                let text = d["text"].as_str().unwrap_or("").trim().to_string();
                if sid.is_empty() || text.is_empty() { continue; }
                if sid.len() > MAX_SESSION_LEN || text.len() > MAX_MESSAGE_LEN { continue; }

                let st2 = st.clone();
                tokio::spawn(async move { do_admin_reply(st2, sid, text, None).await; });
            }
        }
    }

    conn.task.abort();
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED BUSINESS LOGIC  (used by both WS and REST handlers)
// ─────────────────────────────────────────────────────────────────────────────

/// Auto-reply: call Python, save to DB, broadcast to session + admins.
async fn do_auto_reply(st: AppState, sid: String, msg: String) {
    let (reply, _) = auto_reply(&st.http, &st.cfg.python_url, &msg, &sid).await;
    if let Some(text) = reply {
        if text.is_empty() { return; }
        Db::new(&st.http, &st.cfg).insert_message(&sid, "bot", &text).await;
        bcast_session(&st.session_bus, &sid, &json!({
            "type":"message","sender":"bot","text":text,"session_id":sid
        }));
        bcast_admins(&st.admin_tx, &json!({"type":"message","sender":"bot","session_id":sid,"text":text}));
        bcast_admins(&st.admin_tx, &json!({
            "type":"new_message","session_id":sid,
            "name":"🤖 Bot","text":trunc(&text,80)
        }));
    }
}

/// Image upload + broadcast (customer sent photo).
async fn do_customer_image(st: AppState, sid: String, img_b64: String) {
    let url    = upload_img(&img_b64, &sid, &st.http, &st.cfg).await;
    let stored = if url.is_empty() { format!("[image:{}]", img_b64) }
                 else              { format!("[image:{}]", url) };
    Db::new(&st.http, &st.cfg).insert_message(&sid, "customer", &stored).await;
    bcast_session(&st.session_bus, &sid, &json!({
        "type":"message","sender":"customer","text":stored,"session_id":sid
    }));
    let name = get_name(&st.session_names, &sid).await;
    bcast_admins(&st.admin_tx, &json!({
        "type":"new_message","session_id":sid,"name":name,"text":"📷 Photo"
    }));
    let (h2, py, n2) = (st.http.clone(), st.cfg.python_url.clone(), name);
    tokio::spawn(async move {
        push_admin(&h2, &py, "📷 Photo received", &format!("{} sent a photo", n2)).await;
    });
}

/// Admin reply: save, broadcast, train, forward to Telegram if tg_ session.
/// image_b64 is Some only from the REST endpoint (WS replies are text-only).
async fn do_admin_reply(st: AppState, sid: String, text: String, image_b64: Option<String>) {
    let stored = if let Some(ref img) = image_b64 {
        let url = upload_img(img, &sid, &st.http, &st.cfg).await;
        if url.is_empty() { format!("[image:{}]", img) } else { format!("[image:{}]", url) }
    } else {
        text.clone()
    };

    let db = Db::new(&st.http, &st.cfg);
    db.insert_message(&sid, "support", &stored).await;
    bcast_session(&st.session_bus, &sid, &json!({
        "type":"message","sender":"support","text":stored,"session_id":sid
    }));

    // Self-train on text replies only
    if !text.is_empty() && image_b64.is_none() {
        let rows = db.get_recent_for_training(&sid).await;
        if let Some(q) = rows.iter().find(|r| {
            r["sender"].as_str() == Some("customer")
            && !r["message"].as_str().unwrap_or("").starts_with("[image:")
        }).and_then(|r| r["message"].as_str()).map(str::to_string) {
            let (h2, py, a) = (st.http.clone(), st.cfg.python_url.clone(), text.clone());
            tokio::spawn(async move { save_learned(&h2, &py, &q, &a).await; });
        }
    }

    // Forward to Telegram
    if sid.starts_with("tg_") {
        let cid   = sid[3..].to_string();
        let http2 = st.http.clone();
        let token = st.cfg.telegram_token.clone();
        if let Some(img) = image_b64 {
            if let Some(decoded) = decode_image(&img) {
                tokio::spawn(async move { tg_send_photo(&http2, &token, &cid, decoded.bytes).await; });
            }
        } else {
            let txt = text.clone();
            tokio::spawn(async move { tg_send(&http2, &token, &cid, &txt).await; });
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// REST HANDLERS
// ─────────────────────────────────────────────────────────────────────────────

// POST /api/chat/send
#[derive(Deserialize)]
struct SendBody {
    session_id: Option<String>,
    message:    Option<String>,
    image:      Option<String>,
    name:       Option<String>,
}
async fn rest_send(State(st): State<AppState>, Json(b): Json<SendBody>) -> Response {
    let sid = b.session_id.as_deref().unwrap_or("").trim().to_string();
    let msg = b.message.as_deref().unwrap_or("").trim().to_string();
    let img = b.image.as_deref().unwrap_or("").to_string();
    let nm  = b.name.as_deref().unwrap_or("").trim().to_string();

    if sid.is_empty() || (msg.is_empty() && img.is_empty()) {
        return err(400, "Missing fields");
    }
    if sid.len() > MAX_SESSION_LEN { return err(400, "Invalid session"); }
    if msg.len() > MAX_MESSAGE_LEN { return err(400, "Message too long"); }
    if !img.is_empty() && img.len() > MAX_IMAGE_LEN { return err(400, "Image too large"); }

    if !nm.is_empty() { upsert_name(&st.session_names, &sid, &nm).await; }

    let display = get_name(&st.session_names, &sid).await;
    let preview = if !img.is_empty() { "📷 Photo".into() }
                  else { trunc(&msg, 80).to_string() };

    if !img.is_empty() {
        let st2 = st.clone(); let sid2 = sid.clone(); let img2 = img.clone();
        tokio::spawn(async move { do_customer_image(st2, sid2, img2).await; });
    } else {
        let stored = msg.clone();
        Db::new(&st.http, &st.cfg).insert_message(&sid, "customer", &stored).await;
        bcast_session(&st.session_bus, &sid, &json!({
            "type":"message","sender":"customer","text":stored,"session_id":sid
        }));
        bcast_admins(&st.admin_tx, &json!({
            "type":"new_message","session_id":sid,"name":display,"text":preview
        }));
        let (h2, py) = (st.http.clone(), st.cfg.python_url.clone());
        let pb = format!("{}: {}", display, preview);
        tokio::spawn(async move { push_admin(&h2, &py, "💬 New Chat Message", &pb).await; });
        let st2 = st.clone(); let sid2 = sid.clone(); let msg2 = msg.clone();
        tokio::spawn(async move { do_auto_reply(st2, sid2, msg2).await; });
    }

    ok()
}

// POST /api/chat/reply
#[derive(Deserialize)]
struct ReplyBody {
    session_id: Option<String>,
    message:    Option<String>,
    image:      Option<String>,
    pin:        Option<String>,
}
async fn rest_reply(
    State(st): State<AppState>, headers: HeaderMap, Json(b): Json<ReplyBody>
) -> Response {
    if !check_pin(&headers, None, b.pin.as_deref(), &st.cfg) { return err(401, "Unauthorized"); }

    let sid = b.session_id.as_deref().unwrap_or("").trim().to_string();
    let msg = b.message.as_deref().unwrap_or("").trim().to_string();
    let img = b.image.as_deref().unwrap_or("").to_string();

    if sid.is_empty() || (msg.is_empty() && img.is_empty()) { return err(400, "Missing fields"); }
    if sid.len() > MAX_SESSION_LEN { return err(400, "Invalid input"); }
    if !img.is_empty() && img.len() > MAX_IMAGE_LEN { return err(400, "Image too large"); }

    let img_opt = if img.is_empty() { None } else { Some(img) };
    tokio::spawn(async move { do_admin_reply(st, sid, msg, img_opt).await; });
    ok()
}

// GET /api/chat/messages/:session_id
#[derive(Deserialize)]
struct AfterQuery { after: Option<String> }
async fn rest_messages(
    Path(sid): Path<String>, Query(q): Query<AfterQuery>, State(st): State<AppState>
) -> Response {
    if sid.len() > MAX_SESSION_LEN { return err(400, "Invalid session"); }
    let rows = Db::new(&st.http, &st.cfg).get_messages(&sid, q.after.as_deref()).await;
    Json(rows).into_response()
}

// GET /api/chat/sessions
#[derive(Deserialize)]
struct PinQuery { pin: Option<String> }
async fn rest_sessions(
    State(st): State<AppState>, headers: HeaderMap, Query(q): Query<PinQuery>
) -> Response {
    if !check_pin(&headers, q.pin.as_deref(), None, &st.cfg) { return err(401, "Unauthorized"); }

    let rows = Db::new(&st.http, &st.cfg).get_recent_rows().await;

    let mut last:   HashMap<String, Value>  = HashMap::new();
    let mut sender: HashMap<String, String> = HashMap::new();
    let mut with_customer: std::collections::HashSet<String> = Default::default();

    for r in &rows {
        let sid = r["session_id"].as_str().unwrap_or("").to_string();
        let snd = r["sender"].as_str().unwrap_or("").to_string();
        last.entry(sid.clone()).or_insert_with(|| r.clone());
        sender.entry(sid.clone()).or_insert_with(|| snd.clone());
        if snd == "customer" { with_customer.insert(sid); }
    }

    let names  = st.session_names.read().await;
    let online: std::collections::HashSet<_> = st.session_bus.iter().map(|e| e.key().clone()).collect();

    let mut sessions: Vec<Value> = last.into_iter()
        .filter(|(sid, _)| with_customer.contains(sid))
        .map(|(sid, row)| {
            let unanswered = sender.get(&sid).map(|s| s == "customer").unwrap_or(false);
            let name = names.get(&sid).cloned().unwrap_or_else(|| format!("{}…", trunc(&sid, 14)));
            let msg  = row["message"].as_str().unwrap_or("");
            json!({
                "session_id":   sid,
                "name":         name,
                "last_message": trunc(msg, 60),
                "last_sender":  row["sender"].as_str().unwrap_or(""),
                "unanswered":   unanswered,
                "created_at":   row["created_at"].as_str().unwrap_or(""),
                "online":       online.contains(&sid),
            })
        }).collect();

    sessions.sort_by(|a, b| {
        let ua = a["unanswered"].as_bool().unwrap_or(false);
        let ub = b["unanswered"].as_bool().unwrap_or(false);
        let ca = a["created_at"].as_str().unwrap_or("");
        let cb = b["created_at"].as_str().unwrap_or("");
        ub.cmp(&ua).then(cb.cmp(ca))
    });
    sessions.truncate(50);
    Json(sessions).into_response()
}

// POST /api/chat/set-name
#[derive(Deserialize)]
struct NameBody { session_id: Option<String>, name: Option<String> }
async fn rest_set_name(State(st): State<AppState>, Json(b): Json<NameBody>) -> Response {
    let sid  = b.session_id.as_deref().unwrap_or("").trim().to_string();
    let name = b.name.as_deref().unwrap_or("").trim().to_string();
    if !sid.is_empty() && !name.is_empty() && sid.len() <= MAX_SESSION_LEN {
        upsert_name(&st.session_names, &sid, &name).await;
    }
    ok()
}

// DELETE /api/chat/sessions/:session_id
async fn rest_delete_session(
    Path(sid): Path<String>, State(st): State<AppState>,
    headers: HeaderMap, Query(q): Query<PinQuery>
) -> Response {
    if !check_pin(&headers, q.pin.as_deref(), None, &st.cfg) { return err(401, "Unauthorized"); }
    if sid.len() > MAX_SESSION_LEN { return err(400, "Invalid session"); }
    let deleted = Db::new(&st.http, &st.cfg).delete_session(&sid).await;
    Json(json!({"ok": true, "deleted": deleted})).into_response()
}

// PATCH /api/chat/message/:msg_id
#[derive(Deserialize)]
struct EditBody { text: Option<String>, pin: Option<String> }
async fn rest_edit(
    Path(msg_id): Path<String>, State(st): State<AppState>,
    headers: HeaderMap, Json(b): Json<EditBody>
) -> Response {
    if !check_pin(&headers, None, b.pin.as_deref(), &st.cfg) { return err(401, "Unauthorized"); }
    let new_text = b.text.as_deref().unwrap_or("").trim().to_string();
    if new_text.is_empty() || new_text.len() > MAX_MESSAGE_LEN { return err(400, "Invalid text"); }

    let db  = Db::new(&st.http, &st.cfg);
    let msg = match db.get_message(&msg_id).await {
        Some(m) => m,
        None    => return err(404, "Message not found"),
    };
    let sender = msg["sender"].as_str().unwrap_or("");
    if sender != "support" && sender != "bot" { return err(403, "Can only edit support messages"); }

    let sid = msg["session_id"].as_str().unwrap_or("").to_string();
    if !db.update_message(&msg_id, &new_text).await { return err(500, "DB update failed"); }

    bcast_session(&st.session_bus, &sid, &json!({
        "type":"message_edited","msg_id":msg_id,"text":new_text
    }));
    bcast_admins(&st.admin_tx, &json!({
        "type":"message_edited","msg_id":msg_id,"session_id":sid,"text":new_text
    }));

    if sid.starts_with("tg_") {
        let cid = sid[3..].to_string();
        if let Some(tg_id) = db.get_tg_msg_id(&msg_id).await {
            let (h2, token, txt) = (st.http.clone(), st.cfg.telegram_token.clone(), new_text.clone());
            tokio::spawn(async move { tg_edit(&h2, &token, &cid, tg_id, &txt).await; });
        }
    }
    ok()
}

// GET /health
async fn health() -> impl IntoResponse {
    Json(json!({"status":"ok","service":"chat_ws"}))
}

// ─────────────────────────────────────────────────────────────────────────────
// RESPONSE HELPERS
// ─────────────────────────────────────────────────────────────────────────────
fn ok() -> Response { Json(json!({"ok":true})).into_response() }
fn err(code: u16, msg: &str) -> Response {
    (StatusCode::from_u16(code).unwrap_or(StatusCode::BAD_REQUEST),
     Json(json!({"error":msg}))).into_response()
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────
#[tokio::main]
async fn main() -> Result<()> {
    dotenvy::dotenv().ok();

    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("chat_ws=info".parse().unwrap()),
        )
        .init();

    let cfg  = Arc::new(Config::from_env());
    let port: u16 = std::env::var("CHAT_WS_PORT")
        .ok().and_then(|v| v.parse().ok()).unwrap_or(8765);

    let http = reqwest::Client::builder()
        .timeout(Duration::from_secs(30))
        .pool_max_idle_per_host(20)
        .build()
        .context("HTTP client build failed")?;

    let (admin_tx, _) = broadcast::channel::<String>(256);
    let admin_tx      = Arc::new(admin_tx);

    let state = AppState {
        session_bus:   Arc::new(DashMap::new()),
        admin_tx,
        session_names: Arc::new(RwLock::new(HashMap::new())),
        http,
        cfg,
    };

    let cors = CorsLayer::new()
        .allow_origin([
            "https://lakshmimotorcyclespares.in".parse::<axum::http::HeaderValue>().unwrap(),
            "https://www.lakshmimotorcyclespares.in".parse().unwrap(),
            "http://localhost:5000".parse().unwrap(),
            "http://127.0.0.1:5000".parse().unwrap(),
            "http://192.168.0.108:5000".parse().unwrap(),
        ])
        .allow_methods([Method::GET, Method::POST, Method::PATCH, Method::DELETE, Method::OPTIONS])
        .allow_headers(tower_http::cors::Any);

    let app = Router::new()
        .route("/ws/chat/admin",                 get(ws_admin_upgrade))
        .route("/ws/chat/:session_id",           get(ws_customer_upgrade))
        .route("/api/chat/send",                 post(rest_send))
        .route("/api/chat/reply",                post(rest_reply))
        .route("/api/chat/sessions",             get(rest_sessions))
        .route("/api/chat/set-name",             post(rest_set_name))
        .route("/api/chat/messages/:session_id", get(rest_messages))
        .route("/api/chat/sessions/:session_id", delete(rest_delete_session))
        .route("/api/chat/message/:msg_id",      patch(rest_edit))
        .route("/health",                        get(health))
        .layer(cors)
        .layer(RequestBodyLimitLayer::new(2 * 1024 * 1024))
        .with_state(state);

    let addr = std::net::SocketAddr::from(([0, 0, 0, 0], port));
    info!("🚀 chat_ws :{} — WS + REST chat sidecar", port);

    let listener = tokio::net::TcpListener::bind(addr).await
        .context("TCP bind failed")?;
    axum::serve(listener, app).await
        .context("axum serve failed")?;

    Ok(())
}
