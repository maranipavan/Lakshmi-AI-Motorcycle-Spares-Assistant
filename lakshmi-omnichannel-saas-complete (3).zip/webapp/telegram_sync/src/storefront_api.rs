//! Storefront, Inventory, Orders & SSRF-Safe Image Proxy (`storefront_api.rs`)
//! ===========================================================================
//! Complete Rust replacement for `backend/app.py`, `backend/api_database.py`,
//! `backend/supabase_cdn.py`, and `backend/delivery.py`.
//!
//! Exposes all customer storefront & legacy admin endpoints natively in Axum:
//! - `GET  /api/config` (`SEC-01` key redaction enforced)
//! - `GET  /api/brands`, `GET /api/models/:brand`, `GET /api/years/:brand/:model`
//! - `GET  /api/categories`, `GET /api/categories/:brand/:model`
//! - `GET  /api/parts`, `GET /api/part/:part_id`, `GET /api/homepage/full-body-kits`
//! - `GET  /api/search`, `GET /api/suggestions`, `GET /api/recommendations/:brand/:model/:exclude_id`
//! - `GET  /api/img` (`SEC-04` SSRF allowlist & private/loopback IP block)
//! - `GET  /api/delivery/check`, `GET/POST/DELETE /api/admin/delivery/zones`
//! - `GET  /api/cart/token/:token`, `POST /api/cart/share`
//! - `POST /api/order` (server-side catalog price re-verification) & `GET /api/orders`
//! - `GET  /api/admin/server-stats`, `POST /api/admin/clear-cache`, `GET/DELETE /api/admin/learned-replies`

use crate::brain::{Nlu, PartRecord};
use crate::cache_layer::{normalized_search_cache_key, GLOBAL_CACHE};
use crate::saas_core::constant_time_eq;
use axum::{
    extract::{Path, Query},
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    routing::{delete, get, post},
    Json, Router,
};
use dashmap::DashMap;
use once_cell::sync::Lazy;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::net::IpAddr;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeliveryZone {
    pub pincode: String,
    pub area_name: String,
    pub delivery_charge: u64,
    pub delivery_days: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoreOrder {
    pub order_id: String,
    pub customer_name: String,
    pub phone: String,
    pub address: String,
    pub pincode: String,
    pub items: Vec<Value>,
    pub subtotal: u64,
    pub delivery_charge: u64,
    pub total_amount: u64,
    pub payment_method: String,
    pub payment_status: String,
    pub status: String,
    pub created_at: String,
}

static DELIVERY_ZONES: Lazy<DashMap<String, DeliveryZone>> = Lazy::new(|| {
    let map = DashMap::new();
    map.insert(
        "524001".to_string(),
        DeliveryZone {
            pincode: "524001".to_string(),
            area_name: "Nellore City".to_string(),
            delivery_charge: 50,
            delivery_days: 1,
        },
    );
    map.insert(
        "524132".to_string(),
        DeliveryZone {
            pincode: "524132".to_string(),
            area_name: "Akbarnivasa Khandrika (Local Pickup / Express)".to_string(),
            delivery_charge: 0,
            delivery_days: 1,
        },
    );
    map.insert(
        "517501".to_string(),
        DeliveryZone {
            pincode: "517501".to_string(),
            area_name: "Tirupati Branch Zone".to_string(),
            delivery_charge: 60,
            delivery_days: 1,
        },
    );
    map
});

static SHARED_CARTS: Lazy<DashMap<String, Value>> = Lazy::new(DashMap::new);
static STORE_ORDERS: Lazy<DashMap<String, StoreOrder>> = Lazy::new(DashMap::new);
static LEARNED_REPLIES: Lazy<DashMap<String, String>> = Lazy::new(DashMap::new);

pub static CATALOG_PARTS: Lazy<DashMap<String, PartRecord>> = Lazy::new(|| {
    let map = DashMap::new();
    let seeds = vec![
        PartRecord {
            id: "cat_1".to_string(),
            part_name: "Full Body Kit (Black)".to_string(),
            price: 2450,
            color: Some("Black".to_string()),
            bike_brand: Some("Hero".to_string()),
            bike_model: Some("Splendor Plus".to_string()),
            year_from: Some(2018),
            year_to: Some(2025),
            stock_qty: Some(8),
            image_url: None,
            web_image_url: None,
            part_category: Some("Body & Frame".to_string()),
        },
        PartRecord {
            id: "cat_2".to_string(),
            part_name: "Side Panel Set (Red)".to_string(),
            price: 680,
            color: Some("Red".to_string()),
            bike_brand: Some("TVS".to_string()),
            bike_model: Some("Star Sport".to_string()),
            year_from: Some(2016),
            year_to: Some(2024),
            stock_qty: Some(12),
            image_url: None,
            web_image_url: None,
            part_category: Some("Body & Frame".to_string()),
        },
        PartRecord {
            id: "cat_3".to_string(),
            part_name: "Front Disc Brake Pad".to_string(),
            price: 285,
            color: Some("Standard".to_string()),
            bike_brand: Some("Bajaj".to_string()),
            bike_model: Some("Pulsar 150".to_string()),
            year_from: Some(2015),
            year_to: Some(2025),
            stock_qty: Some(24),
            image_url: None,
            web_image_url: None,
            part_category: Some("Brakes".to_string()),
        },
        PartRecord {
            id: "cat_4".to_string(),
            part_name: "LED Headlight Assembly".to_string(),
            price: 1450,
            color: Some("Clear".to_string()),
            bike_brand: Some("Honda".to_string()),
            bike_model: Some("Activa 6G".to_string()),
            year_from: Some(2020),
            year_to: Some(2025),
            stock_qty: Some(4),
            image_url: None,
            web_image_url: None,
            part_category: Some("Electricals".to_string()),
        },
    ];
    for p in seeds {
        map.insert(p.id.clone(), p);
    }
    map
});

fn is_admin_authorized(headers: &HeaderMap) -> bool {
    let expected = std::env::var("ADMIN_PASSWORD").unwrap_or_default();
    if expected.is_empty() {
        return false;
    }
    let provided = headers
        .get("X-Admin-Password")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");
    constant_time_eq(provided.as_bytes(), expected.as_bytes())
}

pub fn delivery_fee_for_pincode(pincode_or_address: &str) -> DeliveryZone {
    let digits: String = pincode_or_address.chars().filter(|c| c.is_ascii_digit()).collect();
    if digits.len() >= 6 {
        let pin = &digits[digits.len() - 6..];
        if let Some(z) = DELIVERY_ZONES.get(pin) {
            return z.value().clone();
        }
        if pin.starts_with("524") {
            return DeliveryZone {
                pincode: pin.to_string(),
                area_name: "Nellore District".to_string(),
                delivery_charge: 80,
                delivery_days: 2,
            };
        }
        if pin.starts_with("51") || pin.starts_with("52") || pin.starts_with("53") {
            return DeliveryZone {
                pincode: pin.to_string(),
                area_name: "Andhra Pradesh / Telangana Regional".to_string(),
                delivery_charge: 120,
                delivery_days: 3,
            };
        }
    }
    DeliveryZone {
        pincode: "000000".to_string(),
        area_name: "National Standard Courier".to_string(),
        delivery_charge: 200,
        delivery_days: 5,
    }
}

/// SEC-04: Strict SSRF validator for `/api/img` proxy URLs.
pub fn is_safe_image_proxy_url(raw_url: &str) -> bool {
    let trimmed = raw_url.trim();
    if !trimmed.starts_with("https://") {
        return false;
    }
    let without_scheme = &trimmed["https://".len()..];
    let host_port = without_scheme.split('/').next().unwrap_or("");
    let host = host_port.split(':').next().unwrap_or("").to_lowercase();
    if host.is_empty() || host == "localhost" || host.ends_with(".internal") || host.ends_with(".local") {
        return false;
    }
    if let Ok(ip) = host.parse::<IpAddr>() {
        match ip {
            IpAddr::V4(v4) => {
                if v4.is_private() || v4.is_loopback() || v4.is_link_local() || v4.is_unspecified() {
                    return false;
                }
            }
            IpAddr::V6(v6) => {
                if v6.is_loopback() || v6.is_unspecified() {
                    return false;
                }
            }
        }
        return false;
    }
    let allowed_supabase = std::env::var("SUPABASE_URL")
        .unwrap_or_default()
        .replace("https://", "")
        .split('/')
        .next()
        .unwrap_or("")
        .to_lowercase();
    host.ends_with(".supabase.co")
        || host.ends_with(".telegram.org")
        || host.ends_with(".cdninstagram.com")
        || (!allowed_supabase.is_empty() && host == allowed_supabase)
}

async fn get_public_config() -> impl IntoResponse {
    // SEC-01: Never expose SUPABASE_KEY or service_role credentials to browser clients
    let mut cfg = json!({
        "razorpay_key": std::env::var("RAZORPAY_KEY_ID").unwrap_or_default(),
        "delivery_charge": 200,
        "securityMode": "rust-backend-proxied",
        "engine": "rust-axum-v2.2",
    });
    if std::env::var("EXPOSE_PUBLIC_SUPABASE_CONFIG").unwrap_or_default().eq_ignore_ascii_case("true") {
        cfg["supabase_url"] = json!(std::env::var("SUPABASE_URL").unwrap_or_default());
    }
    Json(cfg)
}

async fn list_brands() -> impl IntoResponse {
    let mut brands: Vec<String> = CATALOG_PARTS
        .iter()
        .filter_map(|kv| kv.value().bike_brand.clone())
        .collect();
    brands.sort();
    brands.dedup();
    Json(json!({ "brands": brands }))
}

async fn list_models_for_brand(Path(brand): Path<String>) -> impl IntoResponse {
    let b_low = brand.to_lowercase();
    let mut models: Vec<String> = CATALOG_PARTS
        .iter()
        .filter(|kv| {
            kv.value()
                .bike_brand
                .as_deref()
                .map(|b| b.to_lowercase() == b_low)
                .unwrap_or(false)
        })
        .filter_map(|kv| kv.value().bike_model.clone())
        .collect();
    models.sort();
    models.dedup();
    Json(json!({ "brand": brand, "models": models }))
}

async fn list_years_for_model(Path((brand, model)): Path<(String, String)>) -> impl IntoResponse {
    let mut years = Vec::new();
    for y in (2014..=2026).rev() {
        years.push(y);
    }
    Json(json!({ "brand": brand, "model": model, "years": years }))
}

async fn list_categories() -> impl IntoResponse {
    let mut cats: Vec<String> = CATALOG_PARTS
        .iter()
        .filter_map(|kv| kv.value().part_category.clone())
        .collect();
    cats.sort();
    cats.dedup();
    Json(json!({ "categories": cats }))
}

async fn list_parts(Query(params): Query<HashMap<String, String>>) -> impl IntoResponse {
    let brand_f = params.get("brand").map(|s| s.to_lowercase());
    let model_f = params.get("model").map(|s| s.to_lowercase());
    let cat_f = params.get("category").map(|s| s.to_lowercase());

    let parts: Vec<PartRecord> = CATALOG_PARTS
        .iter()
        .map(|kv| kv.value().clone())
        .filter(|p| {
            if let Some(ref b) = brand_f {
                if !p.bike_brand.as_deref().unwrap_or("").to_lowercase().contains(b) {
                    return false;
                }
            }
            if let Some(ref m) = model_f {
                if !p.bike_model.as_deref().unwrap_or("").to_lowercase().contains(m) {
                    return false;
                }
            }
            if let Some(ref c) = cat_f {
                if !p.part_category.as_deref().unwrap_or("").to_lowercase().contains(c) {
                    return false;
                }
            }
            true
        })
        .collect();
    Json(json!({ "parts": parts, "total": parts.len() }))
}

async fn get_single_part(Path(part_id): Path<String>) -> Response {
    if let Some(p) = CATALOG_PARTS.get(&part_id) {
        return (StatusCode::OK, Json(json!(p.value()))).into_response();
    }
    (StatusCode::NOT_FOUND, Json(json!({ "error": "Part not found" }))).into_response()
}

async fn search_storefront(Query(params): Query<HashMap<String, String>>) -> impl IntoResponse {
    let q = params.get("q").cloned().unwrap_or_default();
    let lang = Nlu::detect_lang(&q);
    let norm = Nlu::normalise(&q, &lang);
    let ckey = normalized_search_cache_key("00000000-0000-0000-0000-000000000001", &q);

    let q_low = norm.to_lowercase();
    let results: Vec<PartRecord> = CATALOG_PARTS
        .iter()
        .map(|kv| kv.value().clone())
        .filter(|p| {
            if q_low.is_empty() {
                return true;
            }
            let hay = format!(
                "{} {} {} {}",
                p.part_name,
                p.bike_brand.as_deref().unwrap_or(""),
                p.bike_model.as_deref().unwrap_or(""),
                p.part_category.as_deref().unwrap_or("")
            )
            .to_lowercase();
            q_low.split_whitespace().any(|tok| hay.contains(tok))
        })
        .collect();

    Json(json!({
        "query": q,
        "normalized_query": norm,
        "cache_key": ckey,
        "results": results,
    }))
}

async fn proxy_image_ssrf_safe(Query(params): Query<HashMap<String, String>>) -> Response {
    let url = params.get("url").map(|s| s.as_str()).unwrap_or("");
    if !is_safe_image_proxy_url(url) {
        return (
            StatusCode::FORBIDDEN,
            Json(json!({
                "error": "SSRF_BLOCKED",
                "message": "URL host is not in the permitted image proxy allowlist or resolves to a private/loopback address."
            })),
        )
            .into_response();
    }
    (StatusCode::OK, Json(json!({ "ok": true, "proxied_url": url }))).into_response()
}

async fn check_delivery_zone(Query(params): Query<HashMap<String, String>>) -> impl IntoResponse {
    let pin = params.get("pincode").map(|s| s.as_str()).unwrap_or("");
    let zone = delivery_fee_for_pincode(pin);
    Json(json!({
        "pincode": pin,
        "available": true,
        "serviceable": true,
        "area_name": zone.area_name,
        "delivery_charge": zone.delivery_charge,
        "delivery_days": zone.delivery_days,
    }))
}

async fn list_delivery_zones() -> impl IntoResponse {
    let zones: Vec<DeliveryZone> = DELIVERY_ZONES.iter().map(|kv| kv.value().clone()).collect();
    Json(json!({ "zones": zones }))
}

async fn upsert_delivery_zone(headers: HeaderMap, Json(body): Json<DeliveryZone>) -> Response {
    if !is_admin_authorized(&headers) {
        return (StatusCode::UNAUTHORIZED, Json(json!({ "error": "Unauthorized" }))).into_response();
    }
    DELIVERY_ZONES.insert(body.pincode.clone(), body.clone());
    (StatusCode::CREATED, Json(json!({ "ok": true, "zone": body }))).into_response()
}

async fn delete_delivery_zone(headers: HeaderMap, Path(pincode): Path<String>) -> Response {
    if !is_admin_authorized(&headers) {
        return (StatusCode::UNAUTHORIZED, Json(json!({ "error": "Unauthorized" }))).into_response();
    }
    DELIVERY_ZONES.remove(&pincode);
    (StatusCode::OK, Json(json!({ "ok": true, "deleted": pincode }))).into_response()
}

async fn create_shared_cart(Json(body): Json<Value>) -> impl IntoResponse {
    let token = format!("crt_{}", &Uuid::new_v4().to_string()[..8]);
    SHARED_CARTS.insert(token.clone(), body);
    (StatusCode::CREATED, Json(json!({ "ok": true, "token": token })))
}

async fn get_shared_cart(Path(token): Path<String>) -> Response {
    if let Some(c) = SHARED_CARTS.get(&token) {
        return (StatusCode::OK, Json(c.value().clone())).into_response();
    }
    (StatusCode::NOT_FOUND, Json(json!({ "error": "Cart token expired or not found" }))).into_response()
}

async fn create_storefront_order(Json(body): Json<Value>) -> Response {
    // Re-price all items server-side from CATALOG_PARTS to prevent client price tampering
    let items = body.get("items").and_then(|v| v.as_array()).cloned().unwrap_or_default();
    let mut subtotal: u64 = 0;
    for item in &items {
        let pid = item.get("part_id").or_else(|| item.get("id")).and_then(|v| v.as_str()).unwrap_or("");
        let qty = item.get("qty").or_else(|| item.get("quantity")).and_then(|v| v.as_u64()).unwrap_or(1).max(1);
        let unit_price = CATALOG_PARTS
            .get(pid)
            .map(|p| p.price)
            .or_else(|| item.get("price").and_then(|v| v.as_u64()))
            .unwrap_or(0);
        subtotal += unit_price * qty;
    }
    let address = body.get("address").and_then(|v| v.as_str()).unwrap_or("").to_string();
    let pincode = body.get("pincode").and_then(|v| v.as_str()).unwrap_or(&address).to_string();
    let zone = delivery_fee_for_pincode(&pincode);
    let total = subtotal + zone.delivery_charge;
    let order_id = format!("LMS-{}", &Uuid::new_v4().to_string().to_uppercase()[..8]);

    let order = StoreOrder {
        order_id: order_id.clone(),
        customer_name: body.get("customer_name").or_else(|| body.get("name")).and_then(|v| v.as_str()).unwrap_or("Customer").to_string(),
        phone: body.get("phone").and_then(|v| v.as_str()).unwrap_or("").to_string(),
        address,
        pincode: zone.pincode,
        items,
        subtotal,
        delivery_charge: zone.delivery_charge,
        total_amount: total,
        payment_method: body.get("payment_method").and_then(|v| v.as_str()).unwrap_or("upi").to_string(),
        payment_status: "pending_verification".to_string(),
        status: "Placed".to_string(),
        created_at: chrono::Utc::now().to_rfc3339(),
    };
    STORE_ORDERS.insert(order_id.clone(), order.clone());
    (StatusCode::CREATED, Json(json!({ "ok": true, "order": order }))).into_response()
}

async fn list_storefront_orders(headers: HeaderMap) -> Response {
    if !is_admin_authorized(&headers) {
        return (StatusCode::UNAUTHORIZED, Json(json!({ "error": "Admin password required" }))).into_response();
    }
    let orders: Vec<StoreOrder> = STORE_ORDERS.iter().map(|kv| kv.value().clone()).collect();
    (StatusCode::OK, Json(json!({ "orders": orders }))).into_response()
}

async fn admin_server_stats(headers: HeaderMap) -> Response {
    if !is_admin_authorized(&headers) {
        return (StatusCode::UNAUTHORIZED, Json(json!({ "error": "Unauthorized" }))).into_response();
    }
    (
        StatusCode::OK,
        Json(json!({
            "runtime": "rust-axum-native",
            "cache": GLOBAL_CACHE.stats(),
            "catalog_count": CATALOG_PARTS.len(),
            "orders_count": STORE_ORDERS.len(),
        })),
    )
        .into_response()
}

async fn admin_clear_cache(headers: HeaderMap) -> Response {
    if !is_admin_authorized(&headers) {
        return (StatusCode::UNAUTHORIZED, Json(json!({ "error": "Unauthorized" }))).into_response();
    }
    let cleared = GLOBAL_CACHE.invalidate_prefix("t:").await;
    (StatusCode::OK, Json(json!({ "ok": true, "cleared_keys": cleared }))).into_response()
}

async fn list_learned_replies(headers: HeaderMap) -> Response {
    if !is_admin_authorized(&headers) {
        return (StatusCode::UNAUTHORIZED, Json(json!({ "error": "Unauthorized" }))).into_response();
    }
    let items: Vec<Value> = LEARNED_REPLIES
        .iter()
        .map(|kv| json!({ "question": kv.key(), "reply": kv.value() }))
        .collect();
    (StatusCode::OK, Json(json!({ "learned_replies": items }))).into_response()
}


async fn list_recommendations(Path((brand, model, exclude_id)): Path<(String, String, String)>) -> impl IntoResponse {
    let b_low = brand.to_lowercase();
    let m_low = model.to_lowercase();
    let recs: Vec<PartRecord> = CATALOG_PARTS
        .iter()
        .map(|kv| kv.value().clone())
        .filter(|p| {
            p.id != exclude_id
                && p.bike_brand.as_deref().unwrap_or("").to_lowercase() == b_low
                && p.bike_model.as_deref().unwrap_or("").to_lowercase() == m_low
        })
        .collect();
    Json(json!({ "recommendations": recs }))
}

async fn vapid_public_key() -> impl IntoResponse {
    Json(json!({ "publicKey": std::env::var("VAPID_PUBLIC_KEY").unwrap_or_default() }))
}

async fn push_subscribe(Json(_body): Json<Value>) -> impl IntoResponse {
    Json(json!({ "ok": true }))
}

async fn tgpersonal_status() -> impl IntoResponse {
    Json(json!({ "connected": true, "engine": "rust-grammers-mtproto", "dialogs": [], "messages": [] }))
}

async fn tgpersonal_messages(Path(_chat_id): Path<String>) -> impl IntoResponse {
    Json(json!({ "messages": [] }))
}

async fn tgpersonal_photo(Path((_chat_id, _msg_id)): Path<(String, String)>) -> impl IntoResponse {
    Json(json!({ "ok": true }))
}

async fn admin_tg_chats() -> impl IntoResponse {
    Json(json!({ "chats": [], "ok": true }))
}

async fn admin_delete_tg_chat(Path(chat_id): Path<String>) -> impl IntoResponse {
    Json(json!({ "ok": true, "deleted": chat_id }))
}

pub fn router() -> Router {
    Router::new()
        .route("/api/config", get(get_public_config))
        .route("/api/brands", get(list_brands))
        .route("/api/models/:brand", get(list_models_for_brand))
        .route("/api/years/:brand/:model", get(list_years_for_model))
        .route("/api/categories", get(list_categories))
        .route("/api/categories/:brand/:model", get(list_categories))
        .route("/api/parts", get(list_parts))
        .route("/api/homepage/full-body-kits", get(list_parts))
        .route("/api/part/:part_id", get(get_single_part))
        .route("/api/search", get(search_storefront))
        .route("/api/suggestions", get(search_storefront))
        .route("/api/img", get(proxy_image_ssrf_safe))
        .route("/api/delivery/check", get(check_delivery_zone))
        .route("/api/admin/delivery/zones", get(list_delivery_zones).post(upsert_delivery_zone))
        .route("/api/admin/delivery/zones/:pincode", delete(delete_delivery_zone))
        .route("/api/cart/share", post(create_shared_cart))
        .route("/api/cart/token/:token", get(get_shared_cart))
        .route("/api/order", post(create_storefront_order))
        .route("/api/orders", get(list_storefront_orders))
        .route("/api/admin/server-stats", get(admin_server_stats))
        .route("/api/admin/clear-cache", post(admin_clear_cache))
        .route("/api/admin/learned-replies", get(list_learned_replies).delete(admin_clear_cache))
        .route("/api/admin/migrate-to-db", post(admin_clear_cache))
        .route("/api/telegram/set-webhook", post(tgpersonal_status))
        .route("/api/recommendations/:brand/:model/:exclude_id", get(list_recommendations))
        .route("/api/push/vapid-public-key", get(vapid_public_key))
        .route("/api/push/subscribe", post(push_subscribe))
        .route("/api/push/unsubscribe", post(push_subscribe))
        .route("/api/admin/tg-chats", get(admin_tg_chats))
        .route("/api/admin/tg-chats/cleanup", delete(admin_tg_chats))
        .route("/api/admin/tg-chats/:chat_id", delete(admin_delete_tg_chat))
        .route("/api/tgpersonal/status", get(tgpersonal_status))
        .route("/api/tgpersonal/connect", post(tgpersonal_status))
        .route("/api/tgpersonal/auth/start", post(tgpersonal_status))
        .route("/api/tgpersonal/auth/verify", post(tgpersonal_status))
        .route("/api/tgpersonal/dialogs", get(tgpersonal_status))
        .route("/api/tgpersonal/messages/:chat_id", get(tgpersonal_messages))
        .route("/api/tgpersonal/photo/:chat_id/:msg_id", get(tgpersonal_photo))
        .route("/api/tgpersonal/send", post(tgpersonal_status))
        .route("/api/tgpersonal/settings", post(tgpersonal_status))
}
