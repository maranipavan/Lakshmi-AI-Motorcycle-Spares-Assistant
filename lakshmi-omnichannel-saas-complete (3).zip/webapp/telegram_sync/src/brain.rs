//! brain.rs — Lakshmi Bot Conversational Brain (Pure Rust, No External LLM)
//!
//! Architecture:
//!   1. ConversationMemory  — per-customer context stored in Redis (bike, parts asked,
//!                            conversation turns, pending questions, price accumulator)
//!   2. NLU Pipeline        — tokenise → normalise → detect language → extract intent
//!                            + entities (brand, model, year, part, colour, quantity)
//!   3. DialogueManager     — state machine that decides next action based on intent
//!                            + memory, runs follow-up queries until answer is complete
//!   4. ResponseBuilder     — fills Telugu/Hinglish/English templates dynamically,
//!                            computes price totals, generates clarifying questions
//!   5. LearningStore       — writes every (customer_text → bot_reply) pair to Redis
//!                            stream so they can be reviewed and fed back later
//!
//! Redis keys used:
//!   brain:ctx:{session_id}   — ConversationMemory (JSON, TTL 4 h)
//!   brain:learn              — Redis stream of (input, reply, timestamp) pairs
//!   brain:synonyms           — Hash of learned synonyms (wrong → correct)
//!
//! Integration:
//!   Call `Brain::process(session_id, customer_text, db_client)` from tg_bot.rs
//!   instead of delegating to Python /internal/tg-text.
//!   Returns `BrainReply { text, keyboard, confidence }`.

use std::collections::HashMap;
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};

use redis::AsyncCommands;
use serde::{Deserialize, Serialize};

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────

/// Everything the brain knows about a customer mid-conversation.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ConversationMemory {
    // Bike context (persists across turns)
    pub brand:  String,
    pub model:  String,
    pub year:   String,
    pub colour: String,

    // What parts they have asked about this session
    pub parts_asked: Vec<String>,

    // Accumulated price quote (part_name → price_rupees)
    pub price_quote: HashMap<String, u64>,

    // Pending clarification: what question did bot ask last?
    pub pending_question: Option<PendingQuestion>,

    // Last bot reply (for recall: "repeat that" / "phir bolo")
    pub last_reply: String,

    // Dialogue turns this session
    pub turn_count: u32,

    // Language preference detected
    pub lang: Language,

    // Customer name (from /start or order flow)
    pub customer_name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
pub enum Language {
    #[default]
    Telugu,
    Hinglish,
    English,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PendingQuestion {
    pub kind: PendingKind,
    pub context: String, // extra data (e.g. part name user asked before we knew the bike)
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum PendingKind {
    NeedBrand,
    NeedModel,
    NeedYear,
    NeedColour,
    NeedPartName,
    NeedQuantity,
    ConfirmPart(String), // confirm which part among suggestions
}

/// Structured understanding of a single customer message.
#[derive(Debug, Default)]
pub struct Intent {
    pub kind:     IntentKind,
    pub brand:    Option<String>,
    pub model:    Option<String>,
    pub year:     Option<String>,
    pub colour:   Option<String>,
    pub parts:    Vec<String>,    // extracted part names
    pub quantity: Option<u32>,
    pub raw_norm: String,         // normalised input after stripping noise
}

#[derive(Debug, Default, PartialEq)]
pub enum IntentKind {
    #[default]
    Unknown,
    Greeting,
    PartSearch,
    ListParts,
    PriceQuery,
    StockQuery,
    OrderIntent,
    CartQuery,
    LocationQuery,
    HoursQuery,
    ContactQuery,
    PaymentQuery,
    DeliveryQuery,
    TrackOrder,
    HumanHandoff,
    Reset,
    Thanks,
    Goodbye,
    Yes,
    No,
    Repeat,      // "repeat that" / "phir bolo" / "meeru cheppindi enti"
    PriceTotal,  // "total enta" / "sum cheppu"
}

/// What the brain sends back to tg_bot.rs
#[derive(Debug)]
pub struct BrainReply {
    pub text:       String,
    pub keyboard:   Option<serde_json::Value>, // inline keyboard JSON if needed
    pub confidence: f32,                       // 0.0 – 1.0
    pub save_chat:  bool,                      // whether to persist to chat_messages
}

/// A part record returned from your parts DB (via Supabase REST call).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PartRecord {
    pub id:            String,
    pub part_name:     String,           // DB: part_name   (not "name")
    pub price:         u64,
    pub color:         Option<String>,   // DB: color       (not "colour")
    pub bike_brand:    Option<String>,
    pub bike_model:    Option<String>,
    pub year_from:     Option<i32>,      // DB: year_from   (not "bike_year")
    pub year_to:       Option<i32>,      // DB: year_to
    pub stock_qty:     Option<i32>,      // DB: stock_qty   (not "in_stock")
    pub image_url:     Option<String>,
    pub web_image_url: Option<String>,
    pub part_category: Option<String>,
}

impl PartRecord {
    pub fn in_stock(&self)     -> bool  { self.stock_qty.unwrap_or(0) > 0 }
    pub fn display_name(&self) -> &str  { &self.part_name }
    pub fn colour(&self)       -> Option<&str> { self.color.as_deref() }
    pub fn year_range(&self)   -> String {
        match (self.year_from, self.year_to) {
            (Some(f), Some(t)) if f == t => f.to_string(),
            (Some(f), Some(t))           => format!("{f}–{t}"),
            (Some(f), None)              => format!("{f}+"),
            _                            => String::new(),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// STATIC KNOWLEDGE — compiled in, zero RAM overhead at runtime
// ─────────────────────────────────────────────────────────────────────────────

/// All known bike brands (lowercase)
const BRANDS: &[&str] = &[
    "hero", "honda", "bajaj", "tvs", "yamaha", "suzuki",
    "royal enfield", "mahindra", "ktm", "triumph", "jawa",
];

/// Brand → canonical name mapping (handles misspellings)
const BRAND_ALIASES: &[(&str, &str)] = &[
    ("hiro", "hero"), ("hreo", "hero"), ("heroo", "hero"),
    ("honnda", "honda"), ("handa", "honda"), ("hundai", "honda"),
    ("bajjaj", "bajaj"), ("bajjj", "bajaj"), ("babaj", "bajaj"),
    ("yamha", "yamaha"), ("yammaha", "yamaha"),
    ("suzki", "suzuki"), ("suzuku", "suzuki"),
    ("enfield", "royal enfield"),
    // NOTE: "re" and "bullet" removed as aliases — "re" matches inside common words
    // like "price", "entha re", "address" causing false Royal Enfield detection.
    // Use explicit "royal enfield" or model names (bullet 350, classic 350) instead.
    ("re350", "royal enfield"), ("re 350", "royal enfield"),
    ("bullet", "royal enfield"),
];

/// Model → brand mapping
const MODEL_BRAND: &[(&str, &str)] = &[
    // Hero
    ("splendor", "hero"), ("splendor plus", "hero"), ("splendor pro", "hero"),
    ("passion", "hero"), ("passion pro", "hero"), ("passion plus", "hero"),
    ("glamour", "hero"), ("hf deluxe", "hero"), ("hf", "hero"),
    ("cbz", "hero"), ("cbz xtreme", "hero"), ("xtreme", "hero"),
    ("cd 100", "hero"), ("cd100", "hero"), ("cd100ss", "hero"), ("cd 100 ss", "hero"),
    ("cd dawn", "hero"), ("karizma", "hero"), ("ignitor", "hero"),
    // Honda
    ("shine", "honda"), ("activa", "honda"), ("unicorn", "honda"),
    ("hornet", "honda"), ("livo", "honda"), ("dream", "honda"),
    ("sp125", "honda"), ("cb shine", "honda"), ("dio", "honda"),
    ("cb unicorn", "honda"), ("cb hornet", "honda"),
    // Bajaj
    ("pulsar", "bajaj"), ("pulsar 150", "bajaj"), ("pulsar 180", "bajaj"),
    ("pulsar 220", "bajaj"), ("avenger", "bajaj"), ("discover", "bajaj"),
    ("platina", "bajaj"), ("ct 100", "bajaj"), ("ct100", "bajaj"),
    ("dominar", "bajaj"), ("ns200", "bajaj"),
    // TVS
    ("apache", "tvs"), ("jupiter", "tvs"), ("ntorq", "tvs"),
    ("star city", "tvs"), ("sport", "tvs"), ("victor", "tvs"),
    ("radeon", "tvs"),
    // Yamaha
    ("fz", "yamaha"), ("fzs", "yamaha"), ("fz-s", "yamaha"),
    ("r15", "yamaha"), ("mt15", "yamaha"), ("mt-15", "yamaha"),
    ("fascino", "yamaha"), ("ray", "yamaha"), ("saluto", "yamaha"),
    ("yzf", "yamaha"), ("fz v1", "yamaha"), ("fz v2", "yamaha"), ("fz v3", "yamaha"),
    // Suzuki
    ("access", "suzuki"), ("burgman", "suzuki"), ("gixxer", "suzuki"),
    ("samurai", "suzuki"), ("hayate", "suzuki"),
    // Royal Enfield
    ("bullet 350", "royal enfield"), ("classic 350", "royal enfield"),
    ("meteor", "royal enfield"), ("hunter", "royal enfield"),
    ("thunderbird", "royal enfield"), ("himalayan", "royal enfield"),
    // Yamaha extra
    ("rx 135", "yamaha"), ("rx135", "yamaha"), ("rx100", "yamaha"),
    ("rx 100", "yamaha"), ("rd 350", "yamaha"), ("ybr", "yamaha"),
    ("fazer", "yamaha"), ("szr", "yamaha"),
    // TVS extra
    ("xl 100", "tvs"), ("xl100", "tvs"), ("max 100", "tvs"),
    ("champ", "tvs"), ("scooty", "tvs"), ("wego", "tvs"),
    ("apache rtr", "tvs"), ("apache 160", "tvs"), ("apache 180", "tvs"),
    ("apache 200", "tvs"),
    // Hero extra
    ("passion xpro", "hero"), ("hunk", "hero"), ("achiever", "hero"),
    ("maestro", "hero"), ("pleasure", "hero"), ("duet", "hero"),
    ("destini", "hero"), ("xpulse", "hero"), ("xtec", "hero"),
    // Honda extra
    ("cbr", "honda"), ("cb300", "honda"), ("grazia", "honda"),
    ("cliq", "honda"), ("navi", "honda"),
    // Bajaj extra
    ("boxer", "bajaj"), ("wind", "bajaj"), ("kb100", "bajaj"),
    ("m80", "bajaj"), ("caliber", "bajaj"), ("eliminator", "bajaj"),
    // Suzuki extra
    ("max 100r", "suzuki"), ("fiero", "suzuki"), ("heat", "suzuki"),
    // Hero Honda (old brand)
    ("hero honda", "hero"), ("cd 100", "hero"), ("cd100", "hero"),
    ("sleek", "hero"), ("street", "hero"),
    // Mahindra
    ("centuro", "mahindra"), ("mojo", "mahindra"), ("gusto", "mahindra"),
];

/// Telugu noise words to strip before NLU
const TELUGU_NOISE: &[&str] = &[
    "kavali", "cheppandi", "cheppu", "cheppara", "cheptara",
    "undi", "undaya", "unnaya", "unnai", "untaya", "untai", "untundi",
    "ledu", "oka", "rendu", "naaku", "meeku", "meeru", "meru",
    "ayya", "anna", "akka", "amma", "bro", "garu",
    "dorikutunda", "dorukutunda", "enta", "entha", "ela",
    "stock lo", "spare parts", "spares",
    "price", "cost", "rate", "enta avutundi", "enta untundi",
    "emiti", "emi", "em", "evaru",
    "ani", "ante", "antav", "antaru", "ledha", "leda",
    "anni", "anni parts", "anni partslu",
    "naku", "nakku", "maku", "meeru", "miru",
    "cheyali", "cheyandi", "cheyyi",
    "total", "ki", "lo", "tho", "to", "lo unna",
    "restore", "cheyali na", "avuthadi",
    "sare", "okay", "ok bro", "ok anna",
];

/// Hindi/Hinglish noise words
const HINDI_NOISE: &[&str] = &[
    "hai", "kya", "mujhe", "chahiye", "milega", "milegi",
    "kitna", "kitne", "bhai", "yaar", "nahi", "nahin",
    "haan", "theek", "acha", "accha", "bata", "dena",
    "do you have", "i need", "i want", "can i get",
    "available", "please", "pls", "plz",
];

/// English noise words
const ENGLISH_NOISE: &[&str] = &[
    "do you have", "is there", "i need", "i want", "can i get",
    "available", "please", "tell me", "show me", "give me",
    "what is", "how much", "what are",
    // Short acknowledgements and bike-variant tokens are not part names.
    "yes", "yeah", "yep", "no", "nope", "ok", "okay", "sure",
    "thanks", "thank you", "thank u", "tq", "thx", "bro", "brother",
    "bye", "goodbye", "sry", "sorry", "bs4", "bs6", "b4", "b6",
    "response", "reply",
];

/// Part name aliases (customer term → standard DB term)
const PART_ALIASES: &[(&str, &str)] = &[
    // Body
    ("body kit", "full body"), ("body set", "full body"), ("body panels", "full body"),
    ("full set", "full body"), ("full kit", "full body"), ("body", "full body"),
    ("panel", "full body"), ("panels", "full body"), ("pannel", "full body"),
    ("body pannel", "full body"), ("side panels", "full body"),
    // Tank
    ("petrol tank", "tank"), ("tank", "tank"), ("tanki", "tank"),
    ("fuel", "tank"),
    // Mudguard
    ("mudgard", "mudguard"), ("mud guard", "mudguard"), ("mudgurd", "mudguard"),
    ("front mudgard", "front mudguard"), ("back mudgard", "rear mudguard"),
    ("rear mud guard", "rear mudguard"),
    // Brakes — DB has: Brake Cable, Front Brake Shoe, Back Brake Shoe, Brake Pedal
    ("brake pad", "brake pads"), ("brake pads", "brake pads"), ("brakelu", "brake pads"),
    ("disc pad", "brake shoe"), ("disk pad", "brake shoe"), ("breaking", "brake"),
    ("brakes", "brake"), ("barke", "brake"), ("brakeu", "brake"),
    ("front brake", "front brake shoe"), ("rear brake", "back brake shoe"),
    ("back brake", "back brake shoe"),
    // Lights
    ("head light", "headlight"), ("headlamp", "headlight"), ("headlite", "headlight"),
    ("head lamp", "headlight"), ("indicator", "indicators"), ("signal light", "indicators"),
    ("signal", "indicators"), ("blinker", "indicators"),
    ("tail light", "tail lamp"), ("back light", "tail lamp"),
    // Engine
    ("engine oil", "engine oil"), ("oil", "engine oil"), ("oilu", "engine oil"),
    // Chain
    ("full body kit", "full body"), ("body kit", "full body"),
    ("brake pad", "brake pads"), ("brake", "brake pads"),
    // Chain — DB has: Chain Sprocket, Chain Sprocket Kit, Chain Cover
    ("chainu", "chain sprocket"), ("chain set", "chain sprocket kit"),
    ("sprocket", "chain sprocket"), ("chain kit", "chain sprocket kit"),
    // Clutch — DB has: Clutch Assembly, Clutch Cable, Clutch Lever, Clutch Plate Assembly
    ("clutchu", "clutch"), ("clutch wire", "clutch cable"),
    ("cutch", "clutch"), ("cluch", "clutch"), ("clutch plate", "clutch plate assembly"),
    ("clutch set", "clutch assembly"), ("clutch kit", "clutch assembly"),
    // Tyres — DB has: Back Alloy Wheel, Alloy Wheel Set, Back Drum
    ("tyre", "alloy wheel"), ("tyru", "alloy wheel"), ("tire", "alloy wheel"),
    ("front tyre", "alloy wheel"), ("back tyre", "back alloy wheel"),
    ("rear tyre", "back alloy wheel"), ("alloy", "alloy wheel"),
    ("wheel set", "alloy wheel set"), ("both wheels", "alloy wheel set"),
    // Seat
    ("seat cover", "seat"), ("seat pannel", "seat panel"), ("seat panel", "seat panel"),
    // Speedometer — check DB name
    ("speedo", "meter"), ("speedometer", "meter"), ("speed meter", "meter"),
    ("digital meter", "meter"), ("meter assembly", "meter"),
    // Suspension
    ("shock", "rear shocker"), ("shocker", "rear shocker"), ("suspension", "rear shocker"),
    ("back suspension", "rear shocker"), ("shock absorber", "rear shocker"),
    // Silencer
    ("exhaust", "silencer"), ("pipe", "silencer"), ("muffler", "silencer"),
    // Wheel
    ("rim", "alloy wheel"), ("wheel rim", "alloy wheel"), ("alloy", "alloy wheel"),
    // Wiring
    ("wiring", "wiring"), ("wiring kit", "wiring"),
    ("wiring set", "wiring"), ("wire set", "wiring"),
    // Visor
    ("visot", "visor"), ("visor", "visor"), ("windscreen", "visor"),
    // Dome
    ("doom", "dome"), ("dome", "dome"),
    // Kick
    ("kick", "kick starter"), ("kickstart", "kick starter"),
    // Air filter
    ("air filter", "air filter"), ("filterlu", "air filter"),
    // Battery
    ("battery", "battery"), ("battry", "battery"),
    // Mirror
    ("mirrorlu", "mirror"), ("side mirror", "mirror"),
    // Gear
    ("gearlu", "gear"), ("gear lever", "gear lever"),
    // Power coil
    ("power coil", "ignition coil"), ("coil", "ignition coil"),
    // Seat
    ("seetu", "seat"),
    // Alloy wheel variants
    ("li wheel", "alloy wheel"), ("aloy wheel", "alloy wheel"),
    ("allow wheel", "alloy wheel"), ("allay wheel", "alloy wheel"),
    ("front wheel", "front alloy wheel"), ("back wheel", "rear alloy wheel"),
    ("rear wheel", "rear alloy wheel"),
    // Carburetor — DB has: Carburettor (double t)
    ("carborator", "carburettor"), ("carburator", "carburettor"),
    ("carburetor", "carburettor"), ("carb", "carburettor"),
    ("carbu", "carburettor"), ("carboretter", "carburettor"),
    // Panel variants
    ("pannel", "full body"), ("pannels", "full body"),
    ("front and back panel", "full body"), ("front back panel", "full body"),
    ("front panel", "front mudguard"), ("back panel", "rear mudguard"),
    ("annel", "full body"), ("pannle", "full body"),
    // Engine — DB has: Bore Kit, Cam Shaft, CDI Unit, Carburettor
    ("engine parts", "bore kit"), ("full engine", "bore kit"),
    ("engine kit", "bore kit"), ("engine set", "bore kit"),
    ("bore", "bore kit"), ("boring kit", "bore kit"),
    ("cdi", "cdi unit"), ("ignition box", "cdi unit"),
    // All parts
    ("all parts", "all"), ("all spares", "all"), ("anni parts", "all"),
    ("full parts", "all"), ("complete set", "all"),
    // Suspension
    ("front suspension", "front fork"), ("fork", "front fork"),
    // Petrol tank
    ("tank", "tank"), ("petrol tank", "tank"),
    ("fuel", "tank"),
    // Shocker
    ("back shocker", "rear shocker"), ("back shock", "rear shocker"),
    ("rear shock", "rear shocker"),
    // Seat panel
    ("seat pannel", "seat panel"), ("seet panel", "seat panel"),
    // Mudguard misspellings seen in production
    ("madgad", "mudguard"), ("magad", "mudguard"), ("mudgad", "mudguard"),
    ("back side madgad", "rear mudguard"), ("front side madgad", "front mudguard"),
    ("back madgad", "rear mudguard"), ("front madgad", "front mudguard"),
    ("backside mudguard", "rear mudguard"), ("backside", "rear mudguard"),
    // Shock absorber misspellings
    ("shakob", "rear shocker"), ("shackob", "rear shocker"), ("shakov", "rear shocker"),
    ("shokob", "rear shocker"), ("shakob", "rear shocker"),
    ("back shakob", "rear shocker"), ("front shakob", "front fork"),
    // Photos request
    ("parts potos", "image"), ("parts photos", "image"), ("photo", "image"),
    ("potos", "image"), ("photos", "image"), ("pic", "image"), ("pics", "image"),
    // Meter/speedometer variants
    ("cd deluxe meter", "meter"), ("cd 100 meter", "meter"), ("splendor meter", "meter"),
    ("shine meter", "meter"), ("activa meter", "meter"),
    ("digital speedo", "meter"), ("analog meter", "meter"),
    // Pulsar variants with no space
    ("pulsar1 25", "pulsar"), ("pulsar125", "pulsar"), ("pulsar150", "pulsar"),
    ("pulsar180", "pulsar"), ("pulsar220", "pulsar"),
    // Common misspellings
    ("shalencer", "silencer"), ("silencer pipe", "silencer"), ("selencer", "silencer"),
    ("head ligh", "headlight"), ("head lite", "headlight"),
    ("body pannels", "full body"), ("bod kit", "full body"),
    // Chain cover
    ("chain cover", "chain cover"), ("chaintray", "chain cover"),
    ("seat side panel", "seat panel"),
];

/// Telugu words for colours — includes compound colours matching DB format (Black/Orange etc.)
const COLOUR_WORDS: &[(&str, &str)] = &[
    // Compound colours first (longest match wins — order matters)
    ("black orange", "Black/Orange"), ("black/orange", "Black/Orange"),
    ("black silver", "Black/Silver"), ("black/silver", "Black/Silver"),
    ("black blue",   "Black/Blue"),   ("black/blue",   "Black/Blue"),
    ("black red",    "Black/Red"),    ("black/red",    "Black/Red"),
    ("black pink",   "Black/Pink Line"), ("black pink line", "Black/Pink Line"),
    ("red black",    "Red/Black"),    ("red/black",    "Red/Black"),
    ("sports red black", "Sports Red/Black"), ("sports red/black", "Sports Red/Black"),
    ("blue black",   "Blue/Black"),
    ("silver black", "Silver/Black"),
    ("red gold",     "Red/Gold"),     ("red/gold",     "Red/Gold"),
    ("black gold",   "Black/Gold"),
    ("grey black",   "Grey/Black"),
    // Single colours
    ("red", "Red"), ("redu", "Red"), ("lal", "Red"),
    ("blue", "Blue"), ("bluee", "Blue"), ("neela", "Blue"),
    ("black", "Black"), ("black colour", "Black"),
    ("white", "White"), ("tella", "White"),
    ("green", "Green"), ("pachha", "Green"),
    ("silver", "Silver"), ("grey", "Grey"), ("gray", "Grey"),
    ("orange", "Orange"), ("yellow", "Yellow"),
    ("gold", "Gold"), ("maroon", "Maroon"), ("brown", "Brown"),
];

// ─────────────────────────────────────────────────────────────────────────────
// NLU — Natural Language Understanding
// ─────────────────────────────────────────────────────────────────────────────

pub struct Nlu;

impl Nlu {
    /// Match a phrase on word boundaries so short aliases don't match inside
    /// unrelated words (for example, "all" inside a longer customer message).
    fn contains_phrase(text: &str, phrase: &str) -> bool {
        let normalize = |value: &str| {
            value.to_lowercase()
                .chars()
                .map(|c| if c.is_alphanumeric() { c } else { ' ' })
                .collect::<String>()
                .split_whitespace()
                .collect::<Vec<_>>()
                .join(" ")
        };
        let text = normalize(text);
        let phrase = normalize(phrase);
        !phrase.is_empty() && format!(" {} ", text).contains(&format!(" {} ", phrase))
    }

    /// Detect language from text
    pub fn detect_lang(text: &str) -> Language {
        let lower = text.to_lowercase();
        // Telugu script
        if text.chars().any(|c| ('\u{0C00}'..='\u{0C7F}').contains(&c)) {
            return Language::Telugu;
        }
        // Telugu romanised words
        let telugu_markers = [
            "kavali", "cheppandi", "undi", "undaya", "unnaya", "unnai",
            "ledu", "ayya", "anna", "garu", "dorikutunda", "enta", "naaku",
            "meeku", "bro anna", "cheppu",
        ];
        if telugu_markers.iter().any(|w| lower.contains(w)) {
            return Language::Telugu;
        }
        // Hindi markers
        let hindi_markers = ["hai", "kya", "chahiye", "milega", "bhai", "yaar", "nahi"];
        if hindi_markers.iter().any(|w| lower.contains(w)) {
            return Language::Hinglish;
        }
        Language::English
    }

    /// Strip noise words, return normalised lowercase string
    pub fn normalise(text: &str, lang: &Language) -> String {
        let mut s = text.to_lowercase();
        // Remove punctuation except hyphens (for model names like "fz-s")
        s = s.chars().map(|c| if c.is_alphanumeric() || c == '-' || c == ' ' { c } else { ' ' }).collect();

        let noise: Vec<&str> = match lang {
            Language::Telugu => TELUGU_NOISE.iter().chain(ENGLISH_NOISE.iter()).copied().collect(),
            Language::Hinglish => HINDI_NOISE.iter().chain(ENGLISH_NOISE.iter()).copied().collect(),
            Language::English => ENGLISH_NOISE.to_vec(),
        };

        for word in &noise {
            // Replace whole-word noise (simple boundary with spaces)
            let pattern = format!(" {} ", word);
            s = s.replace(&pattern, " ");
            if s.starts_with(word) { s = s[word.len()..].to_string(); }
            if s.ends_with(word)   { s = s[..s.len()-word.len()].to_string(); }
        }

        // Collapse multiple spaces
        s.split_whitespace().collect::<Vec<_>>().join(" ")
    }

    /// Extract brand from text, returning (canonical_brand, remaining_text)
    pub fn extract_brand(text: &str) -> (Option<String>, String) {
        let lower = text.to_lowercase();

        // Try aliases first (handles misspellings)
        for (alias, canonical) in BRAND_ALIASES {
            if lower.contains(alias) {
                let cleaned = lower.replace(alias, "").trim().to_string();
                return (Some(canonical.to_string()), cleaned);
            }
        }

        // Direct brand match — an explicit, correctly-spelled brand name must win
        // over a model-name inference (e.g. "bajaj fz-v2" must not become yamaha
        // just because "fz" maps to yamaha in MODEL_BRAND below).
        for brand in BRANDS {
            if lower.contains(brand) {
                let cleaned = lower.replace(brand, "").trim().to_string();
                return (Some(brand.to_string()), cleaned);
            }
        }

        // Try model → brand lookup (longest model match first to avoid partial matches)
        // Also strip the model name from remaining text so it doesnt pollute part extraction
        let mut sorted_models: Vec<_> = MODEL_BRAND.to_vec();
        sorted_models.sort_by(|a, b| b.0.len().cmp(&a.0.len()));
        for (model, brand) in &sorted_models {
            if lower.contains(model) {
                // Strip BOTH the brand name and the model name from remaining
                let mut cleaned = lower.clone();
                cleaned = cleaned.replace(brand, "");
                cleaned = cleaned.replace(model, "");
                // Also strip standalone version words like "plus", "pro", "bs6", "bs4"
                for word in ["plus", "pro", "bs6", "bs4", "old", "new", "model", "v1", "v2", "v3"] {
                    let padded = format!(" {} ", word);
                    cleaned = cleaned.replace(&padded, " ");
                    cleaned = cleaned.trim_start_matches(word).trim_end_matches(word).to_string();
                }
                let cleaned = cleaned.split_whitespace().collect::<Vec<_>>().join(" ");
                return (Some(brand.to_string()), cleaned);
            }
        }

        (None, lower)
    }

    /// Extract model from text given a known brand
    pub fn extract_model(text: &str, brand: &str) -> Option<String> {
        let lower = text.to_lowercase();
        for (model, b) in MODEL_BRAND {
            if *b == brand && lower.contains(model) {
                return Some(model.to_string());
            }
        }
        None
    }

    /// Extract 4-digit year
    pub fn extract_year(text: &str) -> Option<String> {
        let re_year = text.split_whitespace()
            .find(|w| w.len() == 4 && w.chars().all(|c| c.is_ascii_digit()))
            .map(|s| s.to_string());
        // Validate reasonable range
        re_year.filter(|y| {
            let n: u32 = y.parse().unwrap_or(0);
            (1990..=2026).contains(&n)
        })
    }

    /// Extract colour from text — matches longest compound colour first
    /// so "Black/Blue" → "Black/Blue" not just "Black"
    pub fn extract_colour(text: &str) -> Option<String> {
        let lower = text.to_lowercase()
            .replace('/', " ")   // "Black/Blue" → "black blue" for matching
            .replace('-', " ");
        // Find the longest matching colour word (compound beats single)
        COLOUR_WORDS.iter()
            .filter(|(word, _)| lower.contains(*word))
            .max_by_key(|(word, _)| word.len())
            .map(|(_, colour)| colour.to_string())
    }

    /// Extract part names, resolving aliases
    pub fn extract_parts(text: &str) -> Vec<String> {
        let lower = text.to_lowercase();
        let mut found = Vec::new();

        // Try multi-word aliases first (longest match wins)
        let mut sorted_aliases: Vec<_> = PART_ALIASES.to_vec();
        sorted_aliases.sort_by(|a, b| b.0.len().cmp(&a.0.len()));

        for (alias, canonical) in &sorted_aliases {
            if Self::contains_phrase(&lower, alias) {
                let part = canonical.to_string();
                if !found.contains(&part) {
                    found.push(part);
                }
            }
        }

        // If nothing found, try to extract remaining words as part query
        if found.is_empty() {
            // Remove known brand/model/year words and what's left is the part
            let mut remaining = lower.clone();
            for brand in BRANDS { remaining = remaining.replace(brand, ""); }
            // Longest model match first to avoid partial strips
            let mut sorted_models: Vec<_> = MODEL_BRAND.to_vec();
            sorted_models.sort_by(|a, b| b.0.len().cmp(&a.0.len()));
            for (model, _) in &sorted_models { remaining = remaining.replace(model, ""); }
            // Remove Telugu/noise words
            // Remove Telugu/noise words (word-boundary safe — avoids "lo" matching inside "colour")
            let mut padded = format!(" {} ", remaining);
            for noise in TELUGU_NOISE {
                let pattern = format!(" {} ", noise);
                padded = padded.replace(&pattern, " ");
            }
            for noise in ENGLISH_NOISE {
                let pattern = format!(" {} ", noise);
                padded = padded.replace(&pattern, " ");
            }
            // Strip colour vocabulary so a colour phrase inline with the part
            // ("matte blue colour front mudguard") doesn't get glued into the
            // part name candidate — colour is handled separately via extract_colour.
            for extra in ["colour", "color", "matte", "glossy", "metallic", "shade", "dual tone"] {
                let pattern = format!(" {} ", extra);
                padded = padded.replace(&pattern, " ");
            }
            for (word, _) in COLOUR_WORDS {
                let pattern = format!(" {} ", word);
                padded = padded.replace(&pattern, " ");
            }
            let remaining = padded.trim().to_string();
            // Remove years
            let words: Vec<&str> = remaining.split_whitespace()
                .filter(|w| {
                    let n: u32 = w.parse().unwrap_or(0);
                    !(w.len() == 4 && (1990..=2026).contains(&n))
                })
                .filter(|w| w.len() > 1 && w.chars().any(|c| c.is_alphabetic()))
                // Skip single characters and numeric-only model/engine details.
                .collect();
            let candidate = words.join(" ").trim().to_string();
            if candidate.len() > 2 {
                found.push(candidate);
            }
        }

        found
    }

    /// Detect high-level intent
    pub fn detect_intent(text: &str, norm: &str, lang: &Language) -> IntentKind {
        let lower = text.to_lowercase();
        let n = norm.to_lowercase();

        // Reset
        if ["reset", "clear", "new bike", "change bike", "start over", "restart"].iter()
            .any(|w| lower.contains(w)) { return IntentKind::Reset; }

        // Explicit show-all overrides the conversational narrowing
        if ["show all", "all parts", "anni parts", "full list", "anni chuppu"].iter()
            .any(|w| Self::contains_phrase(&lower, w)) { return IntentKind::ListParts; }

        // Greeting
        let greetings = ["hi", "hello", "hey", "namaste", "namasthe", "vanakkam",
                         "good morning", "good evening", "kem cho", "sat sri akal"];
        if greetings.iter().any(|g| lower.starts_with(g)) || lower == "start" {
            return IntentKind::Greeting;
        }

        // Thanks
        if ["thanks", "thank you", "thank u", "tq", "thx", "dhanyavaad",
            "chala thanks", "ok thanks", "manchidi", "chala manchidi"].iter()
            .any(|w| Self::contains_phrase(&lower, w)) {
            return IntentKind::Thanks;
        }

        // Farewells are conversational replies, not part names.
        if ["bye", "goodbye", "see you", "sry bye", "sorry bye", "good night"].iter()
            .any(|w| Self::contains_phrase(&lower, w)) { return IntentKind::Goodbye; }

        // Yes / No
        if ["yes", "ha", "haa", "ok", "confirm", "avunu", "sure", "proceed", "correct"]
            .iter().any(|w| n == *w || lower == *w) { return IntentKind::Yes; }
        if ["no", "nahi", "nahin", "ledu", "wrong", "cancel", "vaddhu", "vaddu"]
            .iter().any(|w| n == *w || lower == *w)
            || ["no response", "no reply"].iter()
                .any(|w| Self::contains_phrase(&lower, w)) {
            return IntentKind::No;
        }

        // Repeat
        if ["repeat", "phir bolo", "meeru cheppindi", "again", "malli cheppu"]
            .iter().any(|w| lower.contains(w)) { return IntentKind::Repeat; }

        // Price total
        if ["total enta", "total cheppu", "total cost", "how much total",
            "sum cheppu", "anni enta", "total price"].iter().any(|w| lower.contains(w)) {
            return IntentKind::PriceTotal;
        }

        // Location
        if ["address", "location", "where", "ekkada", "maps", "google maps", "directions",
            "shop ekkada"].iter().any(|w| lower.contains(w)) { return IntentKind::LocationQuery; }

        // Hours
        if ["timing", "timings", "open", "close", "hours", "time", "working hours",
            "ela pani chestundi", "ela untundi"].iter().any(|w| lower.contains(w)) {
            return IntentKind::HoursQuery;
        }

        // Contact
        if ["phone", "number", "contact", "call", "whatsapp", "mobile"]
            .iter().any(|w| lower.contains(w)) { return IntentKind::ContactQuery; }

        // Payment
        if ["cod", "cash on delivery", "payment", "pay", "upi", "gpay", "paytm", "phonepe",
            "razorpay", "online pay", "cheyyali"].iter().any(|w| lower.contains(w)) {
            return IntentKind::PaymentQuery;
        }

        // Delivery
        if ["delivery", "ship", "dispatch", "when", "how long", "days",
            "delivery time", "delivery charge"].iter().any(|w| lower.contains(w)) {
            return IntentKind::DeliveryQuery;
        }

        // Human handoff
        if ["human", "person", "owner", "manager", "real person",
            "owner tho", "speak to", "talk to", "bot kadu"].iter().any(|w| lower.contains(w)) {
            return IntentKind::HumanHandoff;
        }

        // Order / cart
        if ["order", "buy", "purchase", "book", "add to cart", "checkout"]
            .iter().any(|w| lower.contains(w)) { return IntentKind::OrderIntent; }
        if ["cart", "basket", "my order"].iter().any(|w| lower.contains(w)) {
            return IntentKind::CartQuery;
        }

        // List all parts
        let mentions_part = PART_ALIASES.iter()
            .any(|(alias, _)| Self::contains_phrase(&lower, alias));
        if ["list parts", "show parts", "what parts", "full parts", "anni partslu", "anni spare"]
            .iter().any(|w| Self::contains_phrase(&lower, w))
            || ((n == "all" || n == "anni" || n == "complete"
                || Self::contains_phrase(&lower, "all") || Self::contains_phrase(&lower, "anni"))
                && !mentions_part) {
            return IntentKind::ListParts;
        }

        // Price query
        if ["price", "cost", "rate", "how much", "enta", "entha", "kitna", "kitne"]
            .iter().any(|w| lower.contains(w)) { return IntentKind::PriceQuery; }

        // Stock query
        if ["stock", "available", "undi", "undaya", "unnaya", "avilable", "avialble"]
            .iter().any(|w| lower.contains(w)) { return IntentKind::StockQuery; }

        // Default to part search if we have a non-empty norm
        if n.len() > 3 { return IntentKind::PartSearch; }

        IntentKind::Unknown
    }

    /// Full NLU parse of a customer message
    pub fn parse(text: &str, mem: &ConversationMemory) -> Intent {
        let lang     = Self::detect_lang(text);
        let norm     = Self::normalise(text, &lang);
        let kind     = Self::detect_intent(text, &norm, &lang);
        let colour   = Self::extract_colour(text);
        let year     = Self::extract_year(text);
        let quantity = Self::extract_quantity(text);

        let (brand, after_brand) = Self::extract_brand(&norm);
        let model = brand.as_deref()
            .and_then(|b| Self::extract_model(text, b))
            .or_else(|| Self::extract_model(text, &mem.brand));

        // Multi-part: split on comma or newline, extract parts from each segment
        // e.g. "clutch, brake, bore kit\nhandle bar" → ["clutch cable", "brake pads", "bore kit", "handlebar"]
        let segments: Vec<&str> = text.split(|c| c == ',' || c == '\n').collect();
        let mut parts = Vec::new();
        if segments.len() > 1 {
            for seg in &segments {
                let seg_norm = Self::normalise(seg.trim(), &lang);
                let seg_parts = Self::extract_parts(&seg_norm);
                for p in seg_parts {
                    if !parts.contains(&p) { parts.push(p); }
                }
            }
        }
        // Fallback: single segment extraction
        if parts.is_empty() {
            parts = Self::extract_parts(&after_brand);
        }

        Intent { kind, brand, model, year, colour, parts, quantity, raw_norm: norm }
    }

    /// Extract quantity (e.g. "2 brake pads", "ek set")
    fn extract_quantity(text: &str) -> Option<u32> {
        let lower = text.to_lowercase();
        // Word numbers
        let word_map = [("one", 1u32), ("ek", 1), ("oka", 1), ("two", 2), ("rendu", 2),
                        ("do", 2), ("three", 3), ("teen", 3), ("madu", 3)];
        for (word, n) in &word_map {
            if lower.contains(word) { return Some(*n); }
        }
        // Digit before part name
        for token in text.split_whitespace() {
            if let Ok(n) = token.parse::<u32>() {
                if n > 0 && n <= 20 { return Some(n); }
            }
        }
        None
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// DB CLIENT — thin async HTTP client to Supabase REST (no Python needed)
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Clone)]
pub struct DbClient {
    http:        reqwest::Client,
    supabase_url: String,
    supabase_key: String,
}

impl DbClient {
    pub fn new(url: String, key: String) -> Self {
        Self {
            http: reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(8))
                .build()
                .unwrap(),
            supabase_url: url,
            supabase_key: key,
        }
    }

    /// Search parts by name, optionally scoped to brand/model
    pub async fn search_parts(
        &self,
        part_name: &str,
        brand: &str,
        model: &str,
        colour: &str,
    ) -> Vec<PartRecord> {
        // Build Supabase PostgREST query
        // GET /rest/v1/spare_parts?select=*&part_name=ilike.*brake*&bike_brand=ilike.*hero*
        let mut url = format!(
            "{}/rest/v1/spare_parts?select=id,part_name,price,color,bike_brand,bike_model,year_from,year_to,stock_qty,image_url,web_image_url,part_category&part_name=ilike.*{}*&limit=10",
            self.supabase_url,
            urlencoding::encode(part_name)
        );
        if !brand.is_empty() {
            url.push_str(&format!("&bike_brand=ilike.*{}*", urlencoding::encode(brand)));
        }
        if !model.is_empty() {
            url.push_str(&format!("&bike_model=ilike.*{}*", urlencoding::encode(model)));
        }
        if !colour.is_empty() {
            url.push_str(&format!("&color=ilike.*{}*", urlencoding::encode(colour)));
        }
        url.push_str("&is_active=eq.true&order=stock_qty.desc,price.asc");

        tracing::info!("[brain:db] query → {}", url);

        match self.http.get(&url)
            .header("apikey", &self.supabase_key)
            .header("Authorization", format!("Bearer {}", self.supabase_key))
            .send().await
        {
            Ok(r) if r.status().is_success() => {
                let rows = r.json::<Vec<PartRecord>>().await.unwrap_or_default();
                tracing::info!("[brain:db] results → {} rows", rows.len());
                rows
            }
            Ok(r) => {
                let status = r.status();
                let body = r.text().await.unwrap_or_default();
                tracing::warn!("[brain:db] error {} → {}", status, body);
                vec![]
            }
            Err(e) => {
                tracing::warn!("[brain:db] request failed: {}", e);
                vec![]
            }
        }
    }

    /// Search the same part across bike models. Used only after the exact
    /// brand/model search fails so we can suggest a nearby catalog listing.
    pub async fn search_parts_across_models(
        &self,
        part_name: &str,
        brand: Option<&str>,
    ) -> Vec<PartRecord> {
        let mut url = format!(
            "{}/rest/v1/spare_parts?select=id,part_name,price,color,bike_brand,bike_model,year_from,year_to,stock_qty,image_url,web_image_url,part_category&part_name=ilike.*{}*&is_active=eq.true&order=stock_qty.desc,price.asc&limit=100",
            self.supabase_url,
            urlencoding::encode(part_name)
        );
        if let Some(brand) = brand.filter(|value| !value.trim().is_empty()) {
            url.push_str(&format!("&bike_brand=ilike.*{}*", urlencoding::encode(brand)));
        }

        match self.http.get(&url)
            .header("apikey", &self.supabase_key)
            .header("Authorization", format!("Bearer {}", self.supabase_key))
            .send().await
        {
            Ok(r) if r.status().is_success() => r.json::<Vec<PartRecord>>().await.unwrap_or_default(),
            Ok(r) => {
                tracing::warn!("[brain:db] cross-model search error {}", r.status());
                vec![]
            }
            Err(e) => {
                tracing::warn!("[brain:db] cross-model search request failed: {}", e);
                vec![]
            }
        }
    }

    /// Get all parts for a given bike brand/model
    pub async fn list_parts_for_bike(&self, brand: &str, model: &str) -> Vec<PartRecord> {
        let mut url = format!(
            "{}/rest/v1/spare_parts?select=id,part_name,price,color,stock_qty,bike_brand,bike_model,year_from,year_to,part_category&bike_brand=ilike.*{}*&limit=30&order=part_name.asc",
            self.supabase_url,
            urlencoding::encode(brand)
        );
        if !model.is_empty() {
            url.push_str(&format!("&bike_model=ilike.*{}*", urlencoding::encode(model)));
        }

        match self.http.get(&url)
            .header("apikey", &self.supabase_key)
            .header("Authorization", format!("Bearer {}", self.supabase_key))
            .send().await
        {
            Ok(r) if r.status().is_success() => {
                r.json::<Vec<PartRecord>>().await.unwrap_or_default()
            }
            _ => vec![],
        }
    }

    /// Load all unique part names from DB for dynamic matching
    /// Called at startup — cached in Redis for 1 hour
    pub async fn load_part_names(&self) -> Vec<String> {
        let url = format!(
            "{}/rest/v1/spare_parts?select=part_name&is_active=eq.true&order=part_name.asc&limit=500",
            self.supabase_url
        );
        #[derive(Deserialize)]
        struct Row { part_name: String }

        match self.http.get(&url)
            .header("apikey", &self.supabase_key)
            .header("Authorization", format!("Bearer {}", self.supabase_key))
            .send().await
        {
            Ok(r) if r.status().is_success() => {
                let rows = r.json::<Vec<Row>>().await.unwrap_or_default();
                let mut names: Vec<String> = rows.into_iter()
                    .map(|r| r.part_name)
                    .collect::<std::collections::HashSet<_>>()
                    .into_iter()
                    .collect();
                names.sort();
                names
            }
            _ => vec![],
        }
    }

    /// Load synonym corrections from Supabase bot_training table
    /// Table schema: key (wrong), value (correct), kind (type)
    pub async fn load_synonyms(&self) -> HashMap<String, String> {
        let url = format!(
            "{}/rest/v1/bot_training?select=key,value&kind=eq.spelling&limit=2000",
            self.supabase_url
        );
        #[derive(Deserialize)]
        struct Row { key: String, value: String }

        match self.http.get(&url)
            .header("apikey", &self.supabase_key)
            .header("Authorization", format!("Bearer {}", self.supabase_key))
            .send().await
        {
            Ok(r) if r.status().is_success() => {
                r.json::<Vec<Row>>().await.unwrap_or_default()
                    .into_iter()
                    .map(|r| (r.key, r.value))
                    .collect()
            }
            _ => HashMap::new(),
        }
    }

    /// Save a learned correction using correct bot_training schema
    pub async fn save_correction(&self, wrong: &str, correct: &str) {
        let url = format!("{}/rest/v1/bot_training", self.supabase_url);
        let _ = self.http.post(&url)
            .header("apikey", &self.supabase_key)
            .header("Authorization", format!("Bearer {}", self.supabase_key))
            .header("Prefer", "resolution=merge-duplicates")
            .json(&serde_json::json!({
                "key": wrong,
                "value": correct,
                "kind": "spelling"
            }))
            .send().await;
    }

    /// Save a chat message
    pub async fn save_message(&self, session_id: &str, sender: &str, message: &str) {
        let url = format!("{}/rest/v1/chat_messages", self.supabase_url);
        let _ = self.http.post(&url)
            .header("apikey", &self.supabase_key)
            .header("Authorization", format!("Bearer {}", self.supabase_key))
            .json(&serde_json::json!({
                "session_id": session_id,
                "sender": sender,
                "message": message
            }))
            .send().await;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RESPONSE BUILDER — fills templates in the right language
// ─────────────────────────────────────────────────────────────────────────────

pub struct ResponseBuilder;

impl ResponseBuilder {
    pub fn greeting(name: &str, lang: &Language) -> String {
        let first = if !name.is_empty() {
            name.split_whitespace().next().unwrap_or(name).to_string()
        } else {
            "".to_string()
        };
        match lang {
            Language::Telugu => format!(
                "Namaste {}! 🙏 Lakshmi Motorcycle Spares ki swaagatam!\n\n\
                 Meeru em part kavali? Cheppandi:\n\
                 • Part name type cheyyi → e.g. *'Splendor brake pad'*\n\
                 • Bike model cheppu → available parts anni chuptam\n\n\
                 🌐 lakshmimotorcyclespares.in",
                if first.is_empty() { "Ayya".to_string() } else { first }
            ),
            Language::Hinglish => format!(
                "Namaste {}! 🙏 Lakshmi Motorcycle Spares mein aapka swagat hai!\n\n\
                 Kaunsa part chahiye? Batao:\n\
                 • Part name type karo → e.g. *'Splendor brake pad'*\n\
                 • Bike model batao → saare parts dikhate hain\n\n\
                 🌐 lakshmimotorcyclespares.in",
                if first.is_empty() { "Bhai".to_string() } else { first }
            ),
            Language::English => format!(
                "Welcome {}! 🙏 Lakshmi Motorcycle Spares!\n\n\
                 What part do you need?\n\
                 • Type part name → e.g. *'Splendor brake pad'*\n\
                 • Tell me your bike model → we'll show all available parts\n\n\
                 🌐 lakshmimotorcyclespares.in",
                if first.is_empty() { "".to_string() } else { first }
            ),
        }
    }

    pub fn ask_brand(lang: &Language, part_hint: &str) -> String {
        let hint = if !part_hint.is_empty() { format!(" '{}'", part_hint) } else { "".to_string() };
        match lang {
            Language::Telugu => format!(
                "🏍️ Meeru emi bike brand use chestunnaru{}?\n\n\
                 Hero • Honda • Bajaj • TVS • Yamaha • Suzuki • Royal Enfield\n\n\
                 _(Brand name cheppandi)_", hint),
            Language::Hinglish => format!(
                "🏍️ Aapki bike brand kya hai{}?\n\n\
                 Hero • Honda • Bajaj • TVS • Yamaha • Suzuki • Royal Enfield\n\n\
                 _(Brand batao)_", hint),
            Language::English => format!(
                "🏍️ Which bike brand{}?\n\n\
                 Hero • Honda • Bajaj • TVS • Yamaha • Suzuki • Royal Enfield\n\n\
                 _(Type your brand)_", hint),
        }
    }

    pub fn ask_model(brand: &str, lang: &Language) -> String {
        match lang {
            Language::Telugu => format!(
                "🏍️ *{}* — emi model?\n\n_(Model name cheppandi, e.g. Splendor Plus, Shine 125)_", brand),
            Language::Hinglish => format!(
                "🏍️ *{}* — kaunsa model?\n\n_(Model batao, e.g. Splendor Plus, Shine 125)_", brand),
            Language::English => format!(
                "🏍️ *{}* — which model?\n\n_(Type model name, e.g. Splendor Plus, Shine 125)_", brand),
        }
    }

    pub fn ask_colour(part: &str, lang: &Language) -> String {
        match lang {
            Language::Telugu => format!(
                "🎨 *{}* ki em colour kavali?\n\nRed • Blue • Black • Silver • Grey • Orange",
                part),
            Language::Hinglish => format!(
                "🎨 *{}* ka kaunsa colour chahiye?\n\nRed • Blue • Black • Silver • Grey • Orange",
                part),
            Language::English => format!(
                "🎨 Which colour for *{}*?\n\nRed • Blue • Black • Silver • Grey • Orange",
                part),
        }
    }

    pub fn ask_what_part(brand: &str, model: &str, lang: &Language) -> String {
        let bike = format!("{} {}", brand, model).trim().to_string();
        match lang {
            Language::Telugu => format!(
                "🏍️ *{}* ki em part kavali bro?\n\n\
                 e.g. brake pad, body kit, headlight, fuel tank, silencer\n\n\
                 _(Part name type cheyyi)_", bike),
            Language::Hinglish => format!(
                "🏍️ *{}* ka kaunsa part chahiye bhai?\n\n\
                 e.g. brake pad, body kit, headlight, fuel tank, silencer\n\n\
                 _(Part name batao)_", bike),
            Language::English => format!(
                "🏍️ Which part do you need for *{}*?\n\n\
                 e.g. brake pad, body kit, headlight, fuel tank, silencer",
                bike),
        }
    }

    pub fn parts_found(parts: &[PartRecord], bike: &str, lang: &Language) -> String {
        let mut lines = Vec::new();

        if parts.len() == 1 {
            let p = &parts[0];
            let stock = if p.in_stock() { "✅ Available" } else { "❌ Out of stock" };
            let colour_str = p.color.as_deref().map(|c| format!(" · {}", c)).unwrap_or_default();
            let url = p.image_url.as_deref()
                .filter(|u| !u.is_empty() && *u != "None" && u.starts_with("http"))
                .map(|u| format!("\n📷 [View image]({})", u))
                .unwrap_or_default();
            let product_link = format!("\n🌐 [View on website]({})", product_page_url(&p.id));

            let safe_name = escape_md(&p.part_name);
            let safe_colour = colour_str;
            let safe_bike = escape_md(bike);
            match lang {
                Language::Telugu => {
                    lines.push(format!("✅ *{}*{}  — ₹{}", safe_name, safe_colour, p.price));
                    lines.push(format!("📦 {}{}{}", stock, url, product_link));
                    if !bike.is_empty() { lines.push(format!("🏍️ {}", safe_bike)); }
                    lines.push("\n🛒 Cart lo add cheyyali ante below button press cheyyi!".to_string());
                }
                Language::Hinglish => {
                    lines.push(format!("✅ *{}*{}  — ₹{}", safe_name, safe_colour, p.price));
                    lines.push(format!("📦 {}{}{}", stock, url, product_link));
                    if !bike.is_empty() { lines.push(format!("🏍️ {}", safe_bike)); }
                    lines.push("\n🛒 Cart mein add karne ke liye button dabao!".to_string());
                }
                Language::English => {
                    lines.push(format!("✅ *{}*{}  — ₹{}", safe_name, safe_colour, p.price));
                    lines.push(format!("📦 {}{}{}", stock, url, product_link));
                    if !bike.is_empty() { lines.push(format!("🏍️ {}", safe_bike)); }
                    lines.push("\n🛒 Press the button below to add to cart!".to_string());
                }
            }
        } else {
            // Multiple results
            match lang {
                Language::Telugu => {
                    if !bike.is_empty() { lines.push(format!("🏍️ {}\n", escape_md(bike))); }
                    for p in parts.iter().take(8) {
                        let s = if p.in_stock() { "✅" } else { "❌" };
                        let col = p.color.as_deref()
                            .filter(|c| !c.is_empty() && *c != "None" && *c != "null")
                            .map(|c| format!(" · {}", c)).unwrap_or_default();
                        let img = p.image_url.as_deref()
                            .filter(|u| !u.is_empty() && *u != "None" && u.starts_with("http"))
                            .map(|u| format!(" [📷]({})", u)).unwrap_or_default();
                        lines.push(format!("{} {}{}  — ₹{}{} · [View]({})", s, escape_md(&p.part_name), col, p.price, img, product_page_url(&p.id)));
                    }
                    if parts.len() > 8 { lines.push(format!("\n_{} more results_", parts.len() - 8)); }
                    // Only ask colour if results actually have real colour values
                    let has_colours = parts.iter().any(|p| {
                        p.color.as_deref().map(|c| !c.is_empty() && c != "None" && c != "null").unwrap_or(false)
                    });
                    if has_colours {
                        lines.push("\n_Em colour kavali? Cheppandi — filter chestam!_".to_string());
                    }
                }
                _ => {
                    if !bike.is_empty() { lines.push(format!("🏍️ {}\n", escape_md(bike))); }
                    for p in parts.iter().take(8) {
                        let s = if p.in_stock() { "✅" } else { "❌" };
                        let col = p.color.as_deref()
                            .filter(|c| !c.is_empty() && *c != "None" && *c != "null")
                            .map(|c| format!(" · {}", c)).unwrap_or_default();
                        let img = p.image_url.as_deref()
                            .filter(|u| !u.is_empty() && *u != "None" && u.starts_with("http"))
                            .map(|u| format!(" [📷]({})", u)).unwrap_or_default();
                        lines.push(format!("{} {}{}  — ₹{}{} · [View]({})", s, escape_md(&p.part_name), col, p.price, img, product_page_url(&p.id)));
                    }
                    // Only ask colour if results actually have real colour values
                    let has_colours = parts.iter().any(|p| {
                        p.color.as_deref().map(|c| !c.is_empty() && c != "None" && c != "null").unwrap_or(false)
                    });
                    if has_colours {
                        lines.push("\n_Which colour do you want? Type it and I\'ll filter!_".to_string());
                    }
                }
            }
        }

        lines.join("\n")
    }

    pub fn nearby_fitment_matches(
        part: &str,
        requested_bike: &str,
        matches: &[PartRecord],
        same_brand: bool,
        lang: &Language,
    ) -> String {
        let heading = match lang {
            Language::Telugu => format!(
                "🔎 *{}* {} ki exact listing kanipinchaledu.",
                escape_md(part), escape_md(requested_bike)
            ),
            Language::Hinglish => format!(
                "🔎 *{}* {} ke liye exact listing nahi mili.",
                escape_md(part), escape_md(requested_bike)
            ),
            Language::English => format!(
                "🔎 I couldn't find *{}* listed for *{}*.",
                escape_md(part), escape_md(requested_bike)
            ),
        };
        let intro = match (lang, same_brand) {
            (Language::Telugu, true) => "Same brand lo closest model listings: ",
            (Language::Telugu, false) => "Catalog lo closest listings: ",
            (Language::Hinglish, true) => "Same brand ke closest model listings: ",
            (Language::Hinglish, false) => "Catalog ke closest listings: ",
            (Language::English, true) => "Closest listings for other models of this brand:",
            (Language::English, false) => "Closest listings in the catalog:",
        };
        let caution = match lang {
            Language::Telugu => "Fitment mee bike ki confirm kaaledu. Product details check chesi, order mundu call/WhatsApp cheyyandi: 📞 *+91 91602 01088*",
            Language::Hinglish => "Aapki bike ke liye fitment confirm nahi hai. Product details check karke order se pehle call/WhatsApp karein: 📞 *+91 91602 01088*",
            Language::English => "Compatibility with your bike is not confirmed. Check the product details and contact us before ordering: 📞 *+91 91602 01088*",
        };

        let mut lines = vec![heading, intro.to_string()];
        for item in matches.iter().take(3) {
            let candidate_bike = [item.bike_brand.as_deref(), item.bike_model.as_deref()]
                .into_iter()
                .flatten()
                .filter(|value| !value.trim().is_empty())
                .collect::<Vec<_>>()
                .join(" ");
            let stock = if item.in_stock() { "✅ In stock" } else { "❌ Out of stock" };
            lines.push(format!(
                "• *{}* for *{}* — ₹{} · {}\n  [View product on website]({})",
                escape_md(&item.part_name),
                escape_md(&candidate_bike),
                item.price,
                stock,
                product_page_url(&item.id)
            ));
        }
        lines.push(caution.to_string());
        lines.join("\n\n")
    }

    pub fn not_found(part: &str, bike: &str, lang: &Language) -> String {
        match lang {
            Language::Telugu => format!(
                "🔎 *{}* {} ki matching listing kanipinchaledu.\n\n\
                 Part peru correct ga undho check cheyyandi, leda photo pampandi. Stock confirm cheyyadaniki call/WhatsApp cheyyandi:\n\
                 📞 *+91 91602 01088*",
                escape_md(part),
                if bike.is_empty() { "meeru adugutunna bike ki".to_string() } else { format!("({} ki)", escape_md(bike)) }
            ),
            Language::Hinglish => format!(
                "🔎 *{}* ke liye matching listing nahi mili {}.\n\n\
                 Part ka naam check karein ya photo bhejein. Stock confirm karne ke liye call/WhatsApp karein:\n\
                 📞 *+91 91602 01088*",
                escape_md(part),
                if bike.is_empty() { "".to_string() } else { format!("({} ke liye)", escape_md(bike)) }
            ),
            Language::English => format!(
                "🔎 I couldn't find a matching listing for *{}* {}.\n\n\
                 Please check the part name or send us a photo. To confirm stock, call or WhatsApp:\n\
                 📞 *+91 91602 01088*",
                escape_md(part),
                if bike.is_empty() { "".to_string() } else { format!("(for {})", escape_md(bike)) }
            ),
        }
    }

    pub fn price_total(quote: &HashMap<String, u64>, delivery: u64, lang: &Language) -> String {
        if quote.is_empty() {
            return match lang {
                Language::Telugu => "Inka em parts kavali ante cheppandi — price calculate chestam! 🧮".to_string(),
                _ => "Tell me which parts you need — I'll calculate the total! 🧮".to_string(),
            };
        }
        let mut lines = vec!["💰 *Price Summary:*\n".to_string()];
        let subtotal: u64 = quote.iter().map(|(k, v)| {
            lines.push(format!("  • {}  — ₹{}", k, v));
            v
        }).sum();
        lines.push(format!("\n📦 Delivery: ₹{}", delivery));
        lines.push(format!("💳 *Total: ₹{}*", subtotal + delivery));
        match lang {
            Language::Telugu => lines.push("\n_Order cheyyali ante /cart type cheyyi!_".to_string()),
            _ => lines.push("\n_Type /cart to place your order!_".to_string()),
        }
        lines.join("\n")
    }

    pub fn static_reply(kind: &IntentKind, lang: &Language) -> Option<String> {
        match kind {
            IntentKind::LocationQuery => Some(
                "📍 *Lakshmi Motorcycle Spares*\n\
                 Tribuvani Centre, RTC Road\n\
                 Akbarnivasa Khandrika, AP 524132\n\n\
                 🗺️ https://maps.app.goo.gl/e5cniL9xAHGMV4Da9\n\
                 📞 +91 91602 01088".to_string()
            ),
            IntentKind::HoursQuery => Some(
                "🕘 *Shop Timings:*\n\n\
                 ✅ Monday – Saturday: 9 AM – 7 PM\n\
                 ❌ Sunday: Closed\n\n\
                 📞 +91 91602 01088".to_string()
            ),
            IntentKind::ContactQuery => Some(
                "📞 *+91 91602 01088* (Call / WhatsApp)\n\
                 💬 https://t.me/Lakshmi_Motorcycle_Spares\n\n\
                 Mon–Sat 9 AM–7 PM lo available! 🙏".to_string()
            ),
            IntentKind::PaymentQuery => Some(
                "💰 *Payment Options:*\n\n\
                 ✅ Razorpay (Online — cards, UPI, netbanking)\n\
                 ✅ UPI Manual → send screenshot\n\
                 ❌ No COD (prepaid only)\n\n\
                 UPI ID: `9160201088-4@ybl`".to_string()
            ),
            IntentKind::DeliveryQuery => Some(
                "🚚 *Delivery:*\n\n\
                 • Nellore district: 1–2 days\n\
                 • AP/Telangana: 2–3 days\n\
                 • Rest of India: 4–7 days\n\n\
                 📦 Delivery charge: ₹200 (free above ₹2000)".to_string()
            ),
            IntentKind::HumanHandoff => Some(
                "Sure! 🙏 Owner tho directly connect cheyyi:\n\n\
                 📞 *+91 91602 01088* (Call / WhatsApp)\n\
                 💬 Telegram: https://t.me/Lakshmi_Motorcycle_Spares\n\n\
                 Mon–Sat 9 AM–7 PM".to_string()
            ),
            IntentKind::Thanks => Some(
                match lang {
                    Language::Telugu => "🙏 Mee time ki thanks! Inkemi kavali ante anytime cheppandi!",
                    Language::Hinglish => "🙏 Shukriya! Kuch aur chahiye to batao!",
                    Language::English => "🙏 Thank you! Feel free to ask anything else!",
                }.to_string()
            ),
            IntentKind::Goodbye => Some(
                match lang {
                    Language::Telugu => "🙏 Sare, malli eppudaina message cheyyandi. Bye!",
                    Language::Hinglish => "🙏 Theek hai, zaroorat ho to phir message karein. Bye!",
                    Language::English => "🙏 Goodbye! Message us anytime if you need help.",
                }.to_string()
            ),
            _ => None,
        }
    }

    pub fn reset_reply(lang: &Language) -> String {
        match lang {
            Language::Telugu => "✅ Context clear chesamu! New bike details cheppandi.".to_string(),
            Language::Hinglish => "✅ Context clear! Naya bike batao.".to_string(),
            Language::English => "✅ Context cleared! Tell me your bike details.".to_string(),
        }
    }

    pub fn context_hint(brand: &str, model: &str, lang: &Language) -> String {
        if brand.is_empty() { return String::new(); }
        let bike = format!("{} {}", brand, model).trim().to_string();
        match lang {
            Language::Telugu => format!("\n\n_💡 'reset' type cheste bike change cheyochu_\n🏍️ *{}*", bike),
            _ => format!("\n\n_💡 Type 'reset' to change bike_\n🏍️ *{}*", bike),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// BRAIN — main entry point
// ─────────────────────────────────────────────────────────────────────────────

pub struct Brain {
    redis:   redis::aio::ConnectionManager,
    db:      DbClient,
    delivery: u64,
}

impl Brain {
    pub fn new(redis: redis::aio::ConnectionManager, db: DbClient, delivery: u64) -> Self {
        Self { redis, db, delivery }
    }

    /// Find catalog listings for the requested part, first within the same
    /// brand and then across brands if needed. Results are sorted by model
    /// similarity, but callers must still label fitment as unconfirmed.
    async fn closest_fitment_matches(
        &self,
        part: &str,
        brand: &str,
        model: &str,
    ) -> (Vec<PartRecord>, bool) {
        let mut candidates = self.db.search_parts_across_models(part, Some(brand)).await;
        let mut same_brand = !candidates.is_empty();

        // A result without a model cannot help the customer compare fitment.
        candidates.retain(|item| item.bike_model.as_deref()
            .map(|value| !value.trim().is_empty()).unwrap_or(false));

        if candidates.is_empty() {
            candidates = self.db.search_parts_across_models(part, None).await;
            same_brand = false;
            candidates.retain(|item| item.bike_model.as_deref()
                .map(|value| !value.trim().is_empty()).unwrap_or(false));
        }

        candidates.sort_by_key(|item| (
            model_distance(model, item.bike_model.as_deref().unwrap_or_default()),
            !item.in_stock(),
            item.price,
        ));

        let mut seen_fitments = std::collections::HashSet::new();
        candidates.retain(|item| {
            let fitment = format!(
                "{}:{}",
                normalize_model_name(item.bike_brand.as_deref().unwrap_or_default()),
                normalize_model_name(item.bike_model.as_deref().unwrap_or_default()),
            );
            seen_fitments.insert(fitment)
        });
        candidates.truncate(3);
        (candidates, same_brand)
    }

    // ── Dynamic part name matching against DB ────────────────────────────────

    /// Find closest DB part name for a customer search term
    /// Uses: exact match → starts_with → contains → levenshtein
    async fn match_part_name(&mut self, query: &str) -> String {
        // Check Redis cache for part names
        let cache_key = "brain:part_names";
        let cached: Option<String> = self.redis.get(cache_key).await.unwrap_or(None);
        let part_names: Vec<String> = if let Some(s) = cached {
            serde_json::from_str(&s).unwrap_or_default()
        } else {
            let names = self.db.load_part_names().await;
            if !names.is_empty() {
                let s = serde_json::to_string(&names).unwrap_or_default();
                let _: Result<(), _> = self.redis.set_ex(cache_key, s, 3600).await;
                tracing::info!("[brain] loaded {} part names from DB", names.len());
            }
            names
        };

        if part_names.is_empty() { return query.to_string(); }

        let q = query.to_lowercase();

        // 1. Exact match
        if let Some(n) = part_names.iter().find(|n| n.to_lowercase() == q) {
            return n.clone();
        }

        // 2. DB name contains query word (e.g. "clutch" matches "Clutch Assembly")
        if let Some(n) = part_names.iter().find(|n| n.to_lowercase().contains(&q)) {
            return q; // return query so ilike.*clutch* matches all clutch parts
        }

        // 3. Query contains DB name word (e.g. "clutch plate assembly" contains "clutch")
        if let Some(n) = part_names.iter().find(|n| q.contains(&n.to_lowercase())) {
            return n.to_lowercase();
        }

        // 4. Levenshtein fuzzy match (handles typos)
        let best = part_names.iter()
            .map(|n| (n, levenshtein(&n.to_lowercase(), &q)))
            .filter(|(_, d)| *d <= 3)
            .min_by_key(|(_, d)| *d);

        if let Some((name, _)) = best {
            // Return the full matched name (not just first word) so ilike query works correctly
            return name.to_lowercase();
        }

        // 5. Fallback: return query as-is (ilike will try its best)
        query.to_string()
    }

    // ── Memory helpers ────────────────────────────────────────────────────────

    async fn mem_load(&mut self, session_id: &str) -> ConversationMemory {
        let key = format!("brain:ctx:{}", session_id);
        let raw: Option<String> = self.redis.get(&key).await.unwrap_or(None);
        raw.and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
    }

    async fn mem_save(&mut self, session_id: &str, mem: &ConversationMemory) {
        let key = format!("brain:ctx:{}", session_id);
        let s = serde_json::to_string(mem).unwrap_or_default();
        // TTL 4 hours — customer conversation window
        let _: Result<(), _> = self.redis.set_ex(&key, s, 14_400).await;
    }

    async fn mem_clear(&mut self, session_id: &str) {
        let key = format!("brain:ctx:{}", session_id);
        let _: Result<(), _> = self.redis.del(&key).await;
    }

    // ── Synonym lookup with Redis cache ───────────────────────────────────────

    async fn correct_spelling(&mut self, word: &str) -> Option<String> {
        // Check Redis synonym hash first (fast)
        let key = format!("brain:synonyms");
        let cached: Option<String> = self.redis.hget(&key, word).await.unwrap_or(None);
        if cached.is_some() { return cached; }

        // Simple fuzzy: find closest match in PART_ALIASES
        let lower = word.to_lowercase();
        for (alias, canonical) in PART_ALIASES {
            if levenshtein(alias, &lower) <= 2 {
                // Cache and return
                let _: Result<(), _> = self.redis.hset(&key, word, *canonical).await;
                return Some(canonical.to_string());
            }
        }
        None
    }

    // ── Learning: emit to Redis stream ───────────────────────────────────────

    async fn learn(&mut self, input: &str, reply: &str, confidence: f32) {
        let ts = SystemTime::now()
            .duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
        let _: Result<(), _> = self.redis.xadd(
            "brain:learn",
            "*",
            &[
                ("input", input),
                ("reply", reply),
                ("confidence", &confidence.to_string()),
                ("ts", &ts.to_string()),
            ],
        ).await;
    }

    // ── Main process function ─────────────────────────────────────────────────

    pub async fn process(
        &mut self,
        session_id: &str,
        customer_name: &str,
        customer_text: &str,
    ) -> BrainReply {
        let mut mem = self.mem_load(session_id).await;
        mem.turn_count += 1;
        if !customer_name.is_empty() && mem.customer_name.is_empty() {
            mem.customer_name = customer_name.to_string();
        }

        // Parse the message
        let intent = Nlu::parse(customer_text, &mem);
        mem.lang = Nlu::detect_lang(customer_text);

        tracing::info!("[brain:nlu] text='{}' intent={:?} brand={:?} model={:?} parts={:?}",
            customer_text, intent.kind, intent.brand, intent.model, intent.parts);

        // Merge new entities into memory. If the brand changes to something
        // different from what we already had, the old model/year/colour almost
        // certainly no longer apply (e.g. switching from "honda shine" to "yamaha
        // wiring kit" should not keep searching for a "yamaha shine") — reset them;
        // if this same message also supplies a fresh model/year/colour it will
        // overwrite immediately after via the lines below.
        if let Some(b) = &intent.brand {
            if *b != mem.brand && !mem.brand.is_empty() {
                mem.model.clear();
                mem.year.clear();
                mem.colour.clear();
            }
            mem.brand = b.clone();
        }
        if let Some(m) = &intent.model { mem.model = m.clone(); }
        if let Some(y) = &intent.year  { mem.year  = y.clone(); }
        if let Some(c) = &intent.colour { mem.colour = c.clone(); }

        let lang = mem.lang.clone();
        let delivery = self.delivery;

        // ── Handle pending question first ─────────────────────────────────────
        if let Some(pq) = mem.pending_question.clone() {
            let resolved = self.handle_pending(&mut mem, &intent, customer_text, &pq).await;
            if let Some(reply) = resolved {
                self.learn(customer_text, &reply.text, reply.confidence).await;
                self.mem_save(session_id, &mem).await;
                return reply;
            }
            // Not resolved — fall through to normal intent handling
            mem.pending_question = None;
        }

        // ── Route by intent ───────────────────────────────────────────────────
        let reply = match intent.kind {

            IntentKind::Greeting => {
                let text = ResponseBuilder::greeting(&mem.customer_name, &lang);
                let kb = serde_json::json!({"inline_keyboard": [
                    [{"text": "🔘 Browse by Button (Easy)", "callback_data": "guided_browse_start"}],
                    [{"text": "🛒 View Cart",               "callback_data": "tg_view_cart"}],
                    [{"text": "💬 Owner tho Chat",          "url": "https://t.me/Lakshmi_Motorcycle_spares"}],
                ]});
                BrainReply { text, keyboard: Some(kb), confidence: 1.0, save_chat: true }
            }

            IntentKind::Reset => {
                self.mem_clear(session_id).await;
                BrainReply {
                    text: ResponseBuilder::reset_reply(&lang),
                    keyboard: None, confidence: 1.0, save_chat: true,
                }
            }

            IntentKind::Repeat => {
                BrainReply {
                    text: if mem.last_reply.is_empty() {
                        "Previous message artham kaledhu. Em part kavali?".to_string()
                    } else {
                        mem.last_reply.clone()
                    },
                    keyboard: None, confidence: 0.9, save_chat: false,
                }
            }

            IntentKind::PriceTotal => {
                let text = ResponseBuilder::price_total(&mem.price_quote, delivery, &lang);
                BrainReply { text, keyboard: None, confidence: 1.0, save_chat: true }
            }

            IntentKind::Thanks | IntentKind::Goodbye | IntentKind::LocationQuery | IntentKind::HoursQuery
            | IntentKind::ContactQuery | IntentKind::PaymentQuery
            | IntentKind::DeliveryQuery | IntentKind::HumanHandoff => {
                let text = ResponseBuilder::static_reply(&intent.kind, &lang)
                    .unwrap_or_else(|| "Inkemi help cheyali?".to_string());
                BrainReply { text, keyboard: None, confidence: 1.0, save_chat: true }
            }

            IntentKind::PartSearch | IntentKind::PriceQuery | IntentKind::StockQuery => {
                self.handle_part_search(&mut mem, &intent, customer_text, false).await
            }

            IntentKind::ListParts => {
                // If user asks "all panels" or "full remodeling" but we have bike context,
                // ask what specific part they need rather than dumping 30-item list
                if !mem.brand.is_empty() {
                    let text = match lang {
                        Language::Telugu => format!(
                            "🏍️ *{} {}* — Em part kavali bro?\n\n\
                             _Specific ga cheppandi — panels, lights, engine, brakes, etc._\n\n\
                             _(Full list kavali ante 'show all' type cheyyi)_",
                            mem.brand, mem.model),
                        _ => format!(
                            "🏍️ *{} {}* — Which specific part do you need?\n\n\
                             _e.g. body panels, headlight, engine parts, brake shoes_\n\n\
                             _(Type 'show all' to see the full parts list)_",
                            mem.brand, mem.model),
                    };
                    mem.pending_question = Some(PendingQuestion {
                        kind: PendingKind::NeedPartName,
                        context: String::new(),
                    });
                    BrainReply { text, keyboard: None, confidence: 0.8, save_chat: true }
                } else {
                    self.handle_list_parts(&mut mem, &intent).await
                }
            }

            IntentKind::Yes => {
                // Yes with no pending question — assume confirming previous part
                BrainReply {
                    text: match lang {
                        Language::Telugu => "👍 Cart lo add cheyali ante /cart type cheyyi!".to_string(),
                        _ => "👍 Type /cart to add to your order!".to_string(),
                    },
                    keyboard: None, confidence: 0.7, save_chat: false,
                }
            }

            IntentKind::No => {
                BrainReply {
                    text: match lang {
                        Language::Telugu => "Ok! Inkemi kavali ante cheppandi 🙏".to_string(),
                        _ => "Ok! Let me know what else you need 🙏".to_string(),
                    },
                    keyboard: None, confidence: 0.8, save_chat: false,
                }
            }

            IntentKind::Unknown | IntentKind::OrderIntent | IntentKind::CartQuery
            | IntentKind::TrackOrder => {
                // Fallback: if we have a bike but no part, ask what part
                if !mem.brand.is_empty() && intent.parts.is_empty() {
                    let text = ResponseBuilder::ask_what_part(&mem.brand, &mem.model, &lang);
                    mem.pending_question = Some(PendingQuestion {
                        kind: PendingKind::NeedPartName,
                        context: String::new(),
                    });
                    BrainReply { text, keyboard: None, confidence: 0.8, save_chat: true }
                } else {
                    // Truly unknown — ask for clarification
                    BrainReply {
                        text: match lang {
                            Language::Telugu =>
                                "Ayya, em kavali ante clear ga cheppandi 🙏\n\n\
                                 e.g. *'Splendor brake pad'* or *'Honda Shine headlight'*".to_string(),
                            _ =>
                                "Please specify what you need 🙏\n\n\
                                 e.g. *'Splendor brake pad'* or *'Honda Shine headlight'*".to_string(),
                        },
                        keyboard: None, confidence: 0.3, save_chat: true,
                    }
                }
            }
        };

        mem.last_reply = reply.text.clone();
        self.mem_save(session_id, &mem).await;
        self.learn(customer_text, &reply.text, reply.confidence).await;
        reply
    }

    // ── Part search: multi-query until we have an answer ─────────────────────

    async fn handle_part_search(
        &mut self,
        mem: &mut ConversationMemory,
        intent: &Intent,
        raw: &str,
        is_colour_reply: bool,   // true when called from NeedColour handler
    ) -> BrainReply {
        let lang = mem.lang.clone();
        let bike = format!("{} {}", mem.brand, mem.model).trim().to_string();

        // Clear price_quote on every new search.
        // Only clear colour when this is a fresh search — NOT when customer just
        // answered our "which colour?" question (is_colour_reply = true).
        mem.price_quote.clear();
        if !is_colour_reply {
            mem.colour.clear();
        }

        // Brand and model are now mandatory before we search — fitment matters,
        // so we always confirm the exact bike before checking stock/price. The
        // part the customer already mentioned (if any) rides along in
        // pending_question.context so it isn't lost while we ask.
        if mem.brand.is_empty() {
            mem.pending_question = Some(PendingQuestion {
                kind: PendingKind::NeedBrand,
                context: intent.parts.first().cloned().unwrap_or_default(),
            });
            return BrainReply {
                text: ResponseBuilder::ask_brand(&lang, raw),
                keyboard: None, confidence: 0.8, save_chat: true,
            };
        }

        if mem.model.is_empty() {
            mem.pending_question = Some(PendingQuestion {
                kind: PendingKind::NeedModel,
                context: intent.parts.first().cloned().unwrap_or_default(),
            });
            return BrainReply {
                text: ResponseBuilder::ask_model(&mem.brand, &lang),
                keyboard: None, confidence: 0.8, save_chat: true,
            };
        }

        // Brand + model known; if no part was extracted, ask what part they need
        if intent.parts.is_empty() {
            mem.pending_question = Some(PendingQuestion {
                kind: PendingKind::NeedPartName,
                context: String::new(),
            });
            return BrainReply {
                text: ResponseBuilder::ask_what_part(&mem.brand, &mem.model, &lang),
                keyboard: None, confidence: 0.8, save_chat: true,
            };
        }

        let mut all_results = Vec::new();
        let mut not_found_parts: Vec<(String, String)> = Vec::new();

        // Run a DB query for each extracted part
        for part_name in &intent.parts {
            mem.parts_asked.push(part_name.clone());

            // Dynamic matching: find best DB part name for customer query
            let corrected = self.match_part_name(part_name).await;
            tracing::info!("[brain:nlu] part '{}' → search term '{}'", part_name, corrected);

            // Query 1: scoped to brand + model + colour — fitment matters, so we
            // never widen the search beyond the customer's stated bike.
            let mut results = self.db.search_parts(
                &corrected, &mem.brand, &mem.model, &mem.colour
            ).await;

            // Query 2: if colour filter active and still no results, retry without
            // colour but stay scoped to the same brand + model.
            if results.is_empty() && !mem.colour.is_empty() {
                results = self.db.search_parts(
                    &corrected, &mem.brand, &mem.model, ""
                ).await;
            }

            // Query 3: try raw customer word if corrected failed — still scoped to
            // brand + model, never a cross-bike fallback.
            if results.is_empty() && corrected != *part_name {
                results = self.db.search_parts(
                    part_name, &mem.brand, &mem.model, ""
                ).await;
            }

            if results.is_empty() {
                not_found_parts.push((part_name.clone(), corrected.clone()));
            } else {
                // Deduplicate: keep one row per (part_name, color) pair
                // Prevents duplicate rows from multi-brand DB entries
                let mut seen_keys = std::collections::HashSet::new();
                let deduped: Vec<PartRecord> = results.into_iter().filter(|r| {
                    let key = format!("{}|{}",
                        r.part_name.to_lowercase(),
                        r.color.as_deref().unwrap_or("").to_lowercase()
                    );
                    seen_keys.insert(key)
                }).collect();

                // Update price quote — only cheapest in-stock per part TYPE
                // (not all colour variants — that would inflate the total)
                let best_price = deduped.iter()
                    .filter(|r| r.in_stock())
                    .map(|r| r.price)
                    .min();
                if let Some(price) = best_price {
                    mem.price_quote.insert(part_name.clone(), price);
                }
                all_results.extend(deduped);
            }
        }

        // If multiple results all have same base part name but different colours
        // → ask which colour instead of dumping all
        if !all_results.is_empty() && intent.parts.len() == 1 && mem.colour.is_empty() {
            let first_part = &intent.parts[0];
            let unique_colours: Vec<_> = all_results.iter()
                .filter_map(|p| p.color.as_deref())
                .filter(|c| !c.is_empty() && *c != "None" && *c != "null")
                .collect::<std::collections::HashSet<_>>()
                .into_iter()
                .collect();
            // If more than 3 colour variants — ask which colour
            if unique_colours.len() > 3 {
                let colour_list = {
                    let mut v: Vec<_> = all_results.iter()
                        .filter_map(|p| p.color.as_deref())
                        .filter(|c| !c.is_empty() && *c != "None" && *c != "null")
                        .collect::<std::collections::HashSet<_>>()
                        .into_iter()
                        .collect::<Vec<_>>();
                    v.sort();
                    v.join(" • ")
                };
                mem.pending_question = Some(PendingQuestion {
                    kind: PendingKind::NeedColour,
                    context: first_part.clone(),
                });
                let text = match lang {
                    Language::Telugu => format!(
                        "🎨 *{}* ki em colour kavali?

{}

_Colour cheppandi — filter chestam!_",
                        escape_md(first_part), colour_list
                    ),
                    _ => format!(
                        "🎨 Which colour for *{}*?

{}

_Type your colour to filter!_",
                        escape_md(first_part), colour_list
                    ),
                };
                mem.last_reply = text.clone();
                // mem_save happens in process() after we return — no session_id here
                return BrainReply { text, keyboard: None, confidence: 0.95, save_chat: true };
            }
        }

        // Build response
        if all_results.is_empty() {
            let first_part = intent.parts.first().cloned().unwrap_or_default();
            let search_part = not_found_parts.first()
                .map(|(_, corrected)| corrected.as_str())
                .filter(|value| !value.is_empty())
                .unwrap_or(&first_part);
            let results_nocolor = self.db.search_parts(
                search_part, &mem.brand, &mem.model, ""
            ).await;

            if !results_nocolor.is_empty() && mem.colour.is_empty() {
                mem.pending_question = Some(PendingQuestion {
                    kind: PendingKind::NeedColour,
                    context: first_part.clone(),
                });
                return BrainReply {
                    text: ResponseBuilder::ask_colour(&first_part, &lang),
                    keyboard: None, confidence: 0.9, save_chat: true,
                };
            }

            let (nearby_matches, same_brand) = self.closest_fitment_matches(
                search_part, &mem.brand, &mem.model
            ).await;
            if !nearby_matches.is_empty() {
                return BrainReply {
                    text: ResponseBuilder::nearby_fitment_matches(
                        &first_part, &bike, &nearby_matches, same_brand, &lang
                    ),
                    keyboard: None, confidence: 0.75, save_chat: true,
                };
            }

            BrainReply {
                text: ResponseBuilder::not_found(&first_part, &bike, &lang),
                keyboard: None, confidence: 0.5, save_chat: true,
            }
        } else {
            let mut text = ResponseBuilder::parts_found(&all_results, &bike, &lang);

            // If a customer asked for several items, report every missing item
            // too and offer nearby-model product links where possible.
            for (missing_part, corrected_part) in not_found_parts.iter().take(3) {
                let query = if corrected_part.is_empty() { missing_part } else { corrected_part };
                let (nearby_matches, same_brand) = self.closest_fitment_matches(
                    query, &mem.brand, &mem.model
                ).await;
                if nearby_matches.is_empty() {
                    text.push_str(&format!(
                        "\n\n{}",
                        ResponseBuilder::not_found(missing_part, &bike, &lang)
                    ));
                } else {
                    text.push_str(&format!(
                        "\n\n{}",
                        ResponseBuilder::nearby_fitment_matches(
                            missing_part, &bike, &nearby_matches, same_brand, &lang
                        )
                    ));
                }
            }

            // Append context hint if we have bike in memory
            if !mem.brand.is_empty() {
                text.push_str(&ResponseBuilder::context_hint(&mem.brand, &mem.model, &lang));
            }

            // Show price total ONLY when customer searched multiple distinct parts
            // and we have a price for each. Use mem.price_quote (keyed by searched term)
            // so "full body" search returning Full Body + Full Body+Tank variants
            // doesn't inflate the total — only the cheapest match per searched term counts.
            if intent.parts.len() > 1 && mem.price_quote.len() > 1 {
                let subtotal: u64 = mem.price_quote.values().sum();
                if subtotal > 0 {
                    let parts_summary = mem.price_quote.iter()
                        .map(|(k, v)| format!("  • {} — ₹{}", k, v))
                        .collect::<Vec<_>>().join("\n");
                    text.push_str(&format!(
                        "\n\n💰 *Price Summary:*\n{}\n\n*Total: ₹{}* + ₹{} delivery",
                        parts_summary, subtotal, self.delivery
                    ));
                }
            }

            BrainReply { text, keyboard: None, confidence: 0.95, save_chat: true }
        }
    }

    // ── List all parts for bike ───────────────────────────────────────────────

    async fn handle_list_parts(
        &mut self,
        mem: &mut ConversationMemory,
        intent: &Intent,
    ) -> BrainReply {
        let lang = mem.lang.clone();

        if mem.brand.is_empty() {
            mem.pending_question = Some(PendingQuestion {
                kind: PendingKind::NeedBrand,
                context: "list_parts".to_string(),
            });
            return BrainReply {
                text: ResponseBuilder::ask_brand(&lang, ""),
                keyboard: None, confidence: 0.8, save_chat: true,
            };
        }

        let parts = self.db.list_parts_for_bike(&mem.brand, &mem.model).await;
        if parts.is_empty() {
            return BrainReply {
                text: match lang {
                    Language::Telugu => format!("😔 {} {} ki parts ippudu DB lo levu. Owner ki contact cheyyi!", mem.brand, mem.model),
                    _ => format!("😔 No parts found for {} {}. Contact owner!", mem.brand, mem.model),
                },
                keyboard: None, confidence: 0.5, save_chat: true,
            };
        }

        let bike = format!("{} {}", mem.brand, mem.model).trim().to_string();
        let mut lines = vec![format!("🏍️ *{}* — Available Parts:\n", bike)];
        let in_stock: Vec<_> = parts.iter().filter(|p| p.in_stock()).collect();
        let out_of_stock: Vec<_> = parts.iter().filter(|p| !p.in_stock()).collect();

        for p in in_stock.iter().take(15) {
            let col = p.color.as_deref()
                .filter(|c| !c.is_empty() && *c != "None" && *c != "null")
                .map(|c| format!(" · {}", c)).unwrap_or_default();
            lines.push(format!("✅ *{}*{}  — ₹{}", p.part_name, col, p.price));
        }
        if !out_of_stock.is_empty() {
            lines.push(format!("\n❌ *Out of stock ({})* — notify chestha:", out_of_stock.len()));
            for p in out_of_stock.iter().take(5) {
                lines.push(format!("  • {}", p.part_name));
            }
        }
        lines.push("\n_Specific part kavali ante cheppu — order chestam!_".to_string());

        BrainReply {
            text: lines.join("\n"),
            keyboard: None, confidence: 0.9, save_chat: true,
        }
    }

    // ── Handle response to a pending clarification question ──────────────────

    async fn handle_pending(
        &mut self,
        mem: &mut ConversationMemory,
        intent: &Intent,
        raw: &str,
        pq: &PendingQuestion,
    ) -> Option<BrainReply> {
        let lang = mem.lang.clone();

        match &pq.kind {
            PendingKind::NeedBrand => {
                // Customer replied with brand (or we extracted it from intent)
                if intent.brand.is_some() || !mem.brand.is_empty() {
                    mem.pending_question = None;
                    // Resume the original part search — do not let the brand-reply
                    // text itself (e.g. "Hero") get misparsed as the part name.
                    let mut fixed_intent = Intent::default();
                    if !pq.context.is_empty() { fixed_intent.parts = vec![pq.context.clone()]; }
                    return Some(self.handle_part_search(mem, &fixed_intent, raw, true).await);
                }
                None // Brand still not known — let normal flow ask again
            }

            PendingKind::NeedModel => {
                if intent.model.is_some() || !mem.model.is_empty() {
                    mem.pending_question = None;
                    let mut fixed_intent = Intent::default();
                    if !pq.context.is_empty() { fixed_intent.parts = vec![pq.context.clone()]; }
                    return Some(self.handle_part_search(mem, &fixed_intent, raw, false).await);
                }
                None
            }

            PendingKind::NeedYear => {
                if let Some(y) = Nlu::extract_year(raw) {
                    mem.year = y;
                    mem.pending_question = None;
                    return Some(self.handle_part_search(mem, intent, raw, false).await);
                }
                None
            }

            PendingKind::NeedColour => {
                // extract_colour now matches longest compound first so
                // "Black/Blue" → "Black/Blue" (DB format), "black blue" → "Black/Blue"
                let colour = Nlu::extract_colour(raw)
                    .or_else(|| intent.colour.clone())
                    .or_else(|| {
                        // Last resort: strip the slash from raw and use as-is
                        // e.g. customer typed exactly "Black/Blue" → send "Black/Blue" to DB
                        let norm = raw.trim().to_string();
                        if !norm.is_empty() && norm.split_whitespace().count() <= 4 {
                            Some(norm)
                        } else { None }
                    });
                if let Some(c) = colour {
                    mem.colour = c;
                    mem.pending_question = None;
					let mut fixed_intent = Intent::default();
					fixed_intent.parts = vec![pq.context.clone()];
                    return Some(self.handle_part_search(mem, &fixed_intent, raw, true).await);
                }
                None
            }

            PendingKind::NeedPartName => {
                // Acknowledgements and social replies do not answer a part-name
                // question. Keep the context and repeat a concrete prompt.
                match intent.kind {
                    IntentKind::Yes | IntentKind::No | IntentKind::Greeting => {
                        return Some(BrainReply {
                            text: ResponseBuilder::ask_what_part(&mem.brand, &mem.model, &lang),
                            keyboard: None, confidence: 0.9, save_chat: true,
                        });
                    }
                    IntentKind::Thanks => {
                        return ResponseBuilder::static_reply(&IntentKind::Thanks, &lang)
                            .map(|text| BrainReply {
                                text, keyboard: None, confidence: 1.0, save_chat: true,
                            });
                    }
                    IntentKind::Goodbye => {
                        mem.pending_question = None;
                        return ResponseBuilder::static_reply(&IntentKind::Goodbye, &lang)
                            .map(|text| BrainReply {
                                text, keyboard: None, confidence: 1.0, save_chat: true,
                            });
                    }
                    _ => {}
                }

                // Only a concrete extracted part should resolve this question.
                if !intent.parts.is_empty() {
                    mem.pending_question = None;
                    return Some(self.handle_part_search(mem, intent, raw, false).await);
                }
                None
            }

            PendingKind::NeedQuantity => {
                if let Some(qty) = intent.quantity {
                    mem.pending_question = None;
                    return Some(BrainReply {
                        text: match lang {
                            Language::Telugu => format!("✅ {} units — cart lo add cheyyi!", qty),
                            _ => format!("✅ {} units — adding to cart!", qty),
                        },
                        keyboard: None, confidence: 0.9, save_chat: false,
                    });
                }
                None
            }

            PendingKind::ConfirmPart(part) => {
                match intent.kind {
                    IntentKind::Yes => {
                        mem.pending_question = None;
                        Some(BrainReply {
                            text: format!("✅ *{}* selected! Cart lo add cheyyadaniki /cart type cheyyi.", part),
                            keyboard: None, confidence: 1.0, save_chat: true,
                        })
                    }
                    IntentKind::No => {
                        mem.pending_question = None;
                        Some(BrainReply {
                            text: "Ok! Correct part name cheppandi — find chestam!".to_string(),
                            keyboard: None, confidence: 1.0, save_chat: false,
                        })
                    }
                    _ => None,
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY
// ─────────────────────────────────────────────────────────────────────────────

/// Escape Telegram Markdown v1 special characters in dynamic text
/// Prevents 400 Bad Request when part names contain +, (, ), *, _, etc.
fn escape_md(s: &str) -> String {
    s.replace('*', r"\*")
     .replace('_', r"\_")
     .replace('[', r"\[")
     .replace('`', r"\`")
}

fn product_page_url(part_id: &str) -> String {
    format!(
        "https://lakshmimotorcyclespares.in/?product={}",
        urlencoding::encode(part_id)
    )
}

fn levenshtein(a: &str, b: &str) -> usize {
    let a: Vec<char> = a.chars().collect();
    let b: Vec<char> = b.chars().collect();
    let m = a.len();
    let n = b.len();

    if m == 0 { return n; }
    if n == 0 { return m; }

    let mut dp = vec![vec![0usize; n + 1]; m + 1];
    for i in 0..=m { dp[i][0] = i; }
    for j in 0..=n { dp[0][j] = j; }

    for i in 1..=m {
        for j in 1..=n {
            let cost = if a[i-1] == b[j-1] { 0 } else { 1 };
            dp[i][j] = (dp[i-1][j] + 1)
                .min(dp[i][j-1] + 1)
                .min(dp[i-1][j-1] + cost);
        }
    }
    dp[m][n]
}

fn normalize_model_name(model: &str) -> String {
    model.to_lowercase()
        .chars()
        .filter(|c| c.is_alphanumeric())
        .collect()
}

fn model_distance(requested: &str, candidate: &str) -> usize {
    let requested = normalize_model_name(requested);
    let candidate = normalize_model_name(candidate);
    if requested.is_empty() || candidate.is_empty() {
        return usize::MAX;
    }
    if requested == candidate {
        return 0;
    }
    if requested.contains(&candidate) || candidate.contains(&requested) {
        return requested.len().abs_diff(candidate.len());
    }
    levenshtein(&requested, &candidate)
}

// ─────────────────────────────────────────────────────────────────────────────
// TESTS
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect_lang_telugu() {
        assert_eq!(Nlu::detect_lang("brake pad kavali anna"), Language::Telugu);
        assert_eq!(Nlu::detect_lang("splendor brake pad"), Language::English);
    }

    #[test]
    fn test_extract_brand() {
        let (brand, _) = Nlu::extract_brand("hero splendor brake pad");
        assert_eq!(brand, Some("hero".to_string()));

        let (brand, _) = Nlu::extract_brand("splendor plus body kit");
        assert_eq!(brand, Some("hero".to_string()));

        let (brand, _) = Nlu::extract_brand("hiro bike parts");
        assert_eq!(brand, Some("hero".to_string()));
    }

    #[test]
    fn test_extract_year() {
        assert_eq!(Nlu::extract_year("splendor 2019 model"), Some("2019".to_string()));
        assert_eq!(Nlu::extract_year("no year here"), None);
        assert_eq!(Nlu::extract_year("2030 model"), None); // out of range
    }

    #[test]
    fn test_part_aliases() {
        let parts = Nlu::extract_parts("brakelu kavali");
        assert!(parts.contains(&"brake pads".to_string()));

        let parts = Nlu::extract_parts("body kit price enta");
        assert!(parts.contains(&"full body".to_string()));
    }

    #[test]
    fn test_intent_detection() {
        assert_eq!(Nlu::detect_intent("hi", "hi", &Language::English), IntentKind::Greeting);
        assert_eq!(Nlu::detect_intent("namaste", "namaste", &Language::Telugu), IntentKind::Greeting);
        assert_eq!(Nlu::detect_intent("reset", "reset", &Language::English), IntentKind::Reset);
        assert_eq!(Nlu::detect_intent("total enta", "total enta", &Language::Telugu), IntentKind::PriceTotal);
    }

    #[test]
    fn test_levenshtein() {
        assert_eq!(levenshtein("brake", "brakee"), 1);
        assert_eq!(levenshtein("splendor", "spledor"), 1);
        assert_eq!(levenshtein("abc", "abc"), 0);
    }

    #[test]
    fn test_colour_extraction() {
        assert_eq!(Nlu::extract_colour("red colour body kit"), Some("Red".to_string()));
        assert_eq!(Nlu::extract_colour("neela tank"), Some("Blue".to_string()));
    }

    #[test]
    fn test_price_total() {
        let mut quote = HashMap::new();
        quote.insert("Brake Pads".to_string(), 450u64);
        quote.insert("Headlight".to_string(), 850u64);
        let reply = ResponseBuilder::price_total(&quote, 200, &Language::Telugu);
        assert!(reply.contains("₹1500"));
    }
}
