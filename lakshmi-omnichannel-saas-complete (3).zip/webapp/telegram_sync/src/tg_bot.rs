//! tg_bot — Rust Telegram webhook gateway (Stage 1)
//!
//! Third binary in the telegram_sync crate, alongside telegram_sync and chat_ws.
//! Build: cargo build --release --bin tg_bot
//!
//! What this binary owns (Stage 1):
//!   POST /api/telegram/webhook    — Telegram sends all updates here
//!   GET  /health                  — liveness probe for systemd / nginx
//!
//! What it delegates to Python (loopback HTTP):
//!   POST /internal/tg-text        — text messages that need AI / auto-reply
//!   POST /internal/tg-photo       — photo messages (UPI screenshots, admin panel)
//!   POST /internal/tg-owner-reply — owner replying to a forwarded customer question
//!
//! What it handles fully in Rust (no Python needed):
//!   • All callback_query routing (cart +/-, view/clear/checkout, guided browse,
//!     bike selector, UPI approve/reject, qty adjust, guided_add, guided_img, etc.)
//!   • Cart CRUD in Redis
//!   • Guided-context store/load in Redis (gctx: keys)
//!   • Dedup of Telegram message retries (tg:seen: keys)
//!   • /start, /cart, /help commands
//!   • Order flow state machine (await_name → await_phone → await_address
//!     → choose_payment → await_upi_screenshot / await_razorpay)
//!   • Razorpay payment link creation
//!   • UPI screenshot forwarding to owner + approve/reject handling
//!
//! Required env vars (same .env as other services):
//!   TG_BOT_PORT           default 5001
//!   TELEGRAM_TOKEN
//!   TELEGRAM_CHAT_ID      owner's numeric chat_id
//!   OWNER_UPI_ID
//!   OWNER_PHONE_NUMBER
//!   RAZORPAY_KEY_ID
//!   RAZORPAY_KEY_SECRET
//!   REDIS_URL             default redis://127.0.0.1:6379
//!   PYTHON_API_URL        default http://127.0.0.1:5000
//!   SITE_URL              used for webhook self-registration
//!   DELIVERY_CHARGE       default 200  (overrides admin setting until Phase 2)

use std::sync::Arc;
use std::time::Duration;
mod brain;
use brain::{Brain, DbClient};

use anyhow::Result;
use axum::{
    extract::State,
    http::StatusCode,
    response::IntoResponse,
    routing::{get, post},
    Json, Router,
};
use dotenvy::dotenv;
use redis::AsyncCommands;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tracing::{error, info, warn};

// ─────────────────────────────────────────────────────────────────────────────
// MODELS — mirror Python's JSON shapes exactly
// ─────────────────────────────────────────────────────────────────────────────

/// A single item in the Telegram cart.
/// Mirrors the dicts stored in tg:cart:{chat_id} by Python today.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CartItem {
    pub part_id:    String,
    pub part_name:  String,
    pub price:      String,   // stored as "₹450" or "450" — parse with price_rupees()
    pub qty:        u32,
    #[serde(default)] pub bike_brand: String,
    #[serde(default)] pub bike_model: String,
    #[serde(default)] pub bike_year:  String,
    #[serde(default)] pub color:      String,
    #[serde(default)] pub image_url:  String,
}

impl CartItem {
    /// Parse rupee amount from mixed strings like "₹450", "450", "₹1,200"
    pub fn price_rupees(&self) -> u64 {
        self.price
            .chars()
            .filter(|c| c.is_ascii_digit())
            .collect::<String>()
            .parse()
            .unwrap_or(0)
    }
}

/// Order flow state stored at tg:order:{chat_id}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderFlow {
    pub state:   String,
    pub cart:    Vec<CartItem>,
    pub total:   u64,
    #[serde(default)] pub name:    String,
    #[serde(default)] pub phone:   String,
    #[serde(default)] pub address: String,
    #[serde(default)] pub rzp_amount: u64,
}

/// Guided-browse context stored at gctx:{hkey}
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct GuidedCtx {
    pub brand:    String,
    pub model:    String,
    pub year:     String,
    #[serde(default)] pub category: String,
}

// ─────────────────────────────────────────────────────────────────────────────
// CALLBACK ACTIONS — replaces every cb_data.startswith(...) in Python
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug)]
enum CallbackAction<'a> {
    Noop,
    PartAdd(&'a str),               // po:{short_key}
    PartRemove(&'a str),            // pr:{short_key}
    AddAll(&'a str),                // add_all:{list_key}
    ViewCart,                       // tg_view_cart
    ClearCart,                      // tg_clear_cart
    Checkout,                       // tg_checkout
    PayRazorpay,                    // pay_razorpay
    PayUpi,                         // pay_upi
    UpiApprove(&'a str, &'a str),   // upi_approve:{cust_id}:{txn_id}
    UpiReject(&'a str),             // upi_reject:{cust_id}:
    Suggest(&'a str, &'a str),      // suggest:{wrong}:{correct}
    BikeBrand(&'a str),             // bike_brand:{brand}
    BikeSelectStart,                // bike_select_start | guided_browse_start
    BikeModel(&'a str, &'a str),    // bike_model:{brand}:{model}
    BikeYear(&'a str, &'a str, &'a str), // bike_year:{brand}:{model}:{year}
    GuidedDismiss,                  // guided_dismiss
    GuidedYrDone(&'a str),          // guided_yr_done:{ctx_key}
    GuidedCat(&'a str),             // guided_cat:{ctx_key}
    GuidedPart(&'a str, &'a str),   // guided_part:{part_id}:{ctx_key}
    GuidedImg(&'a str),             // guided_img:{part_id}
    GuidedQty(&'a str, u32, &'a str, &'a str), // guided_qty:{p|m}:{qty}:{part_id}:{ctx_key}
    GuidedAdd(u32, &'a str, &'a str),           // guided_add:{qty}:{part_id}:{ctx_key}
    Unknown,
}

fn parse_callback(data: &str) -> CallbackAction<'_> {
    if data == "noop"               { return CallbackAction::Noop; }
    if data == "tg_view_cart"       { return CallbackAction::ViewCart; }
    if data == "tg_clear_cart"      { return CallbackAction::ClearCart; }
    if data == "tg_checkout"        { return CallbackAction::Checkout; }
    if data == "pay_razorpay"       { return CallbackAction::PayRazorpay; }
    if data == "pay_upi"            { return CallbackAction::PayUpi; }
    if data == "bike_select_start" || data == "guided_browse_start" {
        return CallbackAction::BikeSelectStart;
    }
    if data == "guided_dismiss"     { return CallbackAction::GuidedDismiss; }

    if let Some(rest) = data.strip_prefix("po:")           { return CallbackAction::PartAdd(rest); }
    if let Some(rest) = data.strip_prefix("pr:")           { return CallbackAction::PartRemove(rest); }
    if let Some(rest) = data.strip_prefix("add_all:")      { return CallbackAction::AddAll(rest); }
    if let Some(rest) = data.strip_prefix("guided_yr_done:") { return CallbackAction::GuidedYrDone(rest); }
    if let Some(rest) = data.strip_prefix("guided_cat:")   { return CallbackAction::GuidedCat(rest); }
    if let Some(rest) = data.strip_prefix("guided_img:")   { return CallbackAction::GuidedImg(rest); }

    if let Some(rest) = data.strip_prefix("upi_approve:") {
        let mut it = rest.splitn(2, ':');
        let cust = it.next().unwrap_or("");
        let txn  = it.next().unwrap_or("");
        return CallbackAction::UpiApprove(cust, txn);
    }
    if let Some(rest) = data.strip_prefix("upi_reject:") {
        let cust = rest.split(':').next().unwrap_or("");
        return CallbackAction::UpiReject(cust);
    }
    if let Some(rest) = data.strip_prefix("suggest:") {
        let mut it = rest.splitn(2, ':');
        let wrong   = it.next().unwrap_or("");
        let correct = it.next().unwrap_or("");
        return CallbackAction::Suggest(wrong, correct);
    }
    if let Some(rest) = data.strip_prefix("bike_brand:") { return CallbackAction::BikeBrand(rest); }
    if let Some(rest) = data.strip_prefix("bike_model:") {
        let mut it = rest.splitn(2, ':');
        let brand = it.next().unwrap_or("");
        let model = it.next().unwrap_or("");
        return CallbackAction::BikeModel(brand, model);
    }
    if let Some(rest) = data.strip_prefix("bike_year:") {
        let parts: Vec<&str> = rest.splitn(3, ':').collect();
        let brand = parts.first().copied().unwrap_or("");
        let model = parts.get(1).copied().unwrap_or("");
        let year  = parts.get(2).copied().unwrap_or("");
        return CallbackAction::BikeYear(brand, model, year);
    }
    if let Some(rest) = data.strip_prefix("guided_part:") {
        let mut it = rest.splitn(2, ':');
        let pid = it.next().unwrap_or("");
        let ctx = it.next().unwrap_or("");
        return CallbackAction::GuidedPart(pid, ctx);
    }
    if let Some(rest) = data.strip_prefix("guided_qty:") {
        let parts: Vec<&str> = rest.splitn(4, ':').collect();
        let action  = parts.first().copied().unwrap_or("p");
        let qty: u32 = parts.get(1).and_then(|s| s.parse().ok()).unwrap_or(1);
        let pid     = parts.get(2).copied().unwrap_or("");
        let ctx     = parts.get(3).copied().unwrap_or("");
        return CallbackAction::GuidedQty(action, qty, pid, ctx);
    }
    if let Some(rest) = data.strip_prefix("guided_add:") {
        let parts: Vec<&str> = rest.splitn(3, ':').collect();
        let qty: u32 = parts.first().and_then(|s| s.parse().ok()).unwrap_or(1);
        let pid     = parts.get(1).copied().unwrap_or("");
        let ctx     = parts.get(2).copied().unwrap_or("");
        return CallbackAction::GuidedAdd(qty, pid, ctx);
    }

    CallbackAction::Unknown
}

// ─────────────────────────────────────────────────────────────────────────────
// APP STATE
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Clone)]
struct AppState {
    http:       reqwest::Client,
    redis:      redis::aio::ConnectionManager,
    cfg:        Arc<Config>,
    brain:   Arc<tokio::sync::Mutex<Brain>>,
}

struct Config {
    token:        String,
    owner_id:     String,
    owner_phone:  String,
    upi_id:       String,
    rzp_key:      String,
    rzp_secret:   String,
    python_url:   String,
    delivery:     u64,
    supabase_url: String,
    supabase_key: String,
}

// ─────────────────────────────────────────────────────────────────────────────
// REDIS HELPERS
// ─────────────────────────────────────────────────────────────────────────────

async fn cart_get(redis: &mut redis::aio::ConnectionManager, chat_id: &str) -> Vec<CartItem> {
    let raw: Option<String> = redis.get(format!("tg:cart:{chat_id}")).await.unwrap_or(None);
    raw.and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
}

async fn cart_save(redis: &mut redis::aio::ConnectionManager, chat_id: &str, cart: &[CartItem]) {
    if cart.is_empty() {
        let _: Result<(), _> = redis.del(format!("tg:cart:{chat_id}")).await;
    } else {
        let s = serde_json::to_string(cart).unwrap_or_default();
        let _: Result<(), _> = redis.set_ex(format!("tg:cart:{chat_id}"), s, 3600).await;
    }
}

async fn cart_total(cart: &[CartItem]) -> u64 {
    cart.iter().map(|i| i.price_rupees() * i.qty as u64).sum()
}

async fn order_get(redis: &mut redis::aio::ConnectionManager, chat_id: &str) -> Option<OrderFlow> {
    let raw: Option<String> = redis.get(format!("tg:order:{chat_id}")).await.unwrap_or(None);
    raw.and_then(|s| serde_json::from_str(&s).ok())
}

async fn order_save(redis: &mut redis::aio::ConnectionManager, chat_id: &str, flow: &OrderFlow, ttl: u64) {
    let s = serde_json::to_string(flow).unwrap_or_default();
    let _: Result<(), _> = redis.set_ex(format!("tg:order:{chat_id}"), s, ttl).await;
}

async fn order_delete(redis: &mut redis::aio::ConnectionManager, chat_id: &str) {
    let _: Result<(), _> = redis.del(format!("tg:order:{chat_id}")).await;
}

async fn gctx_store(
    redis: &mut redis::aio::ConnectionManager,
    brand: &str, model: &str, year: &str, category: &str,
) -> String {
    let raw  = format!("{brand}:{model}:{year}:{category}");
    let hash = format!("{:x}", md5::compute(raw.as_bytes()));
    let hkey = format!("gk{}", &hash[..8]);
    let ctx  = GuidedCtx {
        brand: brand.into(), model: model.into(),
        year: year.into(),   category: category.into(),
    };
    let s = serde_json::to_string(&ctx).unwrap_or_default();
    let _: Result<(), _> = redis.set_ex(format!("gctx:{hkey}"), s, 7200).await;
    hkey
}

async fn gctx_load(
    redis: &mut redis::aio::ConnectionManager,
    hkey: &str,
) -> GuidedCtx {
    let raw: Option<String> = redis.get(format!("gctx:{hkey}")).await.unwrap_or(None);
    raw.and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
}

async fn part_cache_get(
    redis: &mut redis::aio::ConnectionManager,
    short_key: &str,
) -> Option<CartItem> {
    let raw: Option<String> = redis.get(format!("tg:part:{short_key}")).await.unwrap_or(None);
    raw.and_then(|s| serde_json::from_str(&s).ok())
}

// ─────────────────────────────────────────────────────────────────────────────
// TELEGRAM API HELPERS
// ─────────────────────────────────────────────────────────────────────────────

fn tg_url(token: &str, method: &str) -> String {
    format!("https://api.telegram.org/bot{}/{}", token, method)
}

async fn tg_send(http: &reqwest::Client, token: &str, chat_id: &str, text: &str, markup: Option<Value>) {
    let text = trunc4k(text);
    let mut body = json!({
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": true,
    });
    if let Some(m) = markup {
        body["reply_markup"] = m;
    }
    for attempt in 0..3u8 {
        match http.post(tg_url(token, "sendMessage")).json(&body)
            .timeout(Duration::from_secs(10)).send().await
        {
            Ok(r) if r.status().is_success() => return,
            Ok(r) => { warn!("[tg_bot] send {} attempt {}: {}", chat_id, attempt, r.status()); }
            Err(e) => { warn!("[tg_bot] send {} attempt {}: {}", chat_id, attempt, e); }
        }
        if attempt < 2 { tokio::time::sleep(Duration::from_millis(1500)).await; }
    }
}

async fn tg_send_get_id(http: &reqwest::Client, token: &str, chat_id: &str, text: &str, markup: Option<Value>) -> Option<i64> {
    let text = trunc4k(text);
    let mut body = json!({
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": true,
    });
    if let Some(m) = markup { body["reply_markup"] = m; }
    match http.post(tg_url(token, "sendMessage")).json(&body)
        .timeout(Duration::from_secs(10)).send().await
    {
        Ok(r) if r.status().is_success() => {
            r.json::<Value>().await.ok()
             .and_then(|v| v["result"]["message_id"].as_i64())
        }
        _ => None,
    }
}

async fn tg_answer_callback(http: &reqwest::Client, token: &str, cb_id: &str, text: &str) {
    let _ = http.post(tg_url(token, "answerCallbackQuery"))
        .json(&json!({"callback_query_id": cb_id, "text": text}))
        .timeout(Duration::from_secs(5)).send().await;
}

async fn tg_edit_markup(http: &reqwest::Client, token: &str, chat_id: &str, msg_id: i64, markup: Option<Value>) {
    let _ = http.post(tg_url(token, "editMessageReplyMarkup"))
        .json(&json!({
            "chat_id": chat_id,
            "message_id": msg_id,
            "reply_markup": markup.unwrap_or(json!({"inline_keyboard": []}))
        }))
        .timeout(Duration::from_secs(5)).send().await;
}

async fn tg_edit_text(http: &reqwest::Client, token: &str, chat_id: &str, msg_id: i64, text: &str, markup: Option<Value>) {
    let text = trunc4k(text);
    let mut body = json!({
        "chat_id": chat_id,
        "message_id": msg_id,
        "text": text,
        "parse_mode": "Markdown",
    });
    if let Some(m) = markup { body["reply_markup"] = m; }
    let _ = http.post(tg_url(token, "editMessageText"))
        .json(&body).timeout(Duration::from_secs(5)).send().await;
}

async fn tg_forward(http: &reqwest::Client, token: &str, to: &str, from: &str, msg_id: i64) -> bool {
    match http.post(tg_url(token, "forwardMessage"))
        .json(&json!({"chat_id": to, "from_chat_id": from, "message_id": msg_id}))
        .timeout(Duration::from_secs(10)).send().await
    {
        Ok(r) => r.status().is_success(),
        Err(_) => false,
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TEXT HELPERS
// ─────────────────────────────────────────────────────────────────────────────

fn trunc4k(s: &str) -> &str {
    if s.len() <= 4000 { return s; }
    let mut end = 4000;
    while end > 0 && !s.is_char_boundary(end) { end -= 1; }
    &s[..end]
}

fn cart_text(cart: &[CartItem], delivery: u64) -> String {
    let total: u64 = cart.iter().map(|i| i.price_rupees() * i.qty as u64).sum();
    let mut lines = vec!["🛒 *Your Cart:*\n".to_string()];
    for item in cart {
        let color = if item.color.is_empty() { String::new() } else { format!(" ({})", item.color) };
        lines.push(format!("  • {}{}  × {} — ₹{}",
            item.part_name, color, item.qty, item.price_rupees() * item.qty as u64));
    }
    lines.push(format!("\n💰 Subtotal: ₹{total} + ₹{delivery} delivery = *₹{}*", total + delivery));
    lines.join("\n")
}

fn cart_keyboard(cart: &[CartItem], delivery: u64) -> Value {
    let total: u64 = cart.iter().map(|i| i.price_rupees() * i.qty as u64).sum();
    let mut rows: Vec<Value> = vec![];
    for item in cart {
        let short = &item.part_id[..item.part_id.len().min(8)];
        let color = if item.color.is_empty() { String::new() } else { format!(" ({})", item.color) };
        let pr = item.price_rupees() * item.qty as u64;
        rows.push(json!([{"text": format!("{}{} — ₹{}", item.part_name, color, pr), "callback_data": "noop"}]));
        rows.push(json!([
            {"text": "➖", "callback_data": format!("pr:{}", short)},
            {"text": format!("Qty: {}", item.qty), "callback_data": "noop"},
            {"text": "➕", "callback_data": format!("po:{}", short)},
        ]));
    }
    rows.push(json!([
        {"text": "🗑 Clear",                                "callback_data": "tg_clear_cart"},
        {"text": format!("✅ Checkout ₹{}", total + delivery), "callback_data": "tg_checkout"},
    ]));
    json!({"inline_keyboard": rows})
}

// ─────────────────────────────────────────────────────────────────────────────
// PYTHON SIDECAR CALLS
// ─────────────────────────────────────────────────────────────────────────────

/// Forward a text message to Python for auto-reply / order flow handling.
/// Python returns { "handled": bool, "reply": str|null, "part_id": str|null,
///                  "reply_type": "meta"|"suggest"|"notfound"|"plain"|null }
async fn py_text(
    http: &reqwest::Client,
    py: &str,
    chat_id: &str,
    session_id: &str,
    text: &str,
    username: &str,
) -> Value {
    match http.post(format!("{py}/internal/tg-text"))
        .json(&json!({
            "chat_id":    chat_id,
            "session_id": session_id,
            "text":       text,
            "username":   username,
        }))
        .timeout(Duration::from_secs(30)).send().await
    {
        Ok(r) => r.json::<Value>().await.unwrap_or(json!({"handled": false})),
        Err(e) => { error!("[tg_bot] py_text: {}", e); json!({"handled": false}) }
    }
}

/// Forward a photo update to Python.
async fn py_photo(http: &reqwest::Client, py: &str, update: &Value) {
    let _ = http.post(format!("{py}/internal/tg-photo"))
        .json(update)
        .timeout(Duration::from_secs(15)).send().await;
}

/// Forward an owner-reply-to-customer message to Python.
async fn py_owner_reply(http: &reqwest::Client, py: &str, text: &str, replied_text: &str) {
    let _ = http.post(format!("{py}/internal/tg-owner-reply"))
        .json(&json!({"text": text, "replied_to_text": replied_text}))
        .timeout(Duration::from_secs(10)).send().await;
}

/// Notify Python that a Razorpay payment succeeded (webhook from Razorpay)
/// — not needed until Stage 3; placeholder.
async fn py_razorpay_paid(http: &reqwest::Client, py: &str, payload: &Value) {
    let _ = http.post(format!("{py}/internal/razorpay-webhook"))
        .json(payload)
        .timeout(Duration::from_secs(10)).send().await;
}

// ─────────────────────────────────────────────────────────────────────────────
// RAZORPAY
// ─────────────────────────────────────────────────────────────────────────────

async fn razorpay_create_link(
    http: &reqwest::Client,
    key: &str, secret: &str,
    amount_paise: u64, name: &str, phone: &str,
) -> Option<String> {
    if key.is_empty() || secret.is_empty() { return None; }
    match http.post("https://api.razorpay.com/v1/payment_links")
        .basic_auth(key, Some(secret))
        .json(&json!({
            "amount": amount_paise,
            "currency": "INR",
            "description": "Lakshmi Motorcycles Order",
            "customer": {"name": name, "contact": format!("+91{}", phone)},
            "notify": {"sms": true, "email": false},
            "reminder_enable": false,
            "callback_method": "get",
        }))
        .timeout(Duration::from_secs(10)).send().await
    {
        Ok(r) if r.status().is_success() => {
            r.json::<Value>().await.ok()
             .and_then(|v| v["short_url"].as_str().map(str::to_string))
        }
        Ok(r) => { warn!("[tg_bot] razorpay {}", r.status()); None }
        Err(e) => { error!("[tg_bot] razorpay: {}", e); None }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ORDER FLOW STATE MACHINE
// Returns Some(true) if text was consumed by the flow, None if no active flow.
// ─────────────────────────────────────────────────────────────────────────────

async fn admin_setting_value(redis: &mut redis::aio::ConnectionManager, key: &str) -> Option<Value> {
    let raw: Option<String> = redis.get("admin:settings").await.unwrap_or(None);
    let settings: Value = serde_json::from_str(raw.as_deref()?).ok()?;
    settings.get(key).cloned()
}

async fn admin_setting_bool(redis: &mut redis::aio::ConnectionManager, key: &str, default: bool) -> bool {
    admin_setting_value(redis, key).await.and_then(|v| v.as_bool()).unwrap_or(default)
}

async fn admin_setting_u64(redis: &mut redis::aio::ConnectionManager, key: &str, default: u64) -> u64 {
    admin_setting_value(redis, key).await
        .and_then(|v| v.as_u64().or_else(|| v.as_f64().filter(|n| *n >= 0.0).map(|n| n.round() as u64)))
        .unwrap_or(default)
}


async fn delivery_for_address(redis: &mut redis::aio::ConnectionManager, address: &str, fallback: u64) -> u64 {
    let base = admin_setting_u64(redis, "delivery_charge", fallback).await;
    // Extract 6-digit Indian pincode from address
    for token in address.split(|c: char| !c.is_ascii_digit()) {
        if token.len() == 6 && !token.starts_with('0') {
            let key = format!("delivery:zone:{token}");
            if let Ok(Some(raw)) = redis.get::<_, Option<String>>(&key).await {
                if let Ok(val) = serde_json::from_str::<Value>(&raw) {
                    if let Some(charge) = val.get("delivery_charge").and_then(|v| v.as_f64()) {
                        if charge >= 0.0 {
                            return charge.round() as u64;
                        }
                    }
                }
            }
        }
    }
    base
}

async fn handle_order_flow(
    st: &AppState,
    chat_id: &str,
    session_id: &str,
    text: &str,
) -> Option<bool> {
    let mut redis = st.redis.clone();
    let flow = order_get(&mut redis, chat_id).await?;
    let token = &st.cfg.token;
    let delivery = delivery_for_address(&mut redis, &flow.address, st.cfg.delivery).await;

    if !admin_setting_bool(&mut redis, "orders_enabled", true).await {
        order_delete(&mut redis, chat_id).await;
        tg_send(&st.http, token, chat_id,
            "Ordering is temporarily unavailable. Please contact the shop directly.", None).await;
        return Some(true);
    }

    // Cancel keywords (Telugu + English)
    let cancel_words = ["cancel", "stop", "ledu", "vaddhu", "vaddu", "venakki"];
    let text_lower = text.to_lowercase();
    if cancel_words.iter().any(|w| text_lower.contains(w)) {
        order_delete(&mut redis, chat_id).await;
        let msg = "❌ Order cancel chesamu. 🙏 Inkemi kavali ante cheppandi!";
        tg_send(&st.http, token, chat_id, msg, None).await;
        py_save_chat(&st.http, &st.cfg.python_url, session_id, "bot", msg).await;
        return Some(true);
    }

    match flow.state.as_str() {
        "await_name" => {
            let name = text.trim();
            if name.len() < 2 {
                let msg = "📝 *Step 1 of 3* — Correct full name cheppandi (minimum 2 letters):";
                tg_send(&st.http, token, chat_id, msg, None).await;
                return Some(true);
            }
            let mut f = flow.clone();
            f.name  = name.to_string();
            f.state = "await_phone".to_string();
            order_save(&mut redis, chat_id, &f, 1800).await;
            let msg = format!("✅ Name: *{name}*\n\n📞 *Step 2 of 3* — Phone number cheppandi _(10 digits)_:");
            tg_send(&st.http, token, chat_id, &msg, None).await;
            Some(true)
        }
        "await_phone" => {
            let digits: String = text.chars().filter(|c| c.is_ascii_digit()).collect();
            if digits.len() < 10 {
                tg_send(&st.http, token, chat_id,
                    "📞 *Step 2 of 3* — Valid 10-digit phone number cheppandi:", None).await;
                return Some(true);
            }
            let phone = digits[digits.len()-10..].to_string();
            let mut f = flow.clone();
            f.phone = phone.clone();
            f.state = "await_address".to_string();
            order_save(&mut redis, chat_id, &f, 1800).await;
            let msg = format!("✅ Phone: *+91 {phone}*\n\n📍 *Step 3 of 3* — Delivery address cheppandi\n_(Street, City, District, Pincode)_:");
            tg_send(&st.http, token, chat_id, &msg, None).await;
            Some(true)
        }
        "await_address" => {
            let address = text.trim();
            if address.len() < 10 {
                tg_send(&st.http, token, chat_id,
                    "Complete address cheppandi (street, city, pincode):", None).await;
                return Some(true);
            }
            let mut f = flow.clone();
            f.address = address.to_string();
            f.state   = "choose_payment".to_string();
            order_save(&mut redis, chat_id, &f, 1800).await;
            let delivery = delivery_for_address(&mut redis, address, st.cfg.delivery).await;

            // Build order summary
            let cart   = &f.cart;
            let total  = cart.iter().map(|i| i.price_rupees() * i.qty as u64).sum::<u64>();
            let pf     = (total as f64 * 0.01).round() as u64;
            let mut lines = vec![
                "📋 *Order Confirmation*".to_string(),
                "─".repeat(28),
                format!("👤 *{}*", f.name),
                format!("📞 +91 {}", f.phone),
                format!("📍 {}", address),
                String::new(),
            ];
            for item in cart {
                let color = if item.color.is_empty() { String::new() } else { format!(" · {}", item.color) };
                let bike  = format!("{} {} {}", item.bike_brand, item.bike_model, item.bike_year).trim().to_string();
                if !bike.is_empty() { lines.push(format!("🏍 *{bike}*")); }
                lines.push(format!("  • {}{}  × {} — ₹{}", item.part_name, color, item.qty, item.price_rupees() * item.qty as u64));
            }
            lines.extend([
                String::new(),
                "─".repeat(28),
                format!("💰 Subtotal  : ₹{total}"),
                format!("🚚 Delivery  : ₹{delivery}"),
                format!("💳 UPI Total : *₹{}*", total + delivery),
                format!("💳 Razorpay  : ₹{} _(+₹{pf} fee)_", total + delivery + pf),
                "─".repeat(28),
                String::new(),
                "*Payment method choose cheyandi:*".to_string(),
            ]);

            let mut pay_row: Vec<Value> = vec![];
            if !st.cfg.rzp_key.is_empty()  { pay_row.push(json!({"text": "💳 Razorpay", "callback_data": "pay_razorpay"})); }
            if !st.cfg.upi_id.is_empty()   { pay_row.push(json!({"text": "📲 Pay UPI",  "callback_data": "pay_upi"})); }
            if pay_row.is_empty()           { pay_row.push(json!({"text": "📲 Pay via UPI", "callback_data": "pay_upi"})); }

            tg_send(&st.http, token, chat_id, &lines.join("\n"),
                Some(json!({"inline_keyboard": [pay_row]}))).await;
            Some(true)
        }
        "await_upi_screenshot" => {
            tg_send(&st.http, token, chat_id,
                "📸 Screenshot pampandi (image ga send cheyandi). Text message accept avvaledhu.", None).await;
            Some(true)
        }
        "choose_payment" => {
            let total = flow.total;
            let mut kb: Vec<Value> = vec![];
            if !st.cfg.rzp_key.is_empty() {
                kb.push(json!([{"text": "💳 Pay Online (Razorpay)", "callback_data": "pay_razorpay"}]));
            }
            if !st.cfg.upi_id.is_empty() {
                kb.push(json!([{"text": "📲 Pay via UPI (Manual)", "callback_data": "pay_upi"}]));
            }
            if kb.is_empty() { kb.push(json!([{"text": "📲 Pay via UPI", "callback_data": "pay_upi"}])); }
            tg_send(&st.http, token, chat_id,
                &format!("👆 Please select a payment method using the buttons above.\nTotal: ₹{} (incl. ₹{delivery} delivery)", total + delivery),
                Some(json!({"inline_keyboard": kb}))).await;
            Some(true)
        }
        "await_razorpay" => {
            tg_send(&st.http, token, chat_id,
                "💳 Please complete payment using the Razorpay link sent above.\nLink 15 minutes valid.", None).await;
            Some(true)
        }
        _ => Some(false),
    }
}

// Small helper: ask Python to persist a chat message (fire-and-forget)
async fn py_save_chat(http: &reqwest::Client, py: &str, session_id: &str, sender: &str, msg: &str) {
    let _ = http.post(format!("{py}/internal/save-chat"))
        .json(&json!({"session_id": session_id, "sender": sender, "message": msg}))
        .timeout(Duration::from_secs(5)).send().await;
}

// ─────────────────────────────────────────────────────────────────────────────
// PLACE ORDER  — calls Python /internal/place-tg-order
// ─────────────────────────────────────────────────────────────────────────────

async fn place_order(
    st: &AppState,
    chat_id: &str,
    session_id: &str,
    flow: &OrderFlow,
    payment_method: &str,
    txn_id: Option<&str>,
) {
    match st.http.post(format!("{}/internal/place-tg-order", st.cfg.python_url))
        .json(&json!({
            "chat_id":        chat_id,
            "session_id":     session_id,
            "flow":           flow,
            "payment_method": payment_method,
            "txn_id":         txn_id,
        }))
        .timeout(Duration::from_secs(20)).send().await
    {
        Ok(r) if r.status().is_success() => {
            // Python sends the confirmation message to the customer directly
        }
        Ok(r) => {
            warn!("[tg_bot] place_order Python returned {}", r.status());
            tg_send(&st.http, &st.cfg.token, chat_id,
                "Order place cheyyaledhu. 😔 Owner ki message pampistam!", None).await;
        }
        Err(e) => {
            error!("[tg_bot] place_order: {}", e);
            tg_send(&st.http, &st.cfg.token, chat_id,
                "Order place cheyyaledhu. 😔 Owner ki message pampistam!", None).await;
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CALLBACK QUERY HANDLER
// ─────────────────────────────────────────────────────────────────────────────

async fn handle_callback(st: &AppState, data: &Value) {
    let cb      = &data["callback_query"];
    let cb_id   = cb["id"].as_str().unwrap_or("");
    let cb_data = cb["data"].as_str().unwrap_or("");
    let chat_id = cb["message"]["chat"]["id"].to_string();
    let msg_id  = cb["message"]["message_id"].as_i64().unwrap_or(0);
    let token   = &st.cfg.token;
    let owner   = &st.cfg.owner_id;
    let session_id = format!("tg_{chat_id}");

    let mut redis = st.redis.clone();
    let delivery = delivery_for_address(&mut redis, &flow.address, st.cfg.delivery).await;

    match parse_callback(cb_data) {
        CallbackAction::Noop => {
            tg_answer_callback(&st.http, token, cb_id, "").await;
        }

        // ── Cart: add from parts-list (po: short key) ─────────────────────
        CallbackAction::PartAdd(short_key) => {
            let part = part_cache_get(&mut redis, short_key).await;
            match part {
                None => { tg_answer_callback(&st.http, token, cb_id, "❌ Part info not found, try again.").await; }
                Some(p) => {
                    let mut cart = cart_get(&mut redis, &chat_id).await;
                    if let Some(ex) = cart.iter_mut().find(|i| i.part_id == p.part_id) {
                        ex.qty += 1;
                    } else {
                        let mut np = p.clone(); np.qty = 1;
                        cart.push(np);
                    }
                    cart_save(&mut redis, &chat_id, &cart).await;
                    tg_answer_callback(&st.http, token, cb_id, &format!("✅ Added! {} in cart", cart.len())).await;

                    // Refresh keyboard on the message (parts list or cart view)
                    let msg_text = cb["message"]["text"].as_str().unwrap_or("");
                    if msg_text.starts_with("🛒 *Your Cart") {
                        let total = cart_total(&cart).await;
                        tg_edit_text(&st.http, token, &chat_id, msg_id,
                            &cart_text(&cart, delivery), Some(cart_keyboard(&cart, delivery))).await;
                    } else {
                        // Parts-list message — refresh markup from stored text (Python still serves this)
                        let orig: Option<String> = redis.get(format!("tg:msgtext:{chat_id}:{msg_id}")).await.unwrap_or(None);
                        if let Some(_) = orig {
                            // Ask Python to rebuild list keyboard and edit the markup
                            let _ = st.http.post(format!("{}/internal/tg-refresh-markup", st.cfg.python_url))
                                .json(&json!({"chat_id": chat_id, "msg_id": msg_id}))
                                .timeout(Duration::from_secs(5)).send().await;
                        }
                    }
                }
            }
        }

        // ── Cart: remove ──────────────────────────────────────────────────
        CallbackAction::PartRemove(short_key) => {
            let cached = part_cache_get(&mut redis, short_key).await;
            let part_id = cached.map(|p| p.part_id).unwrap_or_else(|| short_key.to_string());
            let mut cart = cart_get(&mut redis, &chat_id).await;
            if let Some(idx) = cart.iter().position(|i| i.part_id == part_id) {
                if cart[idx].qty > 1 { cart[idx].qty -= 1; } else { cart.remove(idx); }
            }
            cart_save(&mut redis, &chat_id, &cart).await;
            tg_answer_callback(&st.http, token, cb_id, &format!("➖ {} in cart", cart.len())).await;

            let msg_text = cb["message"]["text"].as_str().unwrap_or("");
            if msg_text.starts_with("🛒 *Your Cart") {
                if cart.is_empty() {
                    tg_edit_text(&st.http, token, &chat_id, msg_id,
                        "🛒 Cart empty. Parts choose cheyyandi!", None).await;
                } else {
                    tg_edit_text(&st.http, token, &chat_id, msg_id,
                        &cart_text(&cart, delivery), Some(cart_keyboard(&cart, delivery))).await;
                }
            }
        }

        // ── View Cart ─────────────────────────────────────────────────────
        CallbackAction::ViewCart => {
            let cart = cart_get(&mut redis, &chat_id).await;
            if cart.is_empty() {
                tg_answer_callback(&st.http, token, cb_id, "Cart is empty!").await;
            } else {
                tg_answer_callback(&st.http, token, cb_id, "").await;
                tg_send(&st.http, token, &chat_id,
                    &cart_text(&cart, delivery), Some(cart_keyboard(&cart, delivery))).await;
            }
        }

        // ── Clear Cart ────────────────────────────────────────────────────
        CallbackAction::ClearCart => {
            let _: Result<(), _> = redis.del(format!("tg:cart:{chat_id}")).await;
            tg_answer_callback(&st.http, token, cb_id, "🗑 Cart cleared!").await;
            tg_edit_text(&st.http, token, &chat_id, msg_id,
                "🗑 Cart clear chesamu. Parts choose cheyyandi!", None).await;
        }

        // ── Checkout ──────────────────────────────────────────────────────
        CallbackAction::Checkout => {
            if !admin_setting_bool(&mut redis, "orders_enabled", true).await {
                tg_answer_callback(&st.http, token, cb_id, "Ordering is temporarily unavailable.").await;
                tg_send(&st.http, token, &chat_id,
                    "Ordering is temporarily unavailable. Please contact the shop directly.", None).await;
                return;
            }
            let cart = cart_get(&mut redis, &chat_id).await;
            if cart.is_empty() {
                tg_answer_callback(&st.http, token, cb_id, "Cart is empty!").await;
                return;
            }
            tg_answer_callback(&st.http, token, cb_id, "").await;
            let total = cart_total(&cart).await;
            let pf    = (total as f64 * 0.01).round() as u64;
            let flow  = OrderFlow {
                state: "await_name".to_string(),
                cart:  cart.clone(),
                total,
                name: String::new(), phone: String::new(),
                address: String::new(), rzp_amount: 0,
            };
            order_save(&mut redis, &chat_id, &flow, 1800).await;

            let mut lines: Vec<String> = vec!["🛒 *Order Checkout*".into(), "─".repeat(28)];
            for item in &cart {
                let color = if item.color.is_empty() { String::new() } else { format!(" · {}", item.color) };
                lines.push(format!("  • {}{}  × {} — ₹{}", item.part_name, color, item.qty, item.price_rupees() * item.qty as u64));
            }
            lines.extend([
                "─".repeat(28),
                format!("💰 Subtotal  : ₹{total}"),
                format!("🚚 Delivery  : ₹{delivery}"),
                format!("💳 UPI Total : *₹{}*", total + delivery),
                format!("💳 Razorpay  : ₹{} _(+₹{pf} fee)_", total + delivery + pf),
                "─".repeat(28),
                String::new(),
                "📝 *Step 1 of 3* — Meeru *full name* cheppandi:".into(),
            ]);
            tg_send(&st.http, token, &chat_id, &lines.join("\n"), None).await;
        }

        // ── Payment: Razorpay ─────────────────────────────────────────────
        CallbackAction::PayRazorpay => {
            if !admin_setting_bool(&mut redis, "orders_enabled", true).await {
                tg_answer_callback(&st.http, token, cb_id, "Ordering is temporarily unavailable.").await;
                return;
            }
            tg_answer_callback(&st.http, token, cb_id, "").await;
            let flow = match order_get(&mut redis, &chat_id).await {
                Some(f) if !f.name.is_empty() => f,
                _ => { tg_send(&st.http, token, &chat_id, "Session expired. Please start again.", None).await; return; }
            };
            let total = flow.total;
            let pf    = (total as f64 * 0.01).round() as u64;
            let amount_paise = (total + delivery + pf) * 100;
            match razorpay_create_link(&st.http, &st.cfg.rzp_key, &st.cfg.rzp_secret,
                amount_paise, &flow.name, &flow.phone).await
            {
                Some(link) => {
                    let mut f2 = flow.clone();
                    f2.state      = "await_razorpay".to_string();
                    f2.rzp_amount = total + delivery + pf;
                    order_save(&mut redis, &chat_id, &f2, 1800).await;
                    tg_send(&st.http, token, &chat_id, &format!(
                        "💳 *Razorpay Payment Link:*\n\nSubtotal: ₹{total}\nDelivery: ₹{delivery}\nPlatform fee (1%): ₹{pf}\n*Total: ₹{}*\n\n👉 {link}\n\nPayment chesina taruvata order automatic ga place avutundi.\n_(Link 15 minutes valid)_",
                        total + delivery + pf
                    ), None).await;
                }
                None => {
                    tg_send(&st.http, token, &chat_id, "❌ Payment link create cheyyaledhu. UPI try cheyandi.", None).await;
                }
            }
        }

        // ── Payment: UPI ──────────────────────────────────────────────────
        CallbackAction::PayUpi => {
            if !admin_setting_bool(&mut redis, "orders_enabled", true).await {
                tg_answer_callback(&st.http, token, cb_id, "Ordering is temporarily unavailable.").await;
                return;
            }
            tg_answer_callback(&st.http, token, cb_id, "").await;
            let flow = match order_get(&mut redis, &chat_id).await {
                Some(f) if !f.name.is_empty() => f,
                _ => { tg_send(&st.http, token, &chat_id, "Session expired. Please start again.", None).await; return; }
            };
            let total = flow.total;
            let mut f2 = flow.clone();
            f2.state = "await_upi_screenshot".to_string();
            order_save(&mut redis, &chat_id, &f2, 1800).await;
            tg_send(&st.http, token, &chat_id, &format!(
                "📲 *UPI Payment:*\n\nUPI ID: `{}`\nAmount: *₹{}*\n\nPayment chesina taruvata *screenshot* ikkade send cheyandi.\nOwner verify chesi order confirm chestaru. ✅",
                st.cfg.upi_id, total + delivery
            ), None).await;
        }

        // ── UPI: owner approves ───────────────────────────────────────────
        CallbackAction::UpiApprove(cust_id, txn_id) => {
            if chat_id != *owner {
                tg_answer_callback(&st.http, token, cb_id, "Not authorized.").await;
                return;
            }
            tg_answer_callback(&st.http, token, cb_id, "").await;
            if let Some(flow) = order_get(&mut redis, cust_id).await {
                order_delete(&mut redis, cust_id).await;
                place_order(st, cust_id, &format!("tg_{cust_id}"), &flow, "upi", Some(txn_id)).await;
                tg_edit_markup(&st.http, token, &chat_id, msg_id, None).await;
                tg_send(&st.http, token, owner, &format!("✅ Order approved for {cust_id}"), None).await;
            }
        }

        // ── UPI: owner rejects ────────────────────────────────────────────
        CallbackAction::UpiReject(cust_id) => {
            if chat_id != *owner {
                tg_answer_callback(&st.http, token, cb_id, "Not authorized.").await;
                return;
            }
            tg_answer_callback(&st.http, token, cb_id, "").await;
            order_delete(&mut redis, cust_id).await;
            let _: Result<(), _> = redis.del(format!("tg:cart:{cust_id}")).await;
            tg_send(&st.http, token, cust_id,
                &format!("❌ Payment verify cheyyaledhu.\nCorrect screenshot pampandi ledu owner ki contact cheyandi.\n📞 +91 {}", st.cfg.owner_phone),
                None).await;
            tg_edit_markup(&st.http, token, &chat_id, msg_id, None).await;
            tg_send(&st.http, token, owner, &format!("❌ Payment rejected for {cust_id}"), None).await;
        }

        // ── Suggest / Bike selector / Guided browse ───────────────────────
        // These all require Supabase queries (parts catalogue) — delegate to Python.
        // Python handles the Supabase call and sends the response directly.
        CallbackAction::Suggest(_, _)
        | CallbackAction::BikeBrand(_)
        | CallbackAction::BikeSelectStart
        | CallbackAction::BikeModel(_, _)
        | CallbackAction::BikeYear(_, _, _)
        | CallbackAction::GuidedDismiss
        | CallbackAction::GuidedYrDone(_)
        | CallbackAction::GuidedCat(_)
        | CallbackAction::GuidedPart(_, _)
        | CallbackAction::GuidedImg(_)
        | CallbackAction::GuidedQty(_, _, _, _)
        | CallbackAction::GuidedAdd(_, _, _)
        | CallbackAction::AddAll(_) => {
            // Answer immediately so Telegram stops showing the spinner
            tg_answer_callback(&st.http, token, cb_id, "").await;
            // Forward full callback update to Python — it handles the catalogue query
            let _ = st.http.post(format!("{}/internal/tg-callback", st.cfg.python_url))
                .json(data)
                .timeout(Duration::from_secs(20)).send().await;
        }

        CallbackAction::Unknown => {
            tg_answer_callback(&st.http, token, cb_id, "").await;
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MESSAGE HANDLER
// ─────────────────────────────────────────────────────────────────────────────

async fn handle_message(st: &AppState, msg: &Value) {
    let chat_id    = msg["chat"]["id"].to_string();
    let text       = msg["text"].as_str().unwrap_or("").trim().to_string();
    let username   = msg["from"]["username"].as_str().unwrap_or("");
    let first_name = msg["from"]["first_name"].as_str().unwrap_or("");
    let session_id = format!("tg_{chat_id}");
    let token      = &st.cfg.token;
    let owner      = &st.cfg.owner_id;
    let mut settings_redis = st.redis.clone();
    let delivery = admin_setting_u64(&mut settings_redis, "delivery_charge", st.cfg.delivery).await;

    // ── Owner reply to a forwarded customer question ──────────────────────
    if chat_id == *owner {
        if let Some(replied) = msg.get("reply_to_message") {
            let replied_text = replied["text"].as_str().unwrap_or("");
            if replied_text.contains("Customer question") && !text.is_empty() {
                py_owner_reply(&st.http, &st.cfg.python_url, &text, replied_text).await;
                tg_send(&st.http, token, owner, "✅ Answer sent to customer and bot trained!", None).await;
            }
        }
        return;  // owner's own messages stop here
    }

    // ── Photo ─────────────────────────────────────────────────────────────
    if msg.get("photo").is_some() {
        // Check if we're in await_upi_screenshot state
        let mut redis = st.redis.clone();
        if let Some(flow) = order_get(&mut redis, &chat_id).await {
            if flow.state == "await_upi_screenshot" {
                let file_id = msg["photo"].as_array()
                    .and_then(|a| a.last())
                    .and_then(|p| p["file_id"].as_str())
                    .unwrap_or("");
                let total = flow.total;

                // Build cart summary for owner — bike at top, then parts
                // Collect unique bike line (brand model year) from cart items
                let bike_header = {
                    let b = flow.cart.first().map(|i| {
                        [i.bike_brand.as_str(), i.bike_model.as_str(), i.bike_year.as_str()]
                            .iter().filter(|s| !s.is_empty()).copied()
                            .collect::<Vec<_>>().join(" ")
                    }).unwrap_or_default();
                    if b.is_empty() { String::new() } else { format!("🏍️ *{}*

", b) }
                };

                let mut cart_lines: Vec<String> = vec![];
                let subtotal: u64 = flow.cart.iter().map(|i| i.price_rupees() * i.qty as u64).sum();
                for item in &flow.cart {
                    let color = if item.color.is_empty() { String::new() } else { format!(" · {}", item.color) };
                    let pr = item.price_rupees() * item.qty as u64;
                    cart_lines.push(format!("  • {}{}  × {} — ₹{}", item.part_name, color, item.qty, pr));
                }

                tg_forward(&st.http, token, owner, &chat_id,
                    msg["message_id"].as_i64().unwrap_or(0)).await;

                tg_send(&st.http, token, owner, &format!(
                    "📲 *UPI Payment Screenshot*

                    {}                    👤 *{}*
                    📞 {}
                    📍 {}

                    *Parts:*
                    {}

                    ――――――――――――――
                    💰 Subtotal : ₹{}
                    🚚 Delivery : ₹{}
                    💳 *Total   : ₹{}*
                    ――――――――――――――

                    💬 Telegram: {}
                    Verify chesi approve or reject cheyandi:",
                    bike_header,
                    flow.name, flow.phone, flow.address,
                    cart_lines.join("
"),
                    subtotal, delivery, subtotal + delivery, chat_id
                ), Some(json!({"inline_keyboard": [[
                    {"text": "✅ Approve", "callback_data": format!("upi_approve:{}:{}", chat_id, &file_id[..file_id.len().min(20)])},
                    {"text": "❌ Reject",  "callback_data": format!("upi_reject:{}:", chat_id)},
                ]]}))).await;

                tg_send(&st.http, token, &chat_id,
                    "📸 Screenshot received! Owner verify chestaru — koంchem wait cheyandi. ⏳", None).await;
                return;
            }
        }
        // Regular photo — delegate to Python (admin panel broadcast)
        py_photo(&st.http, &st.cfg.python_url, msg).await;
        return;
    }

    if text.is_empty() { return; }

    // ── Dedup (Telegram retries same message_id when we're slow) ─────────
    let tg_msg_id = msg["message_id"].as_i64().unwrap_or(0);
    let dedup_key = format!("tg:seen:{chat_id}:{tg_msg_id}");
    {
        let mut redis = st.redis.clone();
        let seen: Option<String> = redis.get(&dedup_key).await.unwrap_or(None);
        if seen.is_some() { return; }
        let _: Result<(), _> = redis.set_ex(&dedup_key, "1", 3600).await;
    }

    // ── /start ────────────────────────────────────────────────────────────
    if text.starts_with("/start") {
        let greeting = format!(
            "Namaste {first_name}! 🙏 Lakshmi Motorcycle Spares ki swaagatam!\n\n\
            Spare parts order cheyyadaniki *2 ways* unnai:\n\n\
            1️⃣ *Type cheyyi* — part name or bike model type cheyyi\n\
               _Example: 'Splendor brake pad'_\n\n\
            2️⃣ *Buttons use cheyyi* — brand → model → year → category → part\n\
               _(Reading/typing radu ante idi use cheyyi!)_\n\n\
            🌐 lakshmimotorcyclespares.in"
        );
        tg_send(&st.http, token, &chat_id, &greeting, Some(json!({"inline_keyboard": [
            [{"text": "🔘 Browse by Button (Easy)", "callback_data": "guided_browse_start"}],
            [{"text": "🔍 Search by Typing",        "callback_data": "noop"}],
            [{"text": "🛒 View Cart",               "callback_data": "tg_view_cart"}],
            [{"text": "💬 Owner tho Chat",          "url":  "https://t.me/Lakshmi_Motorcycle_spares"}],
        ]}))).await;
        py_save_chat(&st.http, &st.cfg.python_url, &session_id, "bot", &greeting).await;
        return;
    }

    // ── /cart ─────────────────────────────────────────────────────────────
    if text.starts_with("/cart") {
        let mut redis = st.redis.clone();
        let cart = cart_get(&mut redis, &chat_id).await;
        if cart.is_empty() {
            tg_send(&st.http, token, &chat_id,
                "🛒 Mee cart empty undi.\n\nPart name cheppandi — add chestam! 😊", None).await;
        } else {
            tg_send(&st.http, token, &chat_id,
                &cart_text(&cart, delivery), Some(cart_keyboard(&cart, delivery))).await;
        }
        return;
    }

    // ── /help ─────────────────────────────────────────────────────────────
    if text.starts_with("/help") {
        tg_send(&st.http, token, &chat_id,
            &format!("📞 *Help & Contact*\n\nOwner tho direct ga matladadaniki:\n\n💬 Telegram lo message cheyyi\n📞 Call: +91 {}", st.cfg.owner_phone),
            Some(json!({"inline_keyboard": [[
                {"text": "💬 Chat with Owner", "url": format!("https://t.me/+91{}", st.cfg.owner_phone)},
                {"text": "📞 Call Owner",      "url": format!("tel:+91{}", st.cfg.owner_phone)},
            ]]}))).await;
        return;
    }

    // ── /history ─────────────────────────────────────────────────────────
    if text.starts_with("/history") {
        // Delegate to Python — needs Supabase order lookup
        py_text(&st.http, &st.cfg.python_url, &chat_id, &session_id, &text, username).await;
        return;
    }

    // ── Active order flow ─────────────────────────────────────────────────
    if let Some(_) = handle_order_flow(st, &chat_id, &session_id, &text).await {
        return;
    }

    // The Rust bot has its own answer engine, so honor the same admin switch as
    // the Python/web chat engine by routing disabled replies to the human path.
    let mut settings_redis = st.redis.clone();
    if !admin_setting_bool(&mut settings_redis, "auto_reply", true).await {
        py_text(&st.http, &st.cfg.python_url, &chat_id, &session_id, &text, username).await;
        return;
    }

    // ── Everything else → Brain (pure Rust, no Python) ───────────────────
    let brain_reply = {
        let mut brain = st.brain.lock().await;
        brain.process(&session_id, username, &text).await
    };

    if brain_reply.save_chat {
        py_save_chat(&st.http, &st.cfg.python_url, &session_id, "customer", &text).await;
        py_save_chat(&st.http, &st.cfg.python_url, &session_id, "bot", &brain_reply.text).await;
    }

    tg_send(&st.http, &st.cfg.token, &chat_id,
        &brain_reply.text, brain_reply.keyboard).await;
}

// ─────────────────────────────────────────────────────────────────────────────
// AXUM ROUTE: POST /api/telegram/webhook
// ─────────────────────────────────────────────────────────────────────────────

async fn webhook_handler(
    State(st): State<AppState>,
    Json(body): Json<Value>,
) -> impl IntoResponse {
    if body.get("callback_query").is_some() {
        let st2 = st.clone();
        let b2  = body.clone();
        tokio::spawn(async move { handle_callback(&st2, &b2).await });
    } else if let Some(msg) = body.get("message").or_else(|| body.get("edited_message")) {
        let st2 = st.clone();
        let m2  = msg.clone();
        tokio::spawn(async move { handle_message(&st2, &m2).await });
    }

    // Always respond 200 immediately — Telegram won't retry if we're fast
    StatusCode::OK
}

async fn health() -> impl IntoResponse { "ok" }

// ─────────────────────────────────────────────────────────────────────────────
// WEBHOOK REGISTRATION
// ─────────────────────────────────────────────────────────────────────────────

async fn register_webhook(http: &reqwest::Client, token: &str, site_url: &str) {
    let url = format!("{site_url}/api/telegram/webhook");
    match http.post(tg_url(token, "setWebhook"))
        .json(&json!({"url": url, "allowed_updates": ["message", "callback_query"]}))
        .timeout(Duration::from_secs(10)).send().await
    {
        Ok(r) => {
            let ok = r.json::<Value>().await.unwrap_or_default()["ok"].as_bool().unwrap_or(false);
            info!("[tg_bot] webhook {}: {url}", if ok { "registered" } else { "FAILED" });
        }
        Err(e) => error!("[tg_bot] register_webhook: {e}"),
    }

    // Register bot commands
    let _ = http.post(tg_url(token, "setMyCommands"))
        .json(&json!({"commands": [
            {"command": "start",   "description": "Welcome message"},
            {"command": "cart",    "description": "View your current cart"},
            {"command": "history", "description": "View your previous orders"},
            {"command": "help",    "description": "Contact owner / get help"},
        ]}))
        .timeout(Duration::from_secs(10)).send().await;
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> Result<()> {
    dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env()
            .add_directive("tg_bot=info".parse()?))
        .init();

    let cfg = Arc::new(Config {
        token:       std::env::var("TELEGRAM_TOKEN").expect("TELEGRAM_TOKEN required"),
        owner_id:    std::env::var("TELEGRAM_CHAT_ID").unwrap_or_default(),
        owner_phone: std::env::var("OWNER_PHONE_NUMBER").unwrap_or_else(|_| "9160201088".into()),
        upi_id:      std::env::var("OWNER_UPI_ID").unwrap_or_default(),
        rzp_key:     std::env::var("RAZORPAY_KEY_ID").unwrap_or_default(),
        rzp_secret:  std::env::var("RAZORPAY_KEY_SECRET").unwrap_or_default(),
        python_url:  std::env::var("PYTHON_API_URL").unwrap_or_else(|_| "http://127.0.0.1:5000".into()),
        delivery:    std::env::var("DELIVERY_CHARGE").ok()
                         .and_then(|s| s.parse().ok()).unwrap_or(200),
        supabase_url: std::env::var("SUPABASE_URL").unwrap_or_default(),
        supabase_key: std::env::var("SUPABASE_KEY").unwrap_or_default(),
    });

    let redis_url  = std::env::var("REDIS_URL").unwrap_or_else(|_| "redis://127.0.0.1:6379".into());
    let redis_client = redis::Client::open(redis_url.as_str())?;
    let redis_mgr  = redis::aio::ConnectionManager::new(redis_client).await?;

    let http = reqwest::Client::builder()
        .timeout(Duration::from_secs(30))
        .build()?;

    // Register webhook on startup
    let site_url = std::env::var("SITE_URL").unwrap_or_default();
    if !site_url.is_empty() {
        register_webhook(&http, &cfg.token, &site_url).await;
    }
    let supabase_url = std::env::var("SUPABASE_URL").unwrap_or_default();
    let supabase_key = std::env::var("SUPABASE_KEY").unwrap_or_default();
    let db_client    = DbClient::new(supabase_url, supabase_key);
    let brain        = Arc::new(tokio::sync::Mutex::new(
      Brain::new(redis_mgr.clone(), db_client, cfg.delivery)
    ));

    let state = AppState { http, redis: redis_mgr, cfg, brain };

    let app = Router::new()
        .route("/api/telegram/webhook", post(webhook_handler))
        .route("/health", get(health))
        .with_state(state);

    let port = std::env::var("TG_BOT_PORT").ok()
        .and_then(|s| s.parse::<u16>().ok()).unwrap_or(5001);
    let addr = format!("127.0.0.1:{port}");
    info!("[tg_bot] listening on {addr}");

    let listener = tokio::net::TcpListener::bind(&addr).await?;
    axum::serve(listener, app).await?;
    Ok(())
}
