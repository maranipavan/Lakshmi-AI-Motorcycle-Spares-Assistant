//! Lakshmi Motorcycle Spare Parts — Combined binary
//!
//! Telegram channel sync and image maintenance:
//!
//! - channel_sync watches the configured Telegram channel and upserts spare parts.
//! - image_sync fills missing web_image_url values on a configurable interval.
use std::io::{self, BufRead as _, Write as _};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use anyhow::{Context, Result};
use grammers_client::client::UpdatesConfiguration;
use grammers_client::update::Update;
use grammers_client::{Client, SignInError};
use grammers_mtsender::SenderPool;
use grammers_session::storages::SqliteSession;
use md5;
use once_cell::sync::Lazy;
use regex::Regex;
use reqwest::header::{HeaderMap, HeaderValue, AUTHORIZATION, CONTENT_TYPE};
use serde::{Deserialize, Serialize};
use std::env;
use tracing::{error, info, warn};

// ============================================================
// COMPILED REGEXES  (channel_sync)
// ============================================================
// ── COMPILED REGEXES  (channel_sync) ─────────────────────────────────────────
static RE_BRAND:    Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Brand:\s*(.+)").unwrap());
static RE_MODEL:    Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Model:\s*(.+)").unwrap());
static RE_PART:     Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Part:\s*(.+)").unwrap());
static RE_CATEGORY: Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Category:\s*(.+)").unwrap());
static RE_COLOR:    Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Color:\s*(.+)").unwrap());
// Captures ALL year ranges in a Years: line — e.g. "2016-2017,2018-2019"
static RE_YEARS:    Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Years?:\s*(.+)").unwrap());
// Matches a single year range like "2016-2017" or "2016–2017"
static RE_YEAR_RANGE: Lazy<Regex> = Lazy::new(|| Regex::new(r"(\d{4})\s*[-–]\s*(\d{4})").unwrap());
static RE_PRICE:    Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Price:\s*(\d+)").unwrap());
static RE_STOCK:    Lazy<Regex> = Lazy::new(|| Regex::new(r"(?i)Stock:\s*(\d+)").unwrap());

// ============================================================
// DATA MODELS
// ============================================================

#[derive(Debug, Serialize, Deserialize, Clone)]
struct SparePart {
    bike_brand:       String,
    bike_model:       String,
    part_name:        String,
    #[serde(skip_serializing_if = "Option::is_none")]
    part_category:    Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    color:            Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    year_from:        Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    year_to:          Option<i32>,
    price:            i32,
    stock_qty:        i32,
    is_active:        bool,
    image_url:        String,
    #[serde(skip_serializing_if = "Option::is_none")]
    web_image_url:    Option<String>,
    telegram_post_id: i64,
}

#[derive(Debug, Deserialize)]
struct SelectRow { id: String }

#[derive(Debug, Deserialize)]
struct ImageSyncRow {
    id:            String,
    part_name:     Option<String>,
    image_url:     Option<String>,
    web_image_url: Option<String>,
}

fn unix_now() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs()
}

// ============================================================
// SUPABASE CLIENT
// ============================================================
#[derive(Clone)]
struct SupabaseClient {
    http:     reqwest::Client,
    base_url: String,
}

impl SupabaseClient {
    fn new(url: &str, service_key: &str) -> Result<Self> {
        let mut headers = HeaderMap::new();
        headers.insert(AUTHORIZATION, HeaderValue::from_str(&format!("Bearer {}", service_key))?);
        headers.insert("apikey",      HeaderValue::from_str(service_key)?);
        headers.insert(CONTENT_TYPE,  HeaderValue::from_static("application/json"));
        Ok(Self {
            http:     reqwest::Client::builder().default_headers(headers).build()?,
            base_url: format!("{}/rest/v1", url),
        })
    }

    // ── channel_sync ──────────────────────────────────────────────────────────

    async fn exists(&self, post_id: i64, brand: &str, model: &str) -> Result<Option<String>> {
        let url = format!(
            "{}/spare_parts?select=id&telegram_post_id=eq.{}&bike_brand=eq.{}&bike_model=eq.{}",
            self.base_url, post_id,
            urlencoding::encode(brand), urlencoding::encode(model)
        );
        let resp   = self.http.get(&url).send().await.context("SELECT failed")?;
        let status = resp.status();
        let body   = resp.text().await?;
        if !status.is_success() {
            return Err(anyhow::anyhow!("SELECT error ({}): {}", status, &body[..body.len().min(200)]));
        }
        let rows: Vec<SelectRow> = serde_json::from_str(&body)
            .with_context(|| format!("SELECT parse: {}", &body[..body.len().min(200)]))?;
        Ok(rows.into_iter().next().map(|r| r.id))
    }

    async fn insert(&self, part: &SparePart) -> Result<String> {
        let resp   = self.http.post(&format!("{}/spare_parts", self.base_url))
            .header("Prefer", "return=representation").json(part).send().await?;
        let status = resp.status();
        let body   = resp.text().await?;
        if !status.is_success() {
            return Err(anyhow::anyhow!("INSERT error ({}): {}", status, &body[..body.len().min(200)]));
        }
        let rows: Vec<SelectRow> = serde_json::from_str(&body)
            .with_context(|| format!("INSERT parse: {}", &body[..body.len().min(200)]))?;
        rows.into_iter().next().map(|r| r.id).context("INSERT returned no id")
    }

    async fn update(&self, part: &SparePart) -> Result<()> {
        let url = format!(
            "{}/spare_parts?telegram_post_id=eq.{}&bike_brand=eq.{}&bike_model=eq.{}",
            self.base_url, part.telegram_post_id,
            urlencoding::encode(&part.bike_brand), urlencoding::encode(&part.bike_model)
        );
        let resp = self.http.patch(&url).json(part).send().await.context("UPDATE failed")?;
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            return Err(anyhow::anyhow!("UPDATE error ({}): {}", status, &body[..body.len().min(200)]));
        }
        Ok(())
    }

    async fn upload_image(
        &self, bucket: &str, path: &str, data: Vec<u8>,
        supabase_url: &str, service_key: &str,
    ) -> Result<String> {
        let upload_url = format!("{}/storage/v1/object/{}/{}", supabase_url, bucket, path);
        let public_url = format!("{}/storage/v1/object/public/{}/{}", supabase_url, bucket, path);
        let resp = self.http.post(&upload_url)
            .header("Authorization", format!("Bearer {}", service_key))
            .header("Content-Type", "image/jpeg")
            .header("x-upsert", "true")
            .body(data).send().await.context("Storage upload failed")?;
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            return Err(anyhow::anyhow!("Storage upload error ({}): {}", status, &body[..body.len().min(200)]));
        }
        Ok(public_url)
    }

    async fn set_web_image_url(&self, part_id: &str, web_url: &str) -> Result<()> {
        let url = format!("{}/spare_parts?id=eq.{}", self.base_url, part_id);
        let resp = self.http.patch(&url)
            .json(&serde_json::json!({ "web_image_url": web_url }))
            .send().await.context("web_image_url patch failed")?;
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            return Err(anyhow::anyhow!("web_image_url patch error ({}): {}", status, &body[..body.len().min(200)]));
        }
        Ok(())
    }

    // ── image_sync ────────────────────────────────────────────────────────────

    async fn get_image_sync_rows(&self, limit: usize, only_missing: bool) -> Result<Vec<ImageSyncRow>> {
        let mut url = format!(
            "{}/spare_parts?select=id,part_name,image_url,web_image_url&is_active=eq.true",
            self.base_url
        );
        if only_missing { url.push_str("&web_image_url=is.null"); }
        if limit > 0    { url.push_str(&format!("&limit={}", limit)); }
        let resp   = self.http.get(&url).send().await.context("image_sync SELECT failed")?;
        let status = resp.status();
        let body   = resp.text().await?;
        if !status.is_success() {
            return Err(anyhow::anyhow!("image_sync SELECT error ({}): {}", status, &body[..body.len().min(200)]));
        }
        serde_json::from_str(&body)
            .with_context(|| format!("image_sync parse: {}", &body[..body.len().min(200)]))
    }


}

// ============================================================
// HELPERS
// ============================================================

fn db_format(s: &str) -> String {
    s.trim().split_whitespace()
        .map(|word| {
            let mut c = word.chars();
            match c.next() {
                None        => String::new(),
                Some(first) => first.to_uppercase().collect::<String>() + c.as_str(),
            }
        })
        .collect::<Vec<_>>().join(" ")
}

fn split_list(s: &str) -> Vec<String> {
    s.split(|c| c == ',' || c == '/')
        .map(|v| db_format(v)).filter(|v| !v.is_empty()).collect()
}

fn extract_opt(re: &Lazy<Regex>, text: &str) -> Option<String> {
    re.captures(text).and_then(|c| c.get(1))
        .map(|m| db_format(m.as_str())).filter(|s| !s.is_empty())
}

fn prompt(msg: &str) -> Result<String> {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    out.write_all(msg.as_bytes())?; out.flush()?;
    let mut line = String::new();
    io::stdin().lock().read_line(&mut line)?;
    Ok(line.trim().to_string())
}

fn is_telegram_url(url: &str) -> bool {
    url.contains("t.me/") || url.contains("telegram.me/") || url.contains("api.telegram.org")
}

fn md5_hex(s: &str) -> String { format!("{:x}", md5::compute(s.as_bytes())) }

fn scrape_client() -> reqwest::Client {
    reqwest::Client::builder()
        .user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 \
                     (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        .timeout(Duration::from_secs(20)).build().expect("scrape_client failed")
}

// ============================================================
// IMAGE SYNC  (unchanged logic from previous version)
// ============================================================

async fn resolve_telegram_image(client: &reqwest::Client, url: &str) -> Option<String> {
    if url.is_empty() || !url.starts_with("http") { return None; }
    let resp = client.get(url).send().await.ok()?;
    if !resp.status().is_success() { return None; }
    let html = resp.text().await.ok()?;
    let re   = Regex::new(r#"<meta[^>]+property="(?:twitter:image|og:image)"[^>]+content="([^"]+)""#).unwrap();
    re.captures(&html).and_then(|c| c.get(1))
        .map(|m| m.as_str().replace("/s/", "/"))
        .filter(|s| !s.is_empty())
}

async fn storage_file_exists(client: &reqwest::Client, url: &str) -> bool {
    client.head(url).timeout(Duration::from_secs(10)).send().await
        .map(|r| r.status().as_u16() == 200).unwrap_or(false)
}

async fn bust_flask_cache() {
    let redis_url = match env::var("REDIS_URL") {
        Ok(u) if !u.is_empty() => u,
        _ => { info!("[image_sync] REDIS_URL not set — skipping cache bust"); return; }
    };
    let ts  = unix_now().to_string();
    let cmd = format!(
        "*5\r\n$3\r\nSET\r\n$20\r\nparts:last_modified\r\n${}\r\n{}\r\n$2\r\nEX\r\n$5\r\n86400\r\n",
        ts.len(), ts
    );
    let addr = {
        let s  = redis_url.trim_start_matches("rediss://").trim_start_matches("redis://");
        let nd = s.split('/').next().unwrap_or(s);
        let hp = if nd.contains('@') { nd.splitn(2, '@').nth(1).unwrap_or(nd) } else { nd };
        if hp.contains(':') { hp.to_string() } else { format!("{}:6379", hp) }
    };
    match tokio::net::TcpStream::connect(&addr).await {
        Ok(mut s) => {
            use tokio::io::AsyncWriteExt;
            if s.write_all(cmd.as_bytes()).await.is_ok() {
                info!("[image_sync] ✅ Redis cache bust sent");
            }
        }
        Err(e) => warn!("[image_sync] Redis connect failed ({}): {}", addr, e),
    }
}

async fn run_image_sync(
    db: SupabaseClient, supabase_url: String, service_key: String,
    limit: usize, only_missing: bool, interval_secs: u64,
) {
    loop {
        info!("[image_sync] 🔄 Starting (limit={}, only_missing={})...", limit, only_missing);
        let rows = match db.get_image_sync_rows(limit, only_missing).await {
            Ok(r)  => r,
            Err(e) => {
                error!("[image_sync] Query failed: {}", e);
                if interval_secs == 0 { break; }
                tokio::time::sleep(Duration::from_secs(interval_secs)).await; continue;
            }
        };
        info!("[image_sync] {} row(s) to process", rows.len());
        let client = scrape_client();
        let (mut uploaded, mut skipped, mut errors, mut any_up) = (0usize, 0usize, 0usize, false);

        for row in &rows {
            let pid  = &row.id;
            let name = row.part_name.as_deref().unwrap_or(pid);
            let img  = row.image_url.as_deref().unwrap_or("").trim().to_string();
            let web  = row.web_image_url.as_deref().unwrap_or("").trim().to_string();

            if only_missing && !web.is_empty() && web.starts_with("http") && !is_telegram_url(&web)
                { skipped += 1; continue; }
            if img.is_empty() { skipped += 1; continue; }

            if img.starts_with("http") && !is_telegram_url(&img) {
                match db.set_web_image_url(pid, &img).await {
                    Ok(_)  => { info!("[image_sync] ✅ {} → copied", &name[..name.len().min(40)]); uploaded += 1; any_up = true; }
                    Err(e) => { error!("[image_sync] ❌ {} — {}", name, e); errors += 1; }
                }
                tokio::time::sleep(Duration::from_millis(500)).await; continue;
            }

            // Must fetch the /s/ preview URL — that is the page with og:image meta tags.
            // Raw t.me/channel/N redirects to the channel page which has no og:image.
            let preview_url = if img.contains("t.me/") {
                img.replace("https://t.me/", "https://t.me/s/")
            } else {
                img.clone()
            };
            let direct = match resolve_telegram_image(&client, &preview_url).await {
                Some(u) => u,
                None    => { error!("[image_sync] ❌ {} — scrape failed", name); errors += 1; continue; }
            };
            let hash = md5_hex(&direct);
            let path = format!("web_images/{}.jpg", hash);
            let pub_url = format!("{}/storage/v1/object/public/web_image_urls/{}", supabase_url, path);

            if storage_file_exists(&client, &pub_url).await {
                info!("[image_sync] reusing {}...", &hash[..12]);
                match db.set_web_image_url(pid, &pub_url).await {
                    Ok(_)  => { uploaded += 1; any_up = true; }
                    Err(e) => { error!("[image_sync] ❌ {} DB patch: {}", name, e); errors += 1; }
                }
                tokio::time::sleep(Duration::from_millis(500)).await; continue;
            }

            let data = match client.get(&direct).send().await {
                Ok(r)  => match r.bytes().await { Ok(b) => b.to_vec(), Err(e) => { error!("[image_sync] ❌ {} body: {}", name, e); errors += 1; continue; } },
                Err(e) => { error!("[image_sync] ❌ {} download: {}", name, e); errors += 1; continue; }
            };

            match db.upload_image("web_image_urls", &path, data, &supabase_url, &service_key).await {
                Ok(u) => match db.set_web_image_url(pid, &u).await {
                    Ok(_)  => { info!("[image_sync] ✅ {} → {}", &name[..name.len().min(40)], &u[..u.len().min(70)]); uploaded += 1; any_up = true; }
                    Err(e) => { error!("[image_sync] ❌ {} DB patch: {}", name, e); errors += 1; }
                },
                Err(e) => { error!("[image_sync] ❌ {} upload: {}", name, e); errors += 1; }
            }
            tokio::time::sleep(Duration::from_millis(500)).await;
        }

        info!("[image_sync] ✅ Done — processed={}, uploaded={}, skipped={}, errors={}",
              rows.len(), uploaded, skipped, errors);
        if any_up { bust_flask_cache().await; }
        if interval_secs == 0 { break; }
        tokio::time::sleep(Duration::from_secs(interval_secs)).await;
    }
}

// ============================================================
// CHANNEL_SYNC  (unchanged from previous version)
// ============================================================

/// Parse "Years: 2016-2017,2018-2019" into vec of (year_from, year_to) pairs.
/// Returns vec in same order as the years appear — index matches model index.
/// e.g. "2016-2017,2018-2019" → [(2016,2017), (2018,2019)]
fn parse_year_ranges(text: &str) -> Vec<(i32, i32)> {
    let years_line = match RE_YEARS.captures(text).and_then(|c| c.get(1)) {
        Some(m) => m.as_str().to_string(),
        None    => return vec![],
    };
    RE_YEAR_RANGE.captures_iter(&years_line)
        .filter_map(|c| {
            let from = c.get(1)?.as_str().parse::<i32>().ok()?;
            let to   = c.get(2)?.as_str().parse::<i32>().ok()?;
            Some((from, to))
        })
        .collect()
}

/// Pair models with their year ranges.
/// Rules:
///   - If years.len() == models.len()  → each model gets its own year range (zip)
///   - If years.len() == 1             → all models share the same year range
///   - If years.len() == 0             → all models get (None, None)
///   - Otherwise (mismatch)            → all models share first year range as fallback
fn pair_models_years(
    models: &[String],
    year_ranges: &[(i32, i32)],
) -> Vec<(String, Option<i32>, Option<i32>)> {
    models.iter().enumerate().map(|(i, model)| {
        let (yr_from, yr_to) = if year_ranges.is_empty() {
            (None, None)
        } else if year_ranges.len() == models.len() {
            // Perfect match — each model gets its own range
            (Some(year_ranges[i].0), Some(year_ranges[i].1))
        } else if year_ranges.len() == 1 {
            // One range for all models
            (Some(year_ranges[0].0), Some(year_ranges[0].1))
        } else {
            // Mismatch — use first range as fallback, log warning
            warn!(
                "⚠️  Year/model count mismatch ({} years, {} models) for '{}' — using first range",
                year_ranges.len(), models.len(), model
            );
            (Some(year_ranges[0].0), Some(year_ranges[0].1))
        };
        (model.clone(), yr_from, yr_to)
    }).collect()
}

async fn process_message(
    text: &str, post_id: i64, channel: &str,
    photo_bytes: Option<Vec<u8>>,
    db: &SupabaseClient, supabase_url: &str, service_key: &str,
) -> Result<()> {
    if !text.to_lowercase().contains("brand:") { return Ok(()); }

    let brand_raw = RE_BRAND.captures(text).and_then(|c| c.get(1)).map(|m| m.as_str());
    let model_raw = RE_MODEL.captures(text).and_then(|c| c.get(1)).map(|m| m.as_str());
    let part_raw  = RE_PART.captures(text).and_then(|c| c.get(1)).map(|m| m.as_str());
    let price_raw = RE_PRICE.captures(text).and_then(|c| c.get(1)).map(|m| m.as_str());

    let (Some(brand_raw), Some(model_raw), Some(part_raw), Some(price_raw)) =
        (brand_raw, model_raw, part_raw, price_raw)
    else {
        warn!("⏭  Post {} skipped — missing required field(s)", post_id);
        return Ok(());
    };

    let part_name = db_format(part_raw);
    let category  = extract_opt(&RE_CATEGORY, text);
    let color     = extract_opt(&RE_COLOR, text);
    let price: i32 = price_raw.parse().context("Invalid price")?;
    let stock: i32 = RE_STOCK.captures(text)
        .and_then(|c| c.get(1)).and_then(|m| m.as_str().parse().ok()).unwrap_or(0);

    let brands      = split_list(brand_raw);
    let models      = split_list(model_raw);
    let year_ranges = parse_year_ranges(text);
    let tg_link     = format!("https://t.me/{}/{}", channel, post_id);

    // Log what we parsed for debugging
    info!(
        "📋 Post {} — brands={:?} models={:?} years={:?} part='{}'",
        post_id, brands, models, year_ranges, part_name
    );

    let web_image_url: Option<String> = if let Some(bytes) = photo_bytes {
        let path = format!("web_images/{}.jpg", md5_hex(&tg_link));
        match db.upload_image("web_image_urls", &path, bytes, supabase_url, service_key).await {
            Ok(url) => { info!("📸 Photo uploaded → {}", &url[..url.len().min(60)]); Some(url) }
            Err(e)  => { warn!("⚠️  Photo upload failed post {}: {}", post_id, e); None }
        }
    } else { None };

    // Pair each model with its correct year range
    let model_year_pairs = pair_models_years(&models, &year_ranges);

    for brand in &brands {
        for (model, yr_from, yr_to) in &model_year_pairs {
            let part = SparePart {
                bike_brand: brand.clone(), bike_model: model.clone(),
                part_name: part_name.clone(), part_category: category.clone(),
                color: color.clone(),
                year_from: *yr_from,
                year_to:   *yr_to,
                price, stock_qty: stock, is_active: true,
                image_url: tg_link.clone(), web_image_url: web_image_url.clone(),
                telegram_post_id: post_id,
            };
            match db.exists(post_id, brand, model).await {
                Ok(Some(_)) => match db.update(&part).await {
                    Ok(_)  => info!("🔄 Updated:  {} {} ({:?}-{:?}) — {}", brand, model, yr_from, yr_to, part_name),
                    Err(e) => error!("❌ Update failed [{} {}]: {}", brand, model, e),
                },
                Ok(None) => match db.insert(&part).await {
                    Ok(new_id) => {
                        info!("✅ Inserted: {} {} ({:?}-{:?}) — {} (id={})", brand, model, yr_from, yr_to, part_name, new_id);
                        if web_image_url.is_none() {
                            let db2  = db.clone(); let link = tg_link.clone();
                            let surl = supabase_url.to_string(); let skey = service_key.to_string();
                            tokio::spawn(async move {
                                scrape_and_upload_image(new_id, &link, &db2, &surl, &skey).await;
                            });
                        }
                    }
                    Err(e) => error!("❌ Insert failed [{} {}]: {}", brand, model, e),
                },
                Err(e) => error!("❌ DB check failed [{} {}]: {}", brand, model, e),
            }
        }
    }
    Ok(())
}

async fn scrape_and_upload_image(
    part_id: String, tg_link: &str,
    db: &SupabaseClient, supabase_url: &str, service_key: &str,
) {
    let preview = tg_link.replace("https://t.me/", "https://t.me/s/");
    let client  = scrape_client();
    let direct  = match resolve_telegram_image(&client, &preview).await {
        Some(u) => u,
        None    => { warn!("⚠️  No og:image for part {}", part_id); return; }
    };
    let data = match client.get(&direct).send().await {
        Ok(r)  => match r.bytes().await { Ok(b) => b.to_vec(), Err(_) => return },
        Err(_) => { warn!("⚠️  Image download failed part {}", part_id); return; }
    };
    // md5 of direct_url matches run_image_sync's dedup key — same image reuses same slot.
    let path = format!("web_images/{}.jpg", md5_hex(&direct));
    match db.upload_image("web_image_urls", &path, data, supabase_url, service_key).await {
        Ok(u) => match db.set_web_image_url(&part_id, &u).await {
            Ok(_)  => info!("🖼  Image uploaded part {} → {}", part_id, &u[..u.len().min(60)]),
            Err(e) => error!("❌ web_image_url patch failed part {}: {}", part_id, e),
        },
        Err(e) => warn!("⚠️  Storage upload failed part {}: {}", part_id, e),
    }
}

// ============================================================
// MAIN
// ============================================================

#[tokio::main]
async fn main() -> Result<()> {
    dotenvy::dotenv().ok();

    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("telegram_sync=info".parse().unwrap()),
        )
        .init();

    // ── Required environment ─────────────────────────────────────────────────
    let api_id:      i32    = env::var("TG_API_ID").context("TG_API_ID missing")?.parse()?;
    let api_hash:    String = env::var("TG_API_HASH").context("TG_API_HASH missing")?;
    let supa_url:    String = env::var("SUPABASE_URL").context("SUPABASE_URL missing")?;
    let service_key: String = env::var("SUPABASE_SERVICE_KEY")
                                 .or_else(|_| env::var("SUPABASE_KEY"))
                                 .context("SUPABASE_SERVICE_KEY missing")?;
    let channel: String = env::var("TG_SYNC_CHANNEL")
                             .unwrap_or_else(|_| "lakshmimotorcyclespare".into());
    let img_limit: usize = env::var("IMAGE_SYNC_LIMIT").ok().and_then(|v| v.parse().ok()).unwrap_or(200);
    let img_intv:  u64  = env::var("IMAGE_SYNC_INTERVAL_SECS").ok().and_then(|v| v.parse().ok()).unwrap_or(21_600);

    let db = SupabaseClient::new(&supa_url, &service_key)?;

    // ── Task 2: image_sync (background maintenance) ──────────────────────────
    {
        let (db2, su2, sk2) = (db.clone(), supa_url.clone(), service_key.clone());
        tokio::spawn(async move { run_image_sync(db2, su2, sk2, img_limit, true, img_intv).await; });
        info!("🖼  image_sync spawned (limit={}, interval={}s)", img_limit, img_intv);
    }

    // ── Task 1: channel_sync (main loop) ──────────────────────────────────────
    info!("🔗 Connecting to Telegram...");
    let session = Arc::new(SqliteSession::open("lakshmi_channel_sync.session").await?);
    let SenderPool { runner, updates, handle } = SenderPool::new(Arc::clone(&session), api_id);
    let client  = Client::new(handle.clone());
    let _pool   = tokio::spawn(runner.run());

    if !client.is_authorized().await? {
        let phone = prompt("Enter phone number (e.g. +91XXXXXXXXXX): ")?;
        let token = client.request_login_code(&phone, &api_hash).await?;
        let code  = prompt("Enter OTP code: ")?;
        match client.sign_in(&token, &code).await {
            Err(SignInError::PasswordRequired(pt)) => {
                let pw = prompt(&format!("2FA password (hint: {}): ", pt.hint().unwrap_or("none")))?;
                client.check_password(pt, pw.trim()).await?;
            }
            Ok(_)  => {}
            Err(e) => return Err(e.into()),
        }
        info!("✅ Logged in.");
    }

    info!("🚀 Rust Sync Running — watching @{}...", channel);

    let mut stream = client
        .stream_updates(updates, UpdatesConfiguration { catch_up: true, ..Default::default() })
        .await;

    loop {
        match stream.next().await {
            Ok(Update::NewMessage(msg)) | Ok(Update::MessageEdited(msg)) => {
                let is_target = msg.peer()
                    .and_then(|p| p.username())
                    .map(|u| u.to_lowercase() == channel.to_lowercase())
                    .unwrap_or(false);
                if !is_target { continue; }

                let text    = msg.text().to_string();
                let post_id = msg.id() as i64;

                let photo_bytes: Option<Vec<u8>> = if msg.photo().is_some() {
                    let tmp = format!("/tmp/tg_photo_{}.jpg", post_id);
                    match msg.download_media(&tmp).await {
                        Ok(true) => {
                            let b = tokio::fs::read(&tmp).await.ok();
                            let _ = tokio::fs::remove_file(&tmp).await;
                            b
                        }
                        _ => None,
                    }
                } else { None };

                let (db_c, ch_c, su_c, sk_c) = (db.clone(), channel.clone(), supa_url.clone(), service_key.clone());
                tokio::spawn(async move {
                    if let Err(e) = process_message(&text, post_id, &ch_c, photo_bytes, &db_c, &su_c, &sk_c).await {
                        warn!("⚠️  Post {} error: {}", post_id, e);
                    }
                });
            }
            Ok(_)  => {}
            Err(e) => {
                error!("❌ Stream error: {}. Retrying in 5s...", e);
                tokio::time::sleep(Duration::from_secs(5)).await;
            }
        }
    }
}
