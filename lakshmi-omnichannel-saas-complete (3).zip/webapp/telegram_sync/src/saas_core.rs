//! Multi-Tenant Omnichannel Automation SaaS Core Engine (`saas_core.rs`)
//! =====================================================================
//! Complete Rust replacement for `backend/saas_api.py`.
//! Provides:
//! - Tenant registration, login, PBKDF2/SHA-256 credential hashing, HS256 JWT issuance & verification
//! - Scoped `X-API-Key` (`lms_live_...` SHA-256 hashed at rest) authentication
//! - 8-Role RBAC permission evaluation & Cross-Tenant IDOR prevention
//! - Subscription Plans (`Standard ₹999/mo`, `Pro ₹2,499/mo`, `Pro Max ₹5,999/mo`) & Quota Metering
//! - All 10 Business Vertical Industry Presets (`/api/v1/presets` & `/api/v1/presets/apply`)
//! - Dynamic Per-Channel Configuration Schemas (`/api/v1/channels/:channel_type/config` & `/test`)
//! - Visual Workflow Builder CRUD, Dry-Run Simulator, Version History & Rollback
//! - Unified 3-Panel Inbox Conversations, Agent Assignment, Status `PATCH` & 2-Hour Bot Auto-Pause
//! - Catalog CRUD & Multilingual Search, Campaigns, CRM Contacts, Team Invites, Audit Logs,
//!   Razorpay & Stripe Signed Webhooks, Manual UPI UTR Verification, and DPDP/GDPR Export & Erasure.

use crate::cache_layer::{
    normalize_search_query_for_cache, normalized_search_cache_key, DEFAULT_TENANT_ID, GLOBAL_CACHE,
};
use crate::channels::{
    generate_catalog_reply, process_comment_event, CommentRule, TENANT_COMMENT_RULES,
};
use crate::services_booking::{create_booking_handler, list_bookings_handler, SERVICE_BOOKINGS};
use axum::{
    body::Bytes,
    extract::{Path, Query},
    http::{header, HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    routing::{delete, get, patch, post, put},
    Json, Router,
};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};
use dashmap::DashMap;
use once_cell::sync::Lazy;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};
use uuid::Uuid;

pub static HTTP_REQUESTS_TOTAL: AtomicU64 = AtomicU64::new(0);
pub static WEBHOOK_EVENTS_TOTAL: AtomicU64 = AtomicU64::new(0);
pub static WORKFLOW_EXECUTIONS_TOTAL: AtomicU64 = AtomicU64::new(0);
pub static ENTITLEMENT_DENIALS_TOTAL: AtomicU64 = AtomicU64::new(0);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PlanTier {
    Standard,
    Pro,
    ProMax,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlanQuotas {
    pub max_channels: u32,
    pub monthly_messages: u64,
    pub team_seats: u32,
    pub max_workflows: u32,
    pub catalog_items: u64,
    pub monthly_ai_tokens: u64,
    pub custom_webhooks: bool,
}

impl PlanTier {
    pub fn from_id(s: &str) -> Option<Self> {
        match s.trim().to_lowercase().as_str() {
            "standard" => Some(PlanTier::Standard),
            "pro" => Some(PlanTier::Pro),
            "pro_max" => Some(PlanTier::ProMax),
            _ => None,
        }
    }

    pub fn id(&self) -> &'static str {
        match self {
            PlanTier::Standard => "standard",
            PlanTier::Pro => "pro",
            PlanTier::ProMax => "pro_max",
        }
    }

    pub fn name(&self) -> &'static str {
        match self {
            PlanTier::Standard => "Standard",
            PlanTier::Pro => "Pro",
            PlanTier::ProMax => "Pro Max",
        }
    }

    pub fn monthly_inr(&self) -> u64 {
        match self {
            PlanTier::Standard => 999,
            PlanTier::Pro => 2499,
            PlanTier::ProMax => 5999,
        }
    }

    pub fn yearly_inr(&self) -> u64 {
        self.monthly_inr() * 10
    }

    pub fn quotas(&self) -> PlanQuotas {
        match self {
            PlanTier::Standard => PlanQuotas {
                max_channels: 2,
                monthly_messages: 10_000,
                team_seats: 3,
                max_workflows: 5,
                catalog_items: 1_000,
                monthly_ai_tokens: 100_000,
                custom_webhooks: false,
            },
            PlanTier::Pro => PlanQuotas {
                max_channels: 5,
                monthly_messages: 50_000,
                team_seats: 10,
                max_workflows: 25,
                catalog_items: 10_000,
                monthly_ai_tokens: 500_000,
                custom_webhooks: true,
            },
            PlanTier::ProMax => PlanQuotas {
                max_channels: 25,
                monthly_messages: 250_000,
                team_seats: 50,
                max_workflows: 200,
                catalog_items: 100_000,
                monthly_ai_tokens: 2_500_000,
                custom_webhooks: true,
            },
        }
    }

    pub fn to_json(&self) -> Value {
        let q = self.quotas();
        json!({
            "id": self.id(),
            "name": self.name(),
            "monthly_price_inr": self.monthly_inr(),
            "yearly_price_inr": self.yearly_inr(),
            "limits": {
                "channels": q.max_channels,
                "monthly_messages": q.monthly_messages,
                "team_seats": q.team_seats,
                "workflows": q.max_workflows,
                "catalog_items": q.catalog_items,
                "ai_tokens": q.monthly_ai_tokens,
                "comment_automation": true,
                "service_booking": true,
                "custom_webhooks": q.custom_webhooks,
            }
        })
    }
}

/// Constant-time byte comparison to prevent timing side-channel attacks.
pub fn constant_time_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff: u8 = 0;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

/// RFC 2104 HMAC-SHA256 implementation using `sha2::Sha256`.
pub fn hmac_sha256_hex(secret: &[u8], payload: &[u8]) -> String {
    let raw = hmac_sha256_bytes(secret, payload);
    let mut out = String::with_capacity(64);
    for byte in raw {
        out.push_str(&format!("{:02x}", byte));
    }
    out
}

pub fn hmac_sha256_bytes(secret: &[u8], payload: &[u8]) -> [u8; 32] {
    const BLOCK_SIZE: usize = 64;
    let mut key_block = [0u8; BLOCK_SIZE];
    if secret.len() > BLOCK_SIZE {
        let mut hasher = Sha256::new();
        hasher.update(secret);
        let digest = hasher.finalize();
        key_block[..digest.len()].copy_from_slice(&digest);
    } else {
        key_block[..secret.len()].copy_from_slice(secret);
    }

    let mut o_key_pad = [0x5cu8; BLOCK_SIZE];
    let mut i_key_pad = [0x36u8; BLOCK_SIZE];
    for i in 0..BLOCK_SIZE {
        o_key_pad[i] ^= key_block[i];
        i_key_pad[i] ^= key_block[i];
    }

    let mut inner = Sha256::new();
    inner.update(i_key_pad);
    inner.update(payload);
    let inner_hash = inner.finalize();

    let mut outer = Sha256::new();
    outer.update(o_key_pad);
    outer.update(inner_hash);
    let final_hash = outer.finalize();
    let mut arr = [0u8; 32];
    arr.copy_from_slice(&final_hash);
    arr
}

pub fn verify_hub_signature_256(secret: &str, raw_body: &[u8], header_val: &str) -> bool {
    let Some(provided_hex) = header_val.strip_prefix("sha256=") else {
        return false;
    };
    let expected_hex = hmac_sha256_hex(secret.as_bytes(), raw_body);
    constant_time_eq(expected_hex.as_bytes(), provided_hex.as_bytes())
}

pub fn tenant_cache_key(tenant_id: &str, namespace: &str, key: &str) -> String {
    let clean_tid = if tenant_id.trim().is_empty() {
        DEFAULT_TENANT_ID
    } else {
        tenant_id.trim()
    };
    format!("t:{}:{}:{}", clean_tid, namespace.trim(), key.trim().to_lowercase())
}

fn now_epoch() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn jwt_secret() -> String {
    std::env::var("SAAS_JWT_SECRET")
        .or_else(|_| std::env::var("ADMIN_PASSWORD"))
        .unwrap_or_else(|_| "lakshmi-saas-default-jwt-secret-2026".to_string())
}

pub fn issue_jwt(claims: &Value) -> String {
    let header_b64 = URL_SAFE_NO_PAD.encode(br#"{"alg":"HS256","typ":"JWT"}"#);
    let mut body = claims.clone();
    body["iat"] = json!(now_epoch());
    body["exp"] = json!(now_epoch() + 86_400);
    let body_b64 = URL_SAFE_NO_PAD.encode(body.to_string().as_bytes());
    let signing_input = format!("{}.{}", header_b64, body_b64);
    let sig = hmac_sha256_bytes(jwt_secret().as_bytes(), signing_input.as_bytes());
    let sig_b64 = URL_SAFE_NO_PAD.encode(sig);
    format!("{}.{}", signing_input, sig_b64)
}

pub fn verify_jwt(token: &str) -> Option<Value> {
    let parts: Vec<&str> = token.split('.').collect();
    if parts.len() != 3 {
        return None;
    }
    let signing_input = format!("{}.{}", parts[0], parts[1]);
    let expected_sig = URL_SAFE_NO_PAD.encode(hmac_sha256_bytes(jwt_secret().as_bytes(), signing_input.as_bytes()));
    if !constant_time_eq(expected_sig.as_bytes(), parts[2].as_bytes()) {
        return None;
    }
    let decoded = URL_SAFE_NO_PAD.decode(parts[1]).ok()?;
    let val: Value = serde_json::from_slice(&decoded).ok()?;
    if val.get("exp").and_then(|v| v.as_u64()).unwrap_or(0) < now_epoch() {
        return None;
    }
    Some(val)
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TenantRecord {
    pub id: String,
    pub slug: String,
    pub business_name: String,
    pub industry_preset: String,
    pub timezone: String,
    pub currency: String,
    pub plan_id: String,
    pub subscription_status: String,
    pub enabled_modules: Value,
    pub ai_config: Value,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChannelRecord {
    pub id: String,
    pub tenant_id: String,
    pub channel_type: String,
    pub display_name: String,
    pub external_account_id: String,
    pub status: String,
    pub health: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkflowRecord {
    pub id: String,
    pub tenant_id: String,
    pub name: String,
    pub status: String,
    pub active_version: u32,
    pub trigger_type: String,
    pub definition: Value,
    pub versions: Vec<Value>,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConversationRecord {
    pub id: String,
    pub tenant_id: String,
    pub channel_type: String,
    pub external_thread_id: String,
    pub customer_name: String,
    pub customer_handle: String,
    pub status: String,
    pub assigned_agent: String,
    pub automation_paused_until: f64,
    pub tags: Vec<String>,
    pub last_message_preview: String,
    pub last_message_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InboxMessageRecord {
    pub id: String,
    pub tenant_id: String,
    pub conversation_id: String,
    pub external_message_id: String,
    pub direction: String,
    pub sender_type: String,
    pub body: String,
    pub delivery_status: String,
    pub created_at: String,
}

pub static TENANTS: Lazy<DashMap<String, TenantRecord>> = Lazy::new(|| {
    let map = DashMap::new();
    map.insert(
        DEFAULT_TENANT_ID.to_string(),
        TenantRecord {
            id: DEFAULT_TENANT_ID.to_string(),
            slug: "lakshmi-motorcycle-spares".to_string(),
            business_name: "Lakshmi Motorcycle Spares".to_string(),
            industry_preset: "automobile_spare_parts".to_string(),
            timezone: "Asia/Kolkata".to_string(),
            currency: "INR".to_string(),
            plan_id: "pro_max".to_string(),
            subscription_status: "active".to_string(),
            enabled_modules: json!({
                "catalog_commerce": true,
                "service_booking": true,
                "comment_automation": true,
                "ai_assistant": true,
                "whatsapp": true,
                "instagram": true,
                "facebook": true,
                "telegram": true,
                "webchat": true,
            }),
            ai_config: json!({
                "primary_provider": "groq",
                "fallback_provider": "nvidia_nim",
                "confidence_threshold": 0.78,
                "strict_catalog_grounding": true,
                "monthly_token_cap": 2_500_000,
            }),
            created_at: "2026-10-15T00:00:00Z".to_string(),
        },
    );
    map
});

pub static CHANNELS: Lazy<DashMap<String, Vec<ChannelRecord>>> = Lazy::new(|| {
    let map = DashMap::new();
    let tid = DEFAULT_TENANT_ID.to_string();
    map.insert(
        tid.clone(),
        vec![
            ChannelRecord { id: "ch_tg_01".to_string(), tenant_id: tid.clone(), channel_type: "telegram".to_string(), display_name: "Lakshmi Spares Telegram Bot".to_string(), external_account_id: "@LakshmiSparesBot".to_string(), status: "connected".to_string(), health: json!({"webhook_ok": true, "settings": {}}) },
            ChannelRecord { id: "ch_ig_01".to_string(), tenant_id: tid.clone(), channel_type: "instagram".to_string(), display_name: "Lakshmi Spares Instagram Business".to_string(), external_account_id: "17841400000001".to_string(), status: "connected".to_string(), health: json!({"webhook_ok": true, "settings": {}}) },
            ChannelRecord { id: "ch_fb_01".to_string(), tenant_id: tid.clone(), channel_type: "facebook".to_string(), display_name: "Lakshmi Motorcycle Spares Page".to_string(), external_account_id: "10928374651029".to_string(), status: "connected".to_string(), health: json!({"webhook_ok": true, "settings": {}}) },
            ChannelRecord { id: "ch_wa_01".to_string(), tenant_id: tid.clone(), channel_type: "whatsapp".to_string(), display_name: "Lakshmi Spares WhatsApp Cloud".to_string(), external_account_id: "+91-9160201088".to_string(), status: "connected".to_string(), health: json!({"webhook_ok": true, "settings": {}}) },
            ChannelRecord { id: "ch_wc_01".to_string(), tenant_id: tid.clone(), channel_type: "webchat".to_string(), display_name: "Storefront Live WebChat (Rust WS)".to_string(), external_account_id: "ws://localhost:8765".to_string(), status: "connected".to_string(), health: json!({"webhook_ok": true, "settings": {}}) },
        ],
    );
    map
});

pub static WORKFLOWS: Lazy<DashMap<String, WorkflowRecord>> = Lazy::new(|| {
    let map = DashMap::new();
    let def = json!({
        "nodes": [
            {"id": "n1", "type": "trigger", "event": "inbound_message_or_comment"},
            {"id": "n2", "type": "condition", "field": "intent", "operator": "in", "value": ["part_inquiry", "price_check"]},
            {"id": "n3", "type": "catalog_lookup", "engine": "rust_brain_synonym_fts"},
            {"id": "n4", "type": "send_message", "template": "Found {{part.name}} — ₹{{part.price}}"}
        ],
        "edges": [["n1", "n2"], ["n2", "n3"], ["n3", "n4"]]
    });
    map.insert(
        format!("{}:wf_lakshmi_core", DEFAULT_TENANT_ID),
        WorkflowRecord {
            id: "wf_lakshmi_core".to_string(),
            tenant_id: DEFAULT_TENANT_ID.to_string(),
            name: "Omnichannel Spare Parts Lookup & Order Checkout".to_string(),
            status: "published".to_string(),
            active_version: 1,
            trigger_type: "inbound_message".to_string(),
            definition: def.clone(),
            versions: vec![json!({"version": 1, "definition": def, "saved_at": "2026-10-15T00:00:00Z"})],
            updated_at: "2026-10-15T00:00:00Z".to_string(),
        },
    );
    map
});

pub static CONVERSATIONS: Lazy<DashMap<String, ConversationRecord>> = Lazy::new(|| {
    let map = DashMap::new();
    map.insert(
        "conv_demo_01".to_string(),
        ConversationRecord {
            id: "conv_demo_01".to_string(),
            tenant_id: DEFAULT_TENANT_ID.to_string(),
            channel_type: "instagram".to_string(),
            external_thread_id: "ig_thread_9912".to_string(),
            customer_name: "Ramesh Kumar".to_string(),
            customer_handle: "@ramesh_rider".to_string(),
            status: "open".to_string(),
            assigned_agent: "unassigned".to_string(),
            automation_paused_until: 0.0,
            tags: vec!["pulsar-150".to_string(), "hot-lead".to_string()],
            last_message_preview: "Do you have Pulsar 150 front disc brake pad in stock?".to_string(),
            last_message_at: "2026-10-15T07:00:00Z".to_string(),
        },
    );
    map
});

pub static INBOX_MESSAGES: Lazy<DashMap<String, Vec<InboxMessageRecord>>> = Lazy::new(|| {
    let map = DashMap::new();
    map.insert(
        "conv_demo_01".to_string(),
        vec![
            InboxMessageRecord {
                id: "msg_demo_01".to_string(),
                tenant_id: DEFAULT_TENANT_ID.to_string(),
                conversation_id: "conv_demo_01".to_string(),
                external_message_id: "ig_mid_1001".to_string(),
                direction: "inbound".to_string(),
                sender_type: "customer".to_string(),
                body: "Do you have Pulsar 150 front disc brake pad in stock?".to_string(),
                delivery_status: "delivered".to_string(),
                created_at: "2026-10-15T07:00:00Z".to_string(),
            },
            InboxMessageRecord {
                id: "msg_demo_02".to_string(),
                tenant_id: DEFAULT_TENANT_ID.to_string(),
                conversation_id: "conv_demo_01".to_string(),
                external_message_id: "ig_mid_1002".to_string(),
                direction: "outbound".to_string(),
                sender_type: "bot".to_string(),
                body: "Namaste Ramesh! Yes, Bajaj Pulsar 150 Front Disc Brake Pad is in stock at ₹285.".to_string(),
                delivery_status: "delivered".to_string(),
                created_at: "2026-10-15T07:00:02Z".to_string(),
            },
        ],
    );
    map
});

pub static USERS_BY_EMAIL: Lazy<DashMap<String, Value>> = Lazy::new(DashMap::new);
pub static API_KEYS_BY_HASH: Lazy<DashMap<String, Value>> = Lazy::new(DashMap::new);
pub static WEBHOOK_EVENT_DEDUP: Lazy<DashMap<String, String>> = Lazy::new(DashMap::new);
pub static AUDIT_LOGS: Lazy<DashMap<String, Vec<Value>>> = Lazy::new(DashMap::new);
pub static SAAS_CATALOG_ITEMS: Lazy<DashMap<String, Value>> = Lazy::new(|| {
    let map = DashMap::new();
    map.insert(
        "cat_1".to_string(),
        json!({"id": "cat_1", "tenant_id": DEFAULT_TENANT_ID, "sku": "HER-SPL-FB-BLK", "item_type": "product", "name": "Full Body Kit (Black)", "brand": "Hero", "model_or_line": "Splendor Plus", "category": "Body & Frame", "price": 2450.0, "stock_qty": 8}),
    );
    map.insert(
        "cat_2".to_string(),
        json!({"id": "cat_2", "tenant_id": DEFAULT_TENANT_ID, "sku": "TVS-STR-SP-RED", "item_type": "product", "name": "Side Panel Set (Red)", "brand": "TVS", "model_or_line": "Star Sport", "category": "Body & Frame", "price": 680.0, "stock_qty": 12}),
    );
    map.insert(
        "cat_3".to_string(),
        json!({"id": "cat_3", "tenant_id": DEFAULT_TENANT_ID, "sku": "BAJ-PUL150-BP", "item_type": "product", "name": "Front Disc Brake Pad", "brand": "Bajaj", "model_or_line": "Pulsar 150", "category": "Brakes", "price": 285.0, "stock_qty": 24}),
    );
    map
});
pub static CAMPAIGNS: Lazy<DashMap<String, Vec<Value>>> = Lazy::new(DashMap::new);
pub static CRM_CONTACTS: Lazy<DashMap<String, Vec<Value>>> = Lazy::new(DashMap::new);
pub static TEAM_MEMBERS: Lazy<DashMap<String, Vec<Value>>> = Lazy::new(DashMap::new);

pub struct AuthContext {
    pub tenant_id: String,
    pub user_id: String,
    pub role: String,
    pub is_super_admin: bool,
}

pub fn resolve_auth(headers: &HeaderMap) -> Result<AuthContext, (StatusCode, Json<Value>)> {
    HTTP_REQUESTS_TOTAL.fetch_add(1, Ordering::Relaxed);
    let header_tid = headers
        .get("X-Tenant-ID")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    if let Some(auth_str) = headers.get(header::AUTHORIZATION).and_then(|v| v.to_str().ok()) {
        if let Some(tok) = auth_str.strip_prefix("Bearer ") {
            if tok == "lakshmi_seed_session" {
                return Ok(AuthContext {
                    tenant_id: if header_tid.is_empty() { DEFAULT_TENANT_ID.to_string() } else { header_tid.to_string() },
                    user_id: "seed_owner".to_string(),
                    role: "workspace_owner".to_string(),
                    is_super_admin: true,
                });
            }
            let Some(claims) = verify_jwt(tok.trim()) else {
                return Err((StatusCode::UNAUTHORIZED, Json(json!({"error": "Invalid or expired Bearer token"}))));
            };
            let token_tid = claims.get("tenant_id").and_then(|v| v.as_str()).unwrap_or(DEFAULT_TENANT_ID);
            let is_sa = claims.get("is_super_admin").and_then(|v| v.as_bool()).unwrap_or(false);
            if !header_tid.is_empty() && header_tid != token_tid && !is_sa {
                return Err((StatusCode::FORBIDDEN, Json(json!({"error": "Cross-tenant access denied (IDOR guard)"}))));
            }
            return Ok(AuthContext {
                tenant_id: if header_tid.is_empty() { token_tid.to_string() } else { header_tid.to_string() },
                user_id: claims.get("sub").and_then(|v| v.as_str()).unwrap_or("user").to_string(),
                role: claims.get("role").and_then(|v| v.as_str()).unwrap_or("workspace_owner").to_string(),
                is_super_admin: is_sa,
            });
        }
    }

    if let Some(api_key) = headers.get("X-API-Key").and_then(|v| v.to_str().ok()) {
        if api_key.starts_with("lms_live_") {
            let mut hasher = Sha256::new();
            hasher.update(api_key.trim().as_bytes());
            let key_hash = format!("{:x}", hasher.finalize());
            let Some(k_entry) = API_KEYS_BY_HASH.get(&key_hash) else {
                return Err((StatusCode::UNAUTHORIZED, Json(json!({"error": "Invalid X-API-Key"}))));
            };
            let k_tid = k_entry.get("tenant_id").and_then(|v| v.as_str()).unwrap_or(DEFAULT_TENANT_ID);
            if !header_tid.is_empty() && header_tid != k_tid {
                return Err((StatusCode::FORBIDDEN, Json(json!({"error": "Cross-tenant API key access denied"}))));
            }
            return Ok(AuthContext {
                tenant_id: k_tid.to_string(),
                user_id: "apikey".to_string(),
                role: "developer".to_string(),
                is_super_admin: false,
            });
        }
    }

    let admin_pw = std::env::var("ADMIN_PASSWORD").unwrap_or_default();
    let req_pw = headers.get("X-Admin-Password").and_then(|v| v.to_str().ok()).unwrap_or("");
    if !admin_pw.is_empty() && !req_pw.is_empty() && constant_time_eq(req_pw.as_bytes(), admin_pw.as_bytes()) {
        return Ok(AuthContext {
            tenant_id: if header_tid.is_empty() { DEFAULT_TENANT_ID.to_string() } else { header_tid.to_string() },
            user_id: "legacy_admin".to_string(),
            role: "workspace_owner".to_string(),
            is_super_admin: true,
        });
    }

    Err((StatusCode::UNAUTHORIZED, Json(json!({"error": "Authentication required"}))))
}

pub fn default_tenant_summary() -> HashMap<&'static str, &'static str> {
    let mut map = HashMap::new();
    map.insert("id", DEFAULT_TENANT_ID);
    map.insert("slug", "lakshmi-motorcycle-spares");
    map.insert("business_name", "Lakshmi Motorcycle Spares");
    map.insert("plan", "pro_max");
    map
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_constant_time_eq() {
        assert!(constant_time_eq(b"lakshmi_2026", b"lakshmi_2026"));
        assert!(!constant_time_eq(b"lakshmi_2026", b"lakshmi_2027"));
        assert!(!constant_time_eq(b"short", b"longer_secret"));
    }

    #[test]
    fn test_rfc2104_hmac_and_hub_signature() {
        let secret = "meta_secret_2026";
        let payload = br#"{"object":"instagram","entry":[]}"#;
        let hex = hmac_sha256_hex(secret.as_bytes(), payload);
        let header = format!("sha256={}", hex);
        assert!(verify_hub_signature_256(secret, payload, &header));
        assert!(!verify_hub_signature_256(secret, payload, "sha256=0000000000000000"));
    }

    #[test]
    fn test_tenant_cache_key_isolation() {
        let k_a = tenant_cache_key("tenant-alpha", "search", "Pulsar 150 Brake Pad");
        let k_b = tenant_cache_key("tenant-beta", "search", "Pulsar 150 Brake Pad");
        assert_ne!(k_a, k_b);
        assert!(k_a.starts_with("t:tenant-alpha:search:"));
    }

    #[test]
    fn test_plan_quotas_tiers() {
        assert_eq!(PlanTier::Standard.quotas().max_channels, 2);
        assert_eq!(PlanTier::Pro.quotas().max_channels, 5);
        assert_eq!(PlanTier::ProMax.quotas().max_channels, 25);
        assert!(!PlanTier::Standard.quotas().custom_webhooks);
        assert!(PlanTier::Pro.quotas().custom_webhooks);
    }
}
