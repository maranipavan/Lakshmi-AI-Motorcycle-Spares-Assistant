# Architecture Documentation (`docs/ARCHITECTURE.md`)

**Last Updated:** 2026-10-15

## 1. Current Baseline Architecture (As Audited in `webapp (2).zip`)

### 1.1 Runtime Topology on Oracle Cloud VPS (1 vCPU / 1 GB RAM)
- **Reverse Proxy**: Nginx (terminates TLS for `lakshmimotorcyclespares.in` and routes traffic to local services).
- **Python Backend (`lakshmi.service`)**:
  - Gunicorn (`127.0.0.1:5000`, 1 sync worker, `preload_app = False`) running Flask (`backend/app.py`).
  - Handles storefront REST APIs (`/api/brands`, `/api/models/*`, `/api/parts`, `/api/search`, `/api/order`, `/api/delivery/check`), Service Booking APIs (`/api/service/*`), Meta Messenger/Instagram webhook (`/api/meta/webhook`), Telethon personal bridge (`/api/tgpersonal/*`), and loopback sidecar endpoints (`/internal/*`).
  - Runs an in-process `APScheduler` (`backend/scheduler.py`) for daily service reminders (`09:00` and `09:30` IST), 20-minute cache re-warming, and `02:00` IST chat cleanup.
- **Rust WebSocket Sidecar (`chat_ws` binary in `telegram_sync/src/chat_ws.rs`)**:
  - Listens on `0.0.0.0:8765`.
  - Handles `/ws/chat/admin`, `/ws/chat/:session_id`, and `/api/chat/*`.
  - Persists messages to Supabase `chat_messages` via PostgREST and calls Python `http://127.0.0.1:5000/internal/auto-reply` for bot replies.
- **Rust Telegram Webhook Gateway (`tg_bot` binary in `telegram_sync/src/tg_bot.rs` + `src/brain.rs`)**:
  - Listens on `127.0.0.1:5001` (`tg_bot.service`, `MemoryMax=150M`).
  - Handles `POST /api/telegram/webhook`.
  - Executes cart CRUD (`tg:cart:*`), checkout state machine (`tg:order:*`), Razorpay payment link creation, UPI screenshot approval, and pure-Rust NLU/catalog search (`brain.rs`).
  - Delegates `/history`, guided-browse category callbacks (`/internal/tg-callback`), non-UPI photos (`/internal/tg-photo`), owner reply training (`/internal/tg-owner-reply`), and final DB order insertion (`/internal/place-tg-order`) to Python on port `5000`.
- **Rust Telegram Channel & Image Sync (`telegram_sync` binary in `telegram_sync/src/main.rs`)**:
  - Connects via MTProto (`grammers-client`) using `lakshmi_channel_sync.session`.
  - Watches `@lakshmimotorcyclespare` for structured posts and syncs `spare_parts` + Supabase Storage `web_image_urls`.

## 2. Target Rust-First Multi-Tenant Modular Monolith Architecture

We will evolve the existing `telegram_sync` crate into a unified workspace (`omnichannel-saas`) with a modular monolith core (`saas-server`) and background worker (`saas-worker`), while maintaining 100% backward compatibility with the Lakshmi Motorcycle Spares storefront and existing data during migration:

1. **`auth` & `tenancy` Modules**:
   - Argon2id password hashing, JWT/session cookie authentication, API key management, workspace invitations, RBAC (`owner`, `admin`, `agent`, `viewer`, `super_admin`), and mandatory `TenantContext` middleware extractor on every route.
2. **`catalog` & `search` Modules**:
   - Business-agnostic `catalog_items` (supporting categories, brands, variants, SKUs, stock, prices, images, and JSONB `attributes` / `compatibility` metadata) with a backward-compatible view/adapter for `spare_parts`.
   - Shared multilingual NLU & search engine (upgraded from `brain.rs` + `auto_reply.py`) supporting English, Telugu, Romanized Telugu, and Hinglish, with tenant-scoped synonym/learned-reply dictionaries and normalized cache keys.
3. **`channels` & `crm` Modules**:
   - Capability-registered adapters for **Telegram** (Private, Groups, Supergroups, Channels), **Instagram** (DMs + Comments), **Facebook Page** (Messenger + Comments), **WhatsApp Business Cloud API**, and **Website Chat** (WebSocket + REST).
   - Shared internal `Conversation`, `Message`, `Contact`, and `Consent` models persisted to PostgreSQL so all channels (including Instagram/Facebook/WhatsApp, which currently do not save to `chat_messages`) appear in the Unified Inbox and CRM timeline.
4. **`workflows` & `comments` Modules**:
   - Declarative DAG workflow execution engine (JSON schema validated, versioned draft/publish, bounded step execution, zero arbitrary code execution) and configurable social comment automation rules.
5. **`ai_registry` Module**:
   - Provider-neutral trait supporting OpenAI, Anthropic, Google Gemini, Groq, Cerebras, OpenAI-compatible endpoints, and local Ollama/vLLM servers, with per-tenant model/key configuration, token/cost budget enforcement, circuit breakers, and prompt-injection sanitization.
6. **`commerce`, `billing`, & `scheduler` Modules**:
   - Reusable cart, order state machine, pincode/zone delivery calculator, and service slot booking.
   - Configurable SaaS subscription tiers (**Standard**, **Pro**, **Pro Max**), server-side entitlement/quota enforcement, and verified Razorpay/Stripe payment webhooks.
   - Durable PostgreSQL-backed job queue (`scheduled_jobs` with `FOR UPDATE SKIP LOCKED`) replacing volatile in-memory timers.
7. **`frontend` (Neumorphic React + TypeScript Dashboard)**:
   - Accessible light/dark neumorphic design system implementing all 25 required SaaS pages while preserving the public customer storefront and service booking experience.


## v3.1.0 Pure Rust Axum Architecture Summary
- **100% Rust Backend (`telegram_sync/` & `lakshmi_search/`)**: 11 Rust modules (`saas_server.rs`, `saas_core.rs`, `cache_layer.rs`, `channels.rs`, `services_booking.rs`, `storefront_api.rs`, `brain.rs`, `tg_bot.rs`, `chat_ws.rs`, `main.rs`, `lakshmi_search/src/lib.rs`) totaling ~9,000 lines of Rust code.
- **156 Registered Axum Routes**: 100% coverage of all `/api/v1/*` multi-tenant SaaS routes, `/api/*` storefront & admin routes, `/api/service/*` & `/api/services/*` 9-slot booking routes, `/webhook*` omnichannel & payment webhooks, `/ws/chat/*` WebSockets, and static frontend serving (`/`, `/admin`, `/saas`, `/dashboard`, `/privacy`, `/css/*`, `/js/*`).
- **Zero Legacy Python Runtime**: All 40 legacy `.py` files and `Dockerfile.python` have been retired and removed.
