# Project Status & Mandatory Repository Audit (`docs/PROJECT_STATUS.md`)

**Last Updated:** 2026-10-15 (Phase 1 Mandatory Repository Audit Complete)  
**Current Phase:** Phase 1 Complete → Awaiting Owner Confirmation on Phase 2 Architectural Decisions

## 1. Executive Summary of Actual Repository State
We inspected the complete `webapp (2).zip` archive (`backend/`, `frontend/`, `telegram_sync/`, `schema.sql`, `DEPLOY.md`, `deploy_all.sh`, `lakshmi.service`, `tg_bot.service`).

### Key Truths Established by Code Inspection
1. **Web Framework is Flask (Not FastAPI)**:
   - Despite initial project notes mentioning FastAPI, `backend/app.py` is built on **Flask (`>=3.0.0`)**, `flask-cors`, `flask-limiter`, `flask-sock`, and `gevent` served by **Gunicorn** (`127.0.0.1:5000`, `workers = 1`, `worker_class = "sync"` in `gunicorn.conf.py`).
2. **Existing Hybrid Rust + Python Architecture (`telegram_sync` Crate)**:
   - The repository already contains a 3-binary Rust workspace in `telegram_sync/Cargo.toml`:
     - `telegram_sync` (`src/main.rs`): Grammers MTProto client (`grammers-client 0.9.0`) that watches `@lakshmimotorcyclespare` for structured posts (`Brand:`, `Model:`, `Part:`, `Price:`, `Stock:`), upserts into `spare_parts`, and scrapes/uploads product photos to Supabase Storage bucket `web_image_urls`.
     - `chat_ws` (`src/chat_ws.rs`): Axum `0.7` WebSocket + REST sidecar on port `8765` (`/ws/chat/admin`, `/ws/chat/:session_id`, `/api/chat/*`), using `DashMap` and `tokio::sync::broadcast`, calling Python loopback endpoints (`/internal/auto-reply`, `/internal/save-learned-reply`, `/internal/push-admin`) in `backend/internal_endpoints.py`.
     - `tg_bot` (`src/tg_bot.rs` + `src/brain.rs`): Stage-1 Axum Telegram webhook gateway on port `5001` (`POST /api/telegram/webhook`, `GET /health`). Note that **two versions of `tg_bot.rs` exist**: `backend/tg_bot.rs` (older Stage-1 version that delegates all text to Python `/internal/tg-text`) and `telegram_sync/src/tg_bot.rs` (newer version that embeds `brain.rs`, a 2,374-line pure-Rust NLU + dialogue manager + Supabase REST client, and only delegates `/history`, photos, guided-browse callbacks, and order placement to Python `/internal/tg-*`).
   - Additionally, `backend/api_database.py` attempts to import a PyO3 extension `from lakshmi_search import search_and_rank`, though the source crate for `lakshmi_search` is not included in the archive (it falls back cleanly to Python scoring).
3. **Database Schema (`schema.sql`)**:
   - 9 tables defined in `schema.sql`: `spare_parts`, `orders`, `chat_messages`, `bot_training`, `service_bookings`, `service_reminders`, `service_reviews`, `service_job_parts`, and `delivery_zones` (seeded with 38 AP/Telangana pincodes).
   - **Schema Drift Found**:
     - `api_database.py` calls Postgres RPCs `next_order_seq(p_day)` and `get_recent_tg_sessions(p_limit)`, which are **not defined in `schema.sql`** (the code falls back to Python queries when they are absent).
     - `orders` inserts `order_notes` (`api_database.py` line 445) and `service_routes.py` selects `order_notes` (line 458), `started_at`, `owner_notes`, `service_charge` on `service_bookings` (lines 1165–1174), and `part_id`, `part_category`, `notes` on `service_job_parts` (lines 1223–1229), plus `telegram_message_id` and `edited` on `chat_messages` (`chat.py` lines 473, 505) and `telegram_post_id` on `spare_parts` (`channel_sync.py` line 122 / `main.rs` line 64) — **none of these columns are in `schema.sql`**.
   - **Row-Level Security (RLS) Misconfiguration**: `schema.sql` lines 246–264 enable RLS on all tables and immediately grant `FOR ALL TO anon, service_role USING (true) WITH CHECK (true)`, and `app.py` `/api/config` exposes `supabase_url` and `supabase_anon_key` to the browser. Anyone with the public anon key can read, modify, or delete all rows in `orders`, `chat_messages`, `spare_parts`, and `service_bookings`.

## 2. Implementation Inventory (Verified Statuses)

| Module / Capability | Current Location | Status | Notes & Evidence |
| :--- | :--- | :--- | :--- |
| **Catalog & Fitment Search (Single-Tenant)** | `backend/api_database.py`, `backend/auto_reply.py`, `telegram_sync/src/brain.rs` | **Partial** | Works for motorcycle spare parts (`bike_brand`, `bike_model`, `year_from`, `year_to`). Hardcoded to motorcycle domain and Lakshmi Spares metadata. |
| **Telegram Bot (Cart, Guided Browse, UPI/Razorpay)** | `backend/telegram_bot.py`, `backend/tg_internal.py`, `telegram_sync/src/tg_bot.rs`, `telegram_sync/src/brain.rs` | **Partial** | Operational for single tenant. `telegram_bot.py` has stub bug in `_process_callback` and duplicate photo/owner-reply code (lines 898–980). `tg_bot.rs` uses flat delivery charge instead of pincode zones. |
| **Telegram Channel Inventory & Image Sync** | `telegram_sync/src/main.rs`, `backend/channel_sync.py`, `backend/image_sync.py` | **Verified Complete (Single-Tenant)** | Rust binary (`telegram_sync`) watches Telegram channel posts and syncs parts + images to Supabase. |
| **Telegram Personal Account Bridge** | `backend/tg_personal.py`, `backend/app.py` (`/api/tgpersonal/*`) | **Partial** | Uses Telethon with local `tg_session.session`. Single-tenant only; writes `TG_API_ID`/`TG_API_HASH` directly to `backend/.env`. |
| **Facebook Messenger & Instagram DM Bot** | `backend/meta_bot.py` (`/api/meta/webhook`) | **Partial** | Supports DMs, HMAC-SHA256 verification, 2h echo-based human takeover pause, 7-day IG token refresh, quick replies, and card carousels. Single-tenant only. |
| **Instagram & Facebook Comment Automation** | Not implemented (`meta_bot.py` ignores `changes`/`feed`) | **Missing** | Required by Sections 2 & 13; `meta_bot.py` only processes `entry.messaging` DM events. |
| **WhatsApp Business Platform Adapter** | Not implemented (only `wa.me` links exist) | **Missing** | Required by Sections 2 & 7; no WhatsApp Cloud API webhook or outbound sender exists in the repo. |
| **Website Customer & Admin Chat** | `telegram_sync/src/chat_ws.rs`, `backend/chat.py`, `backend/internal_endpoints.py` | **Partial** | Rust `chat_ws` sidecar + Python fallback work for single tenant. Uses static `ADMIN_PIN` (default `1234` in `chat_ws.rs`). |
| **Service Slot Booking & Reminders** | `backend/service_routes.py`, `backend/service_db.py`, `backend/scheduler.py`, `frontend/js/service.js` | **Verified Complete (Single-Tenant)** | 9 daily slots, ₹500 Razorpay deposit, HMAC verification, 24h cancellation window, APScheduler reminders, star reviews. |
| **Multi-Tenant Isolation (Workspaces, RBAC, RLS)** | None | **Missing** | Zero `tenant_id` columns, no user accounts/JWT/sessions, global Redis keys, global in-memory caches. |
| **SaaS Subscriptions (Standard, Pro, Pro Max)** | None | **Missing** | No plans, entitlements, quotas, usage metering, or subscription billing webhooks. |
| **Visual Drag-and-Drop Workflow Builder** | None | **Missing** | Currently hardcoded Python/Rust state machines (`auto_reply.py` / `brain.rs`). |
| **Durable Campaign & Broadcast Scheduler** | `backend/scheduler.py` (APScheduler in-memory cron only) | **Missing** | Only runs 2 hardcoded service reminder jobs + cache rewarm + chat cleanup. No campaign queue or audience segmentation. |
| **25-Page Neumorphic React/TypeScript SaaS Dashboard** | `frontend/index.html`, `frontend/admin.html` (Vanilla HTML/JS) | **Missing** | Current UI is 2 vanilla HTML pages (`index.html` storefront + `admin.html` dark-orange owner panel). |


## Phase 2–10 Implementation & Verification Summary (Completed)
- All security remediations (`SEC-01` through `SEC-07`) and bug fixes (`BUG-01` through `BUG-04`) implemented and verified.
- Multi-tenant database migrations (`migrations/0001_schema_drift_and_rls_hardening.sql` and `migrations/0002_multi_tenant_saas_schema.sql`) created preserving Lakshmi Motorcycle Spares (`00000000-0000-0000-0000-000000000001`).
- Omnichannel SaaS API (`backend/saas_api.py`), WhatsApp Cloud API v19.0 (`backend/whatsapp_bot.py`), Comment-to-DM engine (`backend/comment_automation.py`), and Rust SaaS gateway (`telegram_sync/src/saas_core.rs`, `telegram_sync/src/saas_server.rs`, `lakshmi_search`) implemented.
- 25-Page Neumorphic SaaS Dashboard (`frontend/saas_dashboard.html`) validated with zero console/page/layout errors.
- 10/10 automated test suites and 10–1,000 concurrency load benchmarks executed and recorded in `docs/TEST_RESULTS.md`.
