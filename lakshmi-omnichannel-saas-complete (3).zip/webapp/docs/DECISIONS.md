# Architectural & Product Decisions (`docs/DECISIONS.md`)

**Last Updated:** 2026-10-15

## 1. Decisions Established from Repository Inspection
- **DEC-001 (Preserve Existing Lakshmi Motorcycle Spares Behavior)**: The existing application serves Lakshmi Motorcycle Spares (`lakshmimotorcyclespares.in`) with two physical shops in Nellore and Tirupati, AP, India, supporting spare-parts e-commerce AND a 9-slot daily motorcycle service booking system (`service_bookings`, `service_reminders`, `service_reviews`, `service_job_parts`). In the multi-tenant SaaS evolution, Lakshmi Motorcycle Spares will be preserved as the default seed tenant (`tenant_slug = "lakshmi-motorcycle-spares"`), and both **Product Catalog Commerce** and **Appointment / Service Slot Booking** will be first-class configurable modules for any tenant (e.g., auto garages, salons, clinics, consultants, retailers).
- **DEC-002 (Consolidate Duplicate `tg_bot.rs` Files)**: The repository currently has two diverging copies of `tg_bot.rs`: `backend/tg_bot.rs` (60 KB, older Stage-1 without `brain.rs`) and `telegram_sync/src/tg_bot.rs` (64 KB, newer with `brain.rs` and `admin:settings` checks). `telegram_sync/src/tg_bot.rs` is the canonical source referenced by `telegram_sync/Cargo.toml`; `backend/tg_bot.rs` will be removed/archived to prevent accidental deployment of stale code.

## 2. Open Decisions Awaiting Owner Confirmation (Phase 1 → Phase 2 Gate)
1. **OPEN-01: Incremental Cutover & Coexistence Topology**
   - *Context*: Today, Nginx routes traffic across Gunicorn (`127.0.0.1:5000`), Rust `tg_bot` (`127.0.0.1:5001`), and Rust `chat_ws` (`0.0.0.0:8765`), with `tg_bot` and `chat_ws` making loopback HTTP calls to Flask `/internal/*`.
   - *Options*:
     - **Option 1 (Recommended)**: Consolidate `tg_bot`, `chat_ws`, and the new SaaS APIs into a single unified Rust Axum server (`saas-server` on port `8080`, with feature-flagged shadow mode and per-channel routing at Nginx or Axum proxy fallback to Flask `:5000` until all Python endpoints are retired). This eliminates maintaining 3 separate processes and shares a single SQLx + Redis connection pool on your 1 GB RAM VPS.
     - **Option 2**: Keep `tg_bot` (`:5001`), `chat_ws` (`:8765`), and a separate SaaS API binary as independent systemd services.
2. **OPEN-02: Database Access Strategy (Direct PostgreSQL `SQLx` vs. Supabase PostgREST)**
   - *Context*: Currently, both Python (`api_database.py`, `supabase_cdn.py`) and Rust (`main.rs`, `chat_ws.rs`, `brain.rs`) talk to Supabase over HTTP PostgREST (`/rest/v1/...`) rather than a direct PostgreSQL wire connection (`DATABASE_URL` with `sqlx::PgPool`).
   - *Options*:
     - **Option 1 (Recommended)**: Implement a dual-adapter `DatabaseProvider` trait in Rust supporting **native `SQLx` PostgreSQL connection pooling (`DATABASE_URL`)** as primary (required for transactions, migrations, Row-Level Security session variables, and Neon/self-hosted Postgres compatibility) while retaining a **Supabase PostgREST/CDN adapter** for zero-egress cached catalog reads where configured.
     - **Option 2**: Use `SQLx` direct PostgreSQL connections exclusively and retire PostgREST calls.
3. **OPEN-03: Subscription Plans & Payment Providers (Section 6 & 16)**
   - *Context*: The existing system uses **Razorpay** + **Manual UPI (with screenshot approval)** in INR (`₹`).
   - *Options*:
     - **Option 1 (Recommended)**: Use **Razorpay + Manual UPI** as the primary verified payment adapters for both SaaS subscriptions (Standard ₹999/mo, Pro ₹2,499/mo, Pro Max ₹5,999/mo — all admin-configurable in DB) and tenant customer orders, while implementing the **Stripe** adapter behind the same `PaymentProvider` trait for international tenants.
     - **Option 2**: Different default pricing or billing intervals for Standard / Pro / Pro Max.
4. **OPEN-04: Telethon / Grammers MTProto Session Handling in Multi-Tenant SaaS**
   - *Context*: `telegram_sync/src/main.rs` (`grammers-client`) and `backend/tg_personal.py` (`telethon`) log into a personal Telegram user account using `TG_API_ID`/`TG_API_HASH` and local SQLite `.session` files. Official Telegram Bot API (`TELEGRAM_TOKEN`) is used for the customer bot (`tg_bot.rs`).
   - *Options*:
     - **Option 1 (Recommended)**: Standardize the multi-tenant Telegram channel adapter on the **Official Telegram Bot API** (supporting private chats, groups, supergroups, forum topics, and channels where the bot is added as an admin), while keeping the MTProto channel-scraper/personal-account bridge as an optional, explicitly gated Pro Max / self-hosted extension with encrypted per-tenant session storage.
     - **Option 2**: Expose personal MTProto user-account login to all SaaS tenants (carries Telegram account-ban risk and interactive OTP/2FA state complexity).
