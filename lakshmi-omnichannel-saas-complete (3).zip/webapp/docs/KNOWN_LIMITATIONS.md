# Known Limitations & Operational Risks (`docs/KNOWN_LIMITATIONS.md`)

**Last Updated:** 2026-10-15 (Phase 1 Audit)

## 1. Environment & Verification Constraints
1. **No Outbound Network or Live Third-Party Credentials in Sandbox Environment**:
   - Live webhook round-trips against Telegram (`api.telegram.org`), Meta Graph API (`graph.facebook.com`, `graph.instagram.com`), WhatsApp Cloud API, Groq, Cerebras, Razorpay, Resend, and remote Supabase cannot be executed from this isolated environment. All external adapters must be verified via deterministic unit/integration tests with recorded webhook fixtures here, and marked **Awaiting Live Provider Verification** until run on the Oracle Cloud VPS with live credentials.
2. **Rust Compiler (`rustc` / `cargo`) Not Pre-Installed in Sandbox Container**:
   - The current container image provides `Python 3.11.2` and `Node.js v18.20.4 / npm 9.2.0`, but does not have `rustc` or `cargo` pre-installed and has no outbound internet access to download `rustup`.
   - Any Rust code written or updated in this environment is verified against the pinned crate versions in `telegram_sync/Cargo.toml` and `Cargo.lock` (`axum 0.7`, `tokio 1`, `reqwest 0.12`, `redis 0.25`, `serde 1`, `dashmap 6`), and accompanied by an executable verification script (`scripts/verify_build_and_tests.sh`) for your VPS/CI, while all Python and TypeScript/Node tests are executed directly here.

## 2. Existing Codebase Defects Identified in Phase 1
1. **`backend/telegram_bot.py` Callback Stub & Dead Duplicate Code**:
   - `handle_callback_data` (line 451) delegates to `_process_callback` (line 467), which is `pass`. (`_dispatch_callback` at line 477 works around this by calling `_process_update`.)
   - Lines 898–980 in `_process_update` duplicate the exact owner-reply and photo-handling blocks already executed at lines 739–828 (unreachable dead code).
2. **Divergent `tg_bot.rs` Files**:
   - `backend/tg_bot.rs` is an older copy without `brain.rs`, whereas `telegram_sync/src/tg_bot.rs` includes `mod brain;` and `admin:settings` checks.
3. **`telegram_sync/src/brain.rs` Alias Ordering Bug**:
   - In `PART_ALIASES`, `("brakelu", "brake")` (line 315) and `("brake", "brake pads")` (line 329) conflict with `test_part_aliases` (line 2337), which expects `"brakelu kavali"` to extract `"brake pads"`, but `extract_parts` returns `["brake"]`.
4. **Flat Delivery Charge in `tg_bot.rs` & `brain.rs`**:
   - Unlike Python's `app.get_delivery_charge_for_address(address)` (which checks the `delivery_zones` table by 6-digit pincode), `tg_bot.rs` and `brain.rs` use a flat ₹200 (`admin:settings.delivery_charge` or `DELIVERY_CHARGE`) regardless of the customer's pincode.
5. **Unimplemented Razorpay Webhook (`/internal/razorpay-webhook`)**:
   - In `backend/tg_internal.py` (line 348), `/internal/razorpay-webhook` is a `# TODO Stage 2` stub returning `{"ok": True}` without verifying `X-Razorpay-Signature` or placing the Telegram order. If a customer pays via a Razorpay payment link on Telegram, the order is never automatically placed!
6. **Missing Columns & RPCs in `schema.sql`**:
   - `schema.sql` is missing columns actively used by the code (`spare_parts.telegram_post_id`, `orders.order_notes`, `chat_messages.edited`, `chat_messages.telegram_message_id`, `service_bookings.started_at`, `service_bookings.owner_notes`, `service_bookings.service_charge`, `service_job_parts.part_id`, `service_job_parts.part_category`, `service_job_parts.notes`) and missing RPCs (`next_order_seq`, `get_recent_tg_sessions`).
