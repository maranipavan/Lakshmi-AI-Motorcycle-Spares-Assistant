# Deployment & Operations Guide (`docs/DEPLOYMENT.md`)

**Last Updated:** 2026-10-15 (Baseline Audited from `DEPLOY.md`, `deploy_all.sh`, `lakshmi.service`, `tg_bot.service`, `gunicorn.conf.py`)

## 1. Current Production Deployment Baseline (Audited)
- **Target Host**: Oracle Cloud VPS (`ubuntu@spare`, 1 vCPU / 1 GB RAM).
- **Application Directory**: `/home/ubuntu/webapp` (note: `DEPLOY.md` references `/var/www/lakshmi`, whereas `lakshmi.service`, `tg_bot.service`, `gunicorn.conf.py`, and `deploy_all.sh` all use `/home/ubuntu/webapp` — `/home/ubuntu/webapp` is the actual production path).
- **Systemd Services**:
  - `lakshmi.service`: Runs `/home/ubuntu/webapp/backend/venv/bin/gunicorn -c gunicorn.conf.py app:app` on `127.0.0.1:5000` (`workers=1`, `worker_class="sync"`, `max_requests=2000`).
  - `tg_bot.service`: Runs `/home/ubuntu/webapp/telegram_sync/target/release/tg_bot` on `127.0.0.1:5001` (`MemoryMax=150M`, `MemorySwapMax=20M`).
  - `chat_ws`: Built from `telegram_sync/Cargo.toml` (`--bin chat_ws`), listens on `0.0.0.0:8765`. (Note: No `chat_ws.service` or `telegram_sync.service` unit file was included in the zip archive; we will generate reproducible systemd units and Docker Compose configs for all services).
  - Nginx reverse proxy config is currently outside the repository; we will add a version-controlled `deploy/nginx/omnichannel-saas.conf` that explicitly blocks `/internal/*` from external traffic and routes `/ws/chat/*`, `/api/*`, and webhooks cleanly.
