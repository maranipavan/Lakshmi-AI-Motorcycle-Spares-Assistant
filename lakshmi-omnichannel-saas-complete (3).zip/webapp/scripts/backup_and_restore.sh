#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Safe Backup & Rollback Utility for Lakshmi Motorcycle Spares & SaaS Platform
# =============================================================================
MODE="${1:-backup}"
BACKUP_DIR="${2:-./backups/$(date +%Y%m%d_%H%M%S)}"

if [[ "$MODE" == "backup" ]]; then
    mkdir -p "$BACKUP_DIR"
    echo "[BACKUP] Saving SQLite state & configuration metadata to $BACKUP_DIR..."
    if [[ -f "backend/saas_state.db" ]]; then
        cp "backend/saas_state.db" "$BACKUP_DIR/saas_state.db"
    fi
    if [[ -n "${DATABASE_URL:-}" ]] && command -v pg_dump >/dev/null 2>&1; then
        pg_dump "$DATABASE_URL" > "$BACKUP_DIR/supabase_postgres_dump.sql"
        echo "[BACKUP] PostgreSQL dump completed."
    else
        echo "[BACKUP] DATABASE_URL or pg_dump not present; skipped remote PostgreSQL dump."
    fi
    echo "[BACKUP] Completed successfully at $BACKUP_DIR"
elif [[ "$MODE" == "restore" ]]; then
    if [[ ! -d "$BACKUP_DIR" ]]; then
        echo "[ERROR] Backup directory $BACKUP_DIR not found." >&2
        exit 1
    fi
    if [[ -f "$BACKUP_DIR/saas_state.db" ]]; then
        cp "$BACKUP_DIR/saas_state.db" "backend/saas_state.db"
        echo "[RESTORE] Restored backend/saas_state.db"
    fi
    echo "[RESTORE] Rollback complete."
else
    echo "Usage: $0 {backup|restore} [backup_dir]" >&2
    exit 1
fi
