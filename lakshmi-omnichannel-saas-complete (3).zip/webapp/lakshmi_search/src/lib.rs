//! Reconstructs the source for the `lakshmi_search` native Rust search crate
//! so it can be audited, unit-tested, and compiled across platforms without
//! relying solely on a prebuilt `.so` binary artifact.

pub fn normalize_query(q: &str) -> String {
    let mut s = q.to_lowercase();
    for (slang, canonical) in [
        ("brakelu", "brake pads"),
        ("break pad", "brake pad"),
        ("cluch", "clutch"),
        ("sproket", "sprocket"),
        ("silensar", "silencer"),
        ("indikater", "indicator"),
        ("accelator", "accelerator"),
    ] {
        s = s.replace(slang, canonical);
    }
    s.split_whitespace().collect::<Vec<_>>().join(" ")
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_brakelu_not_corrupted() {
        assert_eq!(normalize_query("Pulsar 150 brakelu"), "pulsar 150 brake pads");
    }
}
