# VPS Deployment Guide (1 CPU / 1 GB RAM)

## Pre-Deployment Checklist

### 1. Update .env for Production
```bash
cd backend
nano .env
```

Change these values:
```env
LOCAL_DEV=                    # Remove or set to empty (not 'true')
SITE_URL=https://lakshmimotorcyclespares.in
VECTOR_SEARCH_ENABLED=false   # Already set - saves 200-300 MB RAM
RESEND_API_KEY=re_...         # Resend API key (keep secret)
RESEND_FROM_EMAIL=Lakshmi Motorcycle Spares <orders@your-verified-domain>
```

Order confirmation emails use Resend. Create an API key and verify the sending
domain in Resend first, then set these values in `backend/.env` on the server.
The `RESEND_FROM_EMAIL` address must use that verified domain. Restart the app
after updating the environment. If the credentials are absent or the email
provider is unavailable, the order is still saved and the failure is logged.

### 2. Files to Upload to VPS
```
backend/          # All Python files
frontend/         # All HTML/CSS/JS files
lakshmi.service   # Systemd service file
schema.sql        # Database schema (if not already applied)
```

### 3. Files NOT Needed on VPS (skip these)
```
.vscode/          # Editor config
storage/          # Qdrant data (vector search disabled)
snapshots/        # Local dev snapshots
auto_reply.py     # Old duplicate file (use backend/auto_reply.py)
cleanup_bad_training.py  # One-time script
qdrant_setup.sh   # Not needed (vector search disabled)
.qdrant-initialized  # Not needed
```

---

## VPS Setup Commands

### 1. Install Dependencies
```bash
cd /var/www/lakshmi  # or your app directory
cd backend
pip3 install -r requirements.txt
```

### 2. Apply Database Schema (if first time)
```bash
# Run schema.sql on your Supabase instance via Dashboard → SQL Editor
# Or use psql if you have direct access
```

### 3. Setup Systemd Service
```bash
sudo cp lakshmi.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable lakshmi.service
sudo systemctl start lakshmi.service
```

### 4. Check Status
```bash
sudo systemctl status lakshmi.service
sudo journalctl -u lakshmi.service -f  # Follow logs
```

---

## Memory Optimization (Already Applied)

✅ Vector search disabled - saves 200-300 MB  
✅ Gunicorn workers: 2-3 max (check gunicorn.conf.py)  
✅ In-process LRU cache (no Redis needed)  
✅ Service booking enabled (uses ~15-20 MB per worker)

**Expected RAM usage**: 300-400 MB (leaves 600-700 MB free)

---

## Verify Deployment

### 1. Check Logs for Startup Messages
```bash
sudo journalctl -u lakshmi.service -n 50
```

Look for:
```
[startup] ✅ Hot caches warmed
[startup] ✅ Common bike queries pre-warmed
[vector] ℹ️  Vector search disabled (VECTOR_SEARCH_ENABLED=false)
```

### 2. Test Endpoints
```bash
# Health check
curl https://lakshmimotorcyclespares.in/api/health

# Config (should return Razorpay key + Supabase URL)
curl https://lakshmimotorcyclespares.in/api/config

# Brands
curl https://lakshmimotorcyclespares.in/api/brands
```

### 3. Test Telegram Bot
Send a message to your bot:
```
cd 100 ss
```
Should return parts list with prices.

---

## Troubleshooting

### High Memory Usage
```bash
# Check actual RAM usage
free -h
ps aux --sort=-%mem | head -10

# Reduce workers if needed
nano backend/gunicorn.conf.py
# Set: workers = 2
sudo systemctl restart lakshmi.service
```

### Bot Not Responding
```bash
# Check webhook status
curl "https://api.telegram.org/bot<YOUR_TOKEN>/getWebhookInfo"

# Re-register webhook (replace <PIN> with your ADMIN_PIN)
curl -X POST "https://lakshmimotorcyclespares.in/api/telegram/set-webhook" \
  -H "Content-Type: application/json" \
  -d '{"url":"https://lakshmimotorcyclespares.in","pin":"<PIN>"}'
```

### Scheduler Not Running
```bash
# Check logs for scheduler messages
sudo journalctl -u lakshmi.service | grep scheduler

# Should see:
# [scheduler] Started — day_before @ 09:00 IST, periodic @ 09:30 IST
```

---

## Post-Deployment

### Monitor RAM Usage
```bash
# Real-time monitoring
watch -n 2 free -h

# Or use admin panel
https://lakshmimotorcyclespares.in/admin.html
# Login with ADMIN_PIN → Server Stats tab
```

### Update Code (Future Deployments)
```bash
cd /var/www/lakshmi
git pull  # or upload via SFTP
cd backend
pip3 install -r requirements.txt  # if dependencies changed
sudo systemctl restart lakshmi.service
```

---

## What Changed in This Deployment

1. ✅ Scheduler `setex` error fixed
2. ✅ Startup pre-warming for top 11 bikes
3. ✅ Model normalization (CD-100 SS with spaces/hyphens)
4. ✅ Confirmation buttons (`CONFIRM:` logic)
5. ✅ Admin realtime subscriptions
6. ✅ Bot text cleaning (META:/SUGGEST: stripped)
7. ✅ Vector search disabled (saves RAM)

All changes are backward compatible - just restart the service.
