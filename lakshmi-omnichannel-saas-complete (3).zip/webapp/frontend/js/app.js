// API Base URL - Update this with your backend URL
const API_URL = '/api';

// Configuration
let RAZORPAY_KEY = null;
let DELIVERY_CHARGE = 200;

// Telegram Web App
const tg = window.Telegram?.WebApp;

if (tg) {
    tg.expand();
    tg.ready();
}

const user = tg?.initDataUnsafe?.user;

// State
let cart = JSON.parse(localStorage.getItem('cart') || '[]');
let currentFilters = {};
let navigationHistory = []; // Track navigation history
let lastScrollTop = 0; // Track scroll position for nav bar

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    renderStaticCategoryIcons();
    initializeApp();
    loadHeroFullBodyShowcase();
    setupEventListeners();
    updateCartBadge();
    setupScrollBehavior();
    animatePlaceholder();

    // Reposition fixed suggestions on scroll/resize
    const reposition = () => {
        ['searchInput'].forEach(id => {
            const input = document.getElementById(id);
            const sugId = 'searchSuggestions';
            const container = document.getElementById(sugId);
            if (input && container && container.classList.contains('show')) {
                positionSuggestions(input, container);
            }
        });
    };
    window.addEventListener('scroll', reposition, { passive: true });
    window.addEventListener('resize', reposition, { passive: true });
});

async function initializeApp() {
    try {
        showLoading();
        
        // Add timeout protection
        const timeout = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Initialization timeout')), 10000)
        );
        
        await Promise.race([
            Promise.all([
                loadConfig(),
                loadBrands(),
                loadPopularBrands(),
                loadAllCategories(),
                loadHomepagePicks()
            ]),
            timeout
        ]);
        
        hideLoading();
        window._appReady = true;
        // Fire any pending deep-link
        if (window._pendingDeepLink) {
            openProductDetails(window._pendingDeepLink);
            window._pendingDeepLink = null;
        }
        // Handle ?buy=<part_id> or ?checkout=<token> — if handled, don't show homepage
        const deepLinkHandled = await handleBuyDeepLink();
        if (deepLinkHandled) {
            return; // Stop here, deep link handler already showed the right page
        }
    } catch (error) {
        console.error('Init error:', error);
        hideLoading();
        window._appReady = true;
        if (window._pendingDeepLink) {
            openProductDetails(window._pendingDeepLink);
            window._pendingDeepLink = null;
        }
        const deepLinkHandled = await handleBuyDeepLink();
        if (deepLinkHandled) {
            return; // Stop here
        }
        // Show error to user
        const container = document.getElementById('filterSection');
        if (container) {
            container.innerHTML = `
                <div style="padding: 20px; text-align: center; color: #ff6b6b;">
                    <p>Failed to load app. Please refresh the page.</p>
                    <p style="font-size: 12px; color: #999;">${error.message}</p>
                </div>
            `;
        }
    }
}

// ?buy=<part_id> deep-link: add part to cart and navigate to checkout
async function handleBuyDeepLink() {
    const params = new URLSearchParams(window.location.search);
    const buyId = params.get('buy');
    const productId = params.get('product');
    const checkoutToken = params.get('checkout') || params.get('cart'); // support both

    // ?cart=<token> or ?checkout=<token> — load shared cart
    if (checkoutToken) {
        history.replaceState(null, '', window.location.pathname);
        try {
            const res = await fetch(`${API_URL}/cart/token/${checkoutToken}`);
            if (!res.ok) {
                alert('Cart link expired or invalid. Please try again.');
                return false;
            }
            const data = await res.json();
            
            // Convert backend format to cart item format
            cart = (data.items || []).map(item => ({
                part_id: String(item.id || item.part_id || ''),
                part_name: item.part_name || 'Unknown Part',
                price: parseFloat(item.price) || 0,
                bike_brand: item.bike_brand || '',
                bike_model: item.bike_model || '',
                color: item.color || '',
                image_url: item.image_url || null,
                quantity: 1
            })).filter(item => item.part_id);
            
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCartBadge();
            navigateTo('cart');
            return true;
        } catch (e) {
            console.error('Cart token error:', e);
            alert('Failed to load cart. Please try again.');
            return false;
        }
    }

    // ?product=<id> — open product detail page directly
    if (productId) {
        history.replaceState(null, '', window.location.pathname);
        try {
            let product = _productCache[String(productId)];
            if (!product) {
                const res = await fetch(`${API_URL}/part/${productId}`);
                if (!res.ok) return false;
                product = await res.json();
                _productCache[String(productId)] = product;
            }
            displayProductDetails(product);
            navigateTo('product-detail');
            return true;
        } catch (e) {
            console.error('Product deep-link error:', e);
            return false;
        }
    }

    // ?buy=<id> — add to cart and go to checkout
    if (!buyId) return false;
    try {
        let product = _productCache[String(buyId)];
        if (!product) {
            const res = await fetch(`${API_URL}/part/${buyId}`);
            if (!res.ok) return false;
            product = await res.json();
            _productCache[String(buyId)] = product;
        }
        _doAddToCart(product);
        // Clean URL so refresh doesn't re-add
        history.replaceState(null, '', window.location.pathname);
        navigateTo('checkout');
        return true;
    } catch (e) {
        console.error('Buy deep-link error:', e);
        return false;
    }
}

async function loadConfig() {
    try {
        const response = await fetch(`${API_URL}/config`);
        if (response.ok) {
            const config = await response.json();
            RAZORPAY_KEY = config.razorpay_key;
            DELIVERY_CHARGE = Number(config.delivery_charge ?? 200);
        }
    } catch (error) {
        console.error('Config load error:', error);
        // Don't throw error - app should continue working even if config fails
    }
}

function setupEventListeners() {
    // Use one shared search field across desktop and mobile.
    ['searchInput'].forEach(id => {
        const input = document.getElementById(id);
        if (!input) return;
        const suggestionsId = 'searchSuggestions';
        const clearBtnId    = 'searchClear';
        const clearBtn      = document.getElementById(clearBtnId);

        // Show/hide clear button as user types
        function updateClearBtn() {
            if (clearBtn) clearBtn.style.display = input.value.length > 0 ? 'flex' : 'none';
        }

        // Clear button click — wipe input, close suggestions, reset products
        if (clearBtn) {
            clearBtn.addEventListener('mousedown', (e) => {
                e.preventDefault(); // don't blur input
                input.value = '';
                syncSearchInputs('', id);
                closeAllSuggestions();
                updateClearBtn();
                input.focus();
                // Reset product list to show all / default view
                loadParts({ limit: 50 });
                navigateTo('products');
            });
        }

        input.addEventListener('input', debounce((e) => {
            updateClearBtn();
            handleSearchInput(e, suggestionsId);
        }, 250));

        input.addEventListener('keydown', (e) => {
            const container = document.getElementById(suggestionsId);
            const items = container.querySelectorAll('.suggestion-item, .suggestion-search-all');
            const focused = container.querySelector('.focused');
            const idx = Array.from(items).indexOf(focused);

            if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (focused) focused.classList.remove('focused');
                const next = items[idx + 1] || items[0];
                if (next) { next.classList.add('focused'); next.scrollIntoView({ block: 'nearest' }); }
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (focused) focused.classList.remove('focused');
                const prev = items[idx - 1] || items[items.length - 1];
                if (prev) { prev.classList.add('focused'); prev.scrollIntoView({ block: 'nearest' }); }
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (focused) { focused.click(); return; }
                const query = normalizeSearchQuery(input.value);
                if (query.length >= 2) {
                    input.value = query;
                    closeAllSuggestions();
                    searchParts(query);
                    navigateTo('products');
                    syncSearchInputs(query, id);
                }
            } else if (e.key === 'Escape') {
                closeAllSuggestions();
                input.blur();
            }
        });

        input.addEventListener('focus', () => {
            updateClearBtn();
            if (input.value.length >= 2) handleSearchInput({ target: input }, suggestionsId);
        });

        input.addEventListener('blur', () => {
            setTimeout(() => closeAllSuggestions(), 200);
        });
    });

    // Filters
    document.getElementById('brandSelect').addEventListener('change', handleBrandChange);
    document.getElementById('modelSelect').addEventListener('change', handleModelChange);
    document.getElementById('yearSelect').addEventListener('change', handleYearChange);
    document.getElementById('categorySelect').addEventListener('change', handleCategoryChange);
    document.getElementById('applyFilters').addEventListener('click', applyFilters);
    document.getElementById('clearFilters').addEventListener('click', clearFilters);

    // Header Navigation
    document.querySelectorAll('.header-nav-item').forEach(item => {
        item.addEventListener('click', () => {
            const page = item.dataset.page;
            navigateTo(page);
            document.querySelectorAll('.header-nav-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });

    // Checkout
    document.getElementById('checkoutBtn').addEventListener('click', () => navigateTo('checkout'));
    document.getElementById('checkoutForm').addEventListener('submit', handleCheckout);
}

function closeAllSuggestions() {
    document.querySelectorAll('.search-suggestions').forEach(el => el.classList.remove('show'));
}

// Normalize search query: collapse spaces, trim, fix common patterns
function normalizeSearchQuery(raw) {
    return raw
        .trim()
        .replace(/\s+/g, ' ')          // collapse multiple spaces
        .replace(/[^\w\s\-]/g, ' ')    // strip special chars except hyphen
        .replace(/\s+/g, ' ')
        .trim();
}

function syncSearchInputs(query, sourceId) {
    const clearMap = { 'searchInput': 'searchClear' };
    ['searchInput'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = query;
        const cb = document.getElementById(clearMap[id]);
        if (cb) cb.style.display = query.length > 0 ? 'flex' : 'none';
    });
}

// Position the fixed dropdown below the input
function positionSuggestions(input, container) {
    const rect = input.getBoundingClientRect();
    container.style.top  = (rect.bottom + 6) + 'px';
    container.style.left = rect.left + 'px';
    container.style.width = Math.max(rect.width, 300) + 'px';
    container.style.maxWidth = '480px';
}

async function handleSearchInput(e, suggestionsId) {
    const input = e.target;
    const query = normalizeSearchQuery(input.value);
    const container = document.getElementById(suggestionsId);

    if (query.length < 2) {
        container.classList.remove('show');
        return;
    }

    positionSuggestions(input, container);

    try {
        const res = await fetch(`${API_URL}/suggestions?q=${encodeURIComponent(query)}&rich=1`);
        const data = await res.json();
        displaySuggestions(data, query, container, input);
    } catch (err) {
        // silent fail
    }
}

function highlightMatch(text, query) {
    if (!query) return text;
    const words = query.trim().split(/\s+/).filter(Boolean);
    let result = text;
    words.forEach(word => {
        const re = new RegExp(`(${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
        result = result.replace(re, '<mark>$1</mark>');
    });
    return result;
}

function displaySuggestions(suggestions, query, container, input) {
    container.innerHTML = '';

    if (!suggestions || suggestions.length === 0) {
        container.classList.remove('show');
        return;
    }

    // Group by type
    const parts = suggestions.filter(s => s.type === 'part' || typeof s === 'string');
    const brands = suggestions.filter(s => s.type === 'brand');
    const cats   = suggestions.filter(s => s.type === 'category');

    // Normalise plain strings from old API
    const normalised = suggestions.map(s =>
        typeof s === 'string' ? { type: 'part', label: s, sub: '' } : s
    );

    if (normalised.length) {
        const hdr = document.createElement('div');
        hdr.className = 'suggestions-header';
        hdr.textContent = 'Suggestions';
        container.appendChild(hdr);
    }

    const icons = { part: '🔩', brand: '🏍️', category: '📦' };

    normalised.slice(0, 8).forEach(s => {
        const item = document.createElement('div');
        item.className = 'suggestion-item';

        const typeKey = s.type || 'part';
        const label = s.label || s;
        const sub   = s.sub   || '';

        item.innerHTML = `
            <div class="suggestion-icon">${icons[typeKey] || '🔩'}</div>
            <div class="suggestion-text">
                <div class="suggestion-main">${highlightMatch(label, query)}</div>
                ${sub ? `<div class="suggestion-sub">${sub}</div>` : ''}
            </div>
            <span class="suggestion-type ${typeKey === 'category' ? 'cat' : typeKey}">${typeKey}</span>`;

        item.addEventListener('mousedown', (e) => {
            e.preventDefault();
            // Build a rich query: if it's a part suggestion with a bike sub-label,
            // search "Bajaj Pulsar 150 Full Body" not just "Full Body"
            const searchQuery = (typeKey === 'part' && sub) ? `${sub} ${label}` : label;
            input.value = searchQuery;
            syncSearchInputs(searchQuery, input.id);
            closeAllSuggestions();
            searchParts(searchQuery);
            navigateTo('products');
        });

        container.appendChild(item);
    });

    // "Search for X" footer
    const searchAll = document.createElement('div');
    searchAll.className = 'suggestion-search-all';
    searchAll.innerHTML = `<span>🔍</span> Search for "<strong>${query}</strong>"`;
    searchAll.addEventListener('mousedown', (e) => {
        e.preventDefault();
        input.value = query;
        syncSearchInputs(query, input.id);
        closeAllSuggestions();
        searchParts(query);
        navigateTo('products');
    });
    container.appendChild(searchAll);

    positionSuggestions(input, container);
    container.classList.add('show');
}

// API Calls
async function loadBrands() {
    const response = await fetch(`${API_URL}/brands`);
    const brands = await response.json();
    const select = document.getElementById('brandSelect');
    brands.forEach(brand => {
        const option = document.createElement('option');
        option.value = brand;
        option.textContent = brand;
        select.appendChild(option);
    });
}

async function loadModels(brand) {
    const response = await fetch(`${API_URL}/models/${brand}`);
    const models = await response.json();
    const select = document.getElementById('modelSelect');
    select.innerHTML = '<option value="">Select Model</option>';
    models.forEach(model => {
        const option = document.createElement('option');
        option.value = model;
        option.textContent = model;
        select.appendChild(option);
    });
    select.disabled = false;
}

async function loadYears(brand, model) {
    try {
        const response = await fetch(`${API_URL}/years/${brand}/${model}`);
        const years = await response.json();
        const select = document.getElementById('yearSelect');
        select.innerHTML = '<option value="">Select Year</option>';
        
 // Debug log
        
        // Always add "Any Year" option first
        const anyYearOption = document.createElement('option');
        anyYearOption.value = 'Any';
        anyYearOption.textContent = 'Any Year';
        select.appendChild(anyYearOption);
        
        if (years && years.length > 0) {
            // Add each individual year
            years.forEach(yearObj => {
                const year = yearObj.year;
                if (year) {
                    const option = document.createElement('option');
                    option.value = year;
                    option.textContent = year;
                    select.appendChild(option);
                }
            });
            
 // Debug log
        }
        
        // Always enable year select
        select.disabled = false;
 // Debug log
        
        // Auto-load categories
        await loadCategories(brand, model);
        
    } catch (error) {
        console.error('Error loading years:', error);
        // On error, still provide "Any Year" option
        const select = document.getElementById('yearSelect');
        select.innerHTML = '<option value="">Select Year</option>';
        const anyYearOption = document.createElement('option');
        anyYearOption.value = 'Any';
        anyYearOption.textContent = 'Any Year';
        select.appendChild(anyYearOption);
        select.disabled = false;
        await loadCategories(brand, model);
    }
}

async function loadCategories(brand, model) {
    const response = await fetch(`${API_URL}/categories/${brand}/${model}`);
    const categories = await response.json();
    const select = document.getElementById('categorySelect');
    select.innerHTML = '<option value="">All Categories</option>';
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        select.appendChild(option);
    });
    select.disabled = false;
    document.getElementById('applyFilters').disabled = false;
}

async function loadParts(filters) {
    showLoading();
    const params = new URLSearchParams(filters);
    const response = await fetch(`${API_URL}/parts?${params}`);
    const parts = await response.json();
    displayProducts(parts);
    hideLoading();
}

async function searchParts(query) {
    if (!query) return;
    const q = normalizeSearchQuery(query);
    if (!q) return;
    showLoading();
    const response = await fetch(`${API_URL}/search?q=${encodeURIComponent(q)}`);
    const parts = await response.json();
    displayProducts(parts);
    hideLoading();
}

// Event Handlers
async function handleBrandChange(e) {
    const brand = e.target.value;
    if (brand) {
        currentFilters.brand = brand;
        await loadModels(brand);
        document.getElementById('yearSelect').disabled = true;
        document.getElementById('categorySelect').disabled = true;
        document.getElementById('applyFilters').disabled = true;
    }
}

async function handleModelChange(e) {
    const model = e.target.value;
    if (model) {
        currentFilters.model = model;
        await loadYears(currentFilters.brand, model);
    }
}

async function handleYearChange(e) {
    const year = e.target.value;
 // Debug log
    
    // If user selected the placeholder "Select Year", don't proceed
    if (!year || year === '') {
        document.getElementById('applyFilters').disabled = true;
        return;
    }
    
    // Valid year selected (including "Any")
    currentFilters.year = year;
    // Categories are already loaded, just enable the apply button
    document.getElementById('applyFilters').disabled = false;
 // Debug log
}

function handleCategoryChange(e) {
    currentFilters.category = e.target.value;
}

async function applyFilters() {
    await loadParts(currentFilters);
    navigateTo('products');
}

function clearFilters() {
    currentFilters = {};
    document.getElementById('brandSelect').value = '';
    document.getElementById('modelSelect').innerHTML = '<option value="">Select Model</option>';
    document.getElementById('yearSelect').innerHTML = '<option value="">Select Year</option>';
    document.getElementById('categorySelect').innerHTML = '<option value="">Select Category</option>';
    document.getElementById('modelSelect').disabled = true;
    document.getElementById('yearSelect').disabled = true;
    document.getElementById('categorySelect').disabled = true;
    document.getElementById('applyFilters').disabled = true;
    navigateTo('home');
}

async function handleSearch(e) {
    const query = e.target.value.trim();
    if (query.length >= 3) {
        await searchParts(query);
        navigateTo('products');
    }
}

function displayProducts(products) {
    const grid = document.getElementById('productsGrid');
    grid.innerHTML = '';
    
    if (products.length === 0) {
        grid.innerHTML = '<div class="empty-state"><p>No products found</p></div>';
        return;
    }
    
    // Cache all products in memory
    products.forEach(p => { _productCache[String(p.id)] = p; });
    
    products.forEach(product => {
        const card = createProductCard(product);
        grid.appendChild(card);
    });
}

// Route Supabase Storage image URLs through the backend proxy cache
function _imgUrl(url) {
    if (!url) return '/placeholder.svg';
    // Only proxy Supabase Storage URLs — leave everything else as-is
    if (url.includes('supabase.co/storage')) {
        return `/api/img?u=${encodeURIComponent(url)}`;
    }
    return url;
}

// Update meta tags for better sharing on social media
function updateMetaTags(product) {
    const title = `${product.part_name} - ${product.bike_brand} ${product.bike_model} | Lakshmi Motorcycle Spares`;
    const description = product.description || `Buy ${product.part_name} for ${product.bike_brand} ${product.bike_model}. Price: ₹${product.price}. Quality parts, trusted service.`;
    const imageUrl = _imgUrl(product.web_image_url);
    const url = `${location.origin}${location.pathname}?product=${product.id}`;
    
    // Update page title
    document.title = title;
    
    // Update or create meta tags
    const updateMeta = (property, content) => {
        const attribute = property.startsWith('twitter:') ? 'name' : 'property';
        let meta = document.querySelector(`meta[${attribute}="${property}"]`);
        if (!meta) {
            meta = document.createElement('meta');
            meta.setAttribute(attribute, property);
            document.head.appendChild(meta);
        }
        meta.setAttribute('content', content);
    };
    
    // Open Graph tags
    updateMeta('og:title', title);
    updateMeta('og:description', description);
    updateMeta('og:image', imageUrl);
    updateMeta('og:url', url);
    
    // Twitter tags
    updateMeta('twitter:title', title);
    updateMeta('twitter:description', description);
    updateMeta('twitter:image', imageUrl);
    updateMeta('twitter:url', url);
}

// Reset meta tags to default when going back to home
function resetMetaTags() {
    const title = 'Lakshmi Motorcycle Spares - Quality Parts, Trusted Service';
    const description = 'Find motorcycle and scooter spares by brand, model and year. Browse parts and contact our team for help.';
    const url = `${location.origin}${location.pathname}`;
    document.title = title;
    
    const updateMeta = (property, content) => {
        const attribute = property.startsWith('twitter:') ? 'name' : 'property';
        let meta = document.querySelector(`meta[${attribute}="${property}"]`);
        if (!meta) {
            meta = document.createElement('meta');
            meta.setAttribute(attribute, property);
            document.head.appendChild(meta);
        }
        meta.setAttribute('content', content);
    };
    
    updateMeta('og:title', title);
    updateMeta('og:description', description);
    updateMeta('og:url', url);
    updateMeta('twitter:title', title);
    updateMeta('twitter:description', description);
    updateMeta('twitter:url', url);
    document.querySelector('meta[property="og:image"]')?.remove();
    document.querySelector('meta[name="twitter:image"]')?.remove();
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const imageUrl = _imgUrl(product.web_image_url);
    const inStock = product.stock_qty == null || product.stock_qty > 0;
    
    card.innerHTML = `
        <img loading="lazy" src="${imageUrl}" alt="${product.part_name}" class="product-image" onerror="this.src='/placeholder.svg'">
        <div class="product-info">
            <div class="product-name">${product.part_name}</div>
            <div class="product-brand">${product.bike_brand} ${product.bike_model}</div>
            <div class="product-price">₹${product.price}</div>
            <div class="product-stock ${inStock ? '' : 'out-of-stock'}">
                ${inStock ? (product.stock_qty != null ? `In Stock (${product.stock_qty})` : 'In Stock') : 'Out of Stock'}
            </div>
            ${inStock ? `<button class="btn-add-cart" data-product-id="${product.id}">Add to Cart</button>` : ''}
        </div>
    `;
    
    card.addEventListener('click', (e) => {
        if (!e.target.classList.contains('btn-add-cart')) {
            openProductDetails(product.id);
        }
    });
    
    const addToCartBtn = card.querySelector('.btn-add-cart');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            addToCart(product.id, product); // pass data directly — no API call
        });
    }
    
    return card;
}

// Cart Functions
// In-memory product cache to avoid re-fetching on addToCart
const _productCache = {};

function addToCart(productId, productData) {
    // If product data is passed directly (from card), use it — no API call needed
    if (productData) {
        _doAddToCart(productData);
        return;
    }
    // Fallback: check memory cache first
    if (_productCache[productId]) {
        _doAddToCart(_productCache[productId]);
        return;
    }
    // Last resort: fetch from API
    fetch(`${API_URL}/part/${productId}`)
        .then(res => res.json())
        .then(product => {
            _productCache[productId] = product;
            _doAddToCart(product);
        })
        .catch(() => {});
}

function _doAddToCart(product) {
    const productId = String(product.id);
    const existingItem = cart.find(item => String(item.part_id) === productId);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            part_id: productId,
            part_name: product.part_name,
            bike_brand: product.bike_brand,
            bike_model: product.bike_model,
            year: product.year || 'Any',
            price: parseFloat(product.price),
            color: product.color,
            image_url: product.web_image_url || null,
            quantity: 1
        });
    }
    saveCart();
    updateCartBadge();
    // Visual feedback
    const buttons = document.querySelectorAll(`[data-product-id="${productId}"]`);
    buttons.forEach(btn => {
        const orig = btn.textContent;
        btn.textContent = '✓ Added!';
        btn.style.background = '#28a745';
        setTimeout(() => { btn.textContent = orig; btn.style.background = ''; }, 1500);
    });
}

function updateQuantity(index, change) {
    cart[index].quantity += change;
    if (cart[index].quantity <= 0) {
        cart.splice(index, 1);
    }
    saveCart();
    displayCart();
    updateCartBadge();
}

function removeFromCart(index) {
    cart.splice(index, 1);
    saveCart();
    displayCart();
    updateCartBadge();
}

function displayCart() {
    const container = document.getElementById('cartItems');
    container.innerHTML = '';
    
    if (cart.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>Your cart is empty</p></div>';
        document.getElementById('checkoutBtn').disabled = true;
        return;
    }
    
    document.getElementById('checkoutBtn').disabled = false;
    
    cart.forEach((item, index) => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <img src="${_imgUrl(item.image_url)}" class="cart-item-image" onerror="this.src='/placeholder.svg'">
            <div class="cart-item-details">
                <div class="cart-item-name">${item.part_name}</div>
                <div class="cart-item-brand">${item.bike_brand} ${item.bike_model}</div>
                ${item.color ? `<div class="cart-item-brand">Color: ${item.color}</div>` : ''}
                <div class="cart-item-price">₹${item.price}</div>
                <div class="cart-item-actions">
                    <button class="qty-btn" onclick="updateQuantity(${index}, -1)">-</button>
                    <span class="qty-display">${item.quantity}</span>
                    <button class="qty-btn" onclick="updateQuantity(${index}, 1)">+</button>
                    <button class="btn-remove" onclick="removeFromCart(${index})">Remove</button>
                </div>
            </div>
        `;
        container.appendChild(cartItem);
    });
    
    updateCartSummary();
}

// Build bike-grouped order summary HTML
function _buildBikeGroupedHTML(cartItems) {
    const groups = {};
    cartItems.forEach(item => {
        const key = `${item.bike_brand} ${item.bike_model} ${item.year || 'Any'}`;
        if (!groups[key]) groups[key] = [];
        groups[key].push(item);
    });
    let html = '';
    Object.entries(groups).forEach(([bikeKey, items]) => {
        html += `<div style="margin-bottom:4px;font-size:12px;font-weight:700;color:#FF6700;border-bottom:1px solid rgba(255,103,0,0.3);padding-bottom:3px;">🏍 ${bikeKey}</div>`;
        items.forEach(item => {
            html += `<div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px;padding-left:8px;">
                <span>${item.part_name}${item.color ? ' <span style="color:#aaa;font-size:11px;">('+item.color+')</span>' : ''} ×${item.quantity}</span>
                <span>₹${(item.price * item.quantity).toFixed(2)}</span>
            </div>`;
        });
    });
    return html;
}

function updateCartSummary() {
    // If cart is empty, reset all amounts to 0
    if (cart.length === 0) {
        document.getElementById('cartSubtotal').textContent = '₹0.00';
        document.getElementById('cartDelivery') && (document.getElementById('cartDelivery').textContent = '₹200.00');
        document.getElementById('cartTotal').textContent = '₹0.00';
        document.getElementById('checkoutTotal').textContent = '₹0.00';
        const checkoutItems = document.getElementById('checkoutItems');
        if (checkoutItems) {
            checkoutItems.innerHTML = '';
        }
        return;
    }
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const delivery = 200;
    document.getElementById('cartSubtotal').textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById('cartDelivery') && (document.getElementById('cartDelivery').textContent = `₹${delivery.toFixed(2)}`);
    document.getElementById('cartTotal').textContent = `₹${(subtotal + delivery).toFixed(2)}`;
    document.getElementById('checkoutTotal').textContent = `₹${(subtotal + delivery).toFixed(2)}`;
    
    const checkoutItems = document.getElementById('checkoutItems');
    if (checkoutItems) {
        checkoutItems.innerHTML = _buildBikeGroupedHTML(cart);
    }
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateCartBadge() {
    const badge = document.getElementById('cartBadge');
    const headerBadge = document.getElementById('headerCartBadge');
    const floatingCount = document.getElementById('floatingCartCount');
    const sbBadge = document.getElementById('sbCartBadge');
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'block' : 'none';
    }
    if (headerBadge) {
        headerBadge.textContent = count;
        headerBadge.style.display = count > 0 ? 'block' : 'none';
    }
    if (floatingCount) {
        floatingCount.textContent = count;
        floatingCount.style.display = count > 0 ? 'block' : 'none';
    }
    if (sbBadge) {
        sbBadge.textContent = count;
        sbBadge.style.display = count > 0 ? 'inline' : 'none';
    }
}

// Checkout
let pendingOrderData = null;

async function handleCheckout(e) {
    e.preventDefault();
    const checkoutForm = document.getElementById('checkoutForm');
    if (!checkoutForm.reportValidity()) return;
    
    // Store order data for payment
    pendingOrderData = {
        user_id: tg.initDataUnsafe?.user?.id || 0,
        user_name: document.getElementById('customerName').value,
        phone: document.getElementById('customerPhone').value,
        email: document.getElementById('customerEmail').value.trim(),
        address: document.getElementById('customerAddress').value,
        cart_items: cart
    };

    pendingOrderData.delivery_charge = await resolveDeliveryCharge(pendingOrderData.address);
    
    // Navigate to payment page
    displayPaymentPage();
    navigateTo('payment');
}

async function resolveDeliveryCharge(address) {
    const pincode = String(address || '').match(/\b([1-9][0-9]{5})\b/)?.[1];
    if (pincode) {
        try {
            const response = await fetch(`${API_URL}/delivery/check?pincode=${pincode}`);
            if (response.ok) {
                const result = await response.json();
                if (result.available && result.zone?.delivery_charge != null) {
                    return Number(result.zone.delivery_charge);
                }
            }
        } catch (error) {
            console.warn('Delivery-zone check failed; using the configured fallback fee.', error);
        }
    }
    return DELIVERY_CHARGE;
}

function displayPaymentPage() {
    const paymentItems = document.getElementById('paymentItems');
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const deliveryCharge = Number(pendingOrderData?.delivery_charge ?? DELIVERY_CHARGE);
    const platformFee = Math.round(subtotal * 0.01 * 100) / 100; // 1% on subtotal
    const total = subtotal + deliveryCharge + platformFee;
    
    paymentItems.innerHTML = _buildBikeGroupedHTML(cart) + `
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.1);">
            <span>Subtotal</span>
            <span>₹${subtotal.toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px;">
            <span>Delivery Charge</span>
            <span>₹${deliveryCharge.toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; color: rgba(255,255,255,0.6);">
            <span>Platform Fee (1% on card/online)</span>
            <span>₹${platformFee.toFixed(2)}</span>
        </div>
    `;
    
    document.getElementById('paymentTotal').textContent = `₹${total.toFixed(2)}`;
}

async function initiatePayment() {
    if (!pendingOrderData) {
        (tg?.showAlert || alert)('Order data not found. Please try again.');
        return;
    }
    
    if (!RAZORPAY_KEY) {
        (tg?.showAlert || alert)('Payment system not configured. Please contact support.');
        return;
    }
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const deliveryCharge = Number(pendingOrderData.delivery_charge ?? DELIVERY_CHARGE);
    const platformFee = Math.round(subtotal * 0.01 * 100) / 100; // 1% platform fee for Razorpay
    const total = subtotal + deliveryCharge + platformFee;
    
    const options = {
        key: RAZORPAY_KEY,
        amount: Math.round(total * 100), // Amount in paise (includes 1% platform fee)
        currency: 'INR',
        name: 'Lakshmi Motorcycles',
        description: `Order for ${cart.length} item(s)`,
        handler: async function (response) {
            await completeOrder(response.razorpay_payment_id);
        },
        prefill: {
            name: pendingOrderData.user_name,
            contact: pendingOrderData.phone,
            email: pendingOrderData.email
        },
        notes: {
            order_type: 'spare_parts',
            customer_name: pendingOrderData.user_name
        },
        theme: {
            color: '#FF3B30',
            backdrop_color: 'rgba(0,0,0,0.8)'
        },
        modal: {
            ondismiss: function() {
                (tg?.showAlert || alert)('Payment cancelled');
            },
            escape: true,
            backdropclose: false
        },
        config: {
            display: {
                blocks: {
                    banks: {
                        name: 'All payment methods',
                        instruments: [
                            {
                                method: 'upi'
                            },
                            {
                                method: 'card'
                            },
                            {
                                method: 'netbanking'
                            },
                            {
                                method: 'wallet'
                            }
                        ]
                    }
                },
                sequence: ['block.banks'],
                preferences: {
                    show_default_blocks: false
                }
            }
        },
        retry: {
            enabled: true,
            max_count: 3
        },
        timeout: 300, // 5 minutes
        remember_customer: false
    };
    
    const razorpay = new Razorpay(options);
    razorpay.open();
}

async function completeOrder(paymentId) {
    showLoading();
    
    try {
        const response = await fetch(`${API_URL}/order`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ...pendingOrderData,
                payment_id: paymentId,
                payment_method: 'razorpay',
                payment_status: 'paid'
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Clear cart
            localStorage.setItem("order_id", result.order_id);
            localStorage.setItem("customer_phone", pendingOrderData.phone);

            cart = [];
            saveCart();
            updateCartBadge();
            
            // Show confirmation
            document.getElementById('confirmedOrderId').textContent = result.order_id;
            navigateTo('confirmation');
            
            // Clear pending order data
            pendingOrderData = null;
        } else {
            (tg?.showAlert || alert)('Order failed. Please contact support.');
        }
    } catch (error) {
        console.error('Order error:', error);
        (tg?.showAlert || alert)('Order failed. Please try again.');
    } finally {
        hideLoading();
    }
}

// Navigation
function navigateTo(page, addToHistory = true) {
    // Add current page to history before navigating (if not already there)
    const currentPage = getCurrentPage();
    if (addToHistory && currentPage && currentPage !== page) {
        navigationHistory.push(currentPage);
 // Debug
    }
    
    // Reset meta tags when going back to home
    if (page === 'home') {
        resetMetaTags();
    }
    
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });
    
    document.getElementById('filterSection').style.display = page === 'home' ? 'flex' : 'none';
    document.getElementById('productsSection').style.display = page === 'products' ? 'block' : 'none';
    document.getElementById('cartSection').style.display = page === 'cart' ? 'block' : 'none';
    document.getElementById('checkoutSection').style.display = page === 'checkout' ? 'block' : 'none';
    document.getElementById('paymentSection').style.display = page === 'payment' ? 'block' : 'none';
    document.getElementById('confirmationSection').style.display = page === 'confirmation' ? 'block' : 'none';
    document.getElementById('helpSection').style.display = page === 'help' ? 'block' : 'none';
    document.getElementById('productDetailSection').style.display = page === 'product-detail' ? 'block' : 'none';
    document.getElementById('ordersSection').style.display = page === 'orders' ? 'block' : 'none';
    document.getElementById('orderDetailSection').style.display = page === 'order-detail' ? 'block' : 'none';
    
    // Scroll to top when navigating to a new page (instant, no animation)
    window.scrollTo(0, 0);
    
    if (page === 'cart') {
        displayCart();
    } else if (page === 'orders') {
        loadOrders();
    }
}

function getCurrentPage() {
    // Find which page is currently visible
    if (document.getElementById('filterSection').style.display !== 'none') return 'home';
    if (document.getElementById('productsSection').style.display !== 'none') return 'products';
    if (document.getElementById('cartSection').style.display !== 'none') return 'cart';
    if (document.getElementById('checkoutSection').style.display !== 'none') return 'checkout';
    if (document.getElementById('paymentSection').style.display !== 'none') return 'payment';
    if (document.getElementById('confirmationSection').style.display !== 'none') return 'confirmation';
    if (document.getElementById('helpSection').style.display !== 'none') return 'help';
    if (document.getElementById('productDetailSection').style.display !== 'none') return 'product-detail';
    if (document.getElementById('ordersSection').style.display !== 'none') return 'orders';
    if (document.getElementById('orderDetailSection').style.display !== 'none') return 'order-detail';
    return 'home'; // Default
}

function goBack() {
    if (navigationHistory.length > 0) {
        const previousPage = navigationHistory.pop();
 // Debug
        navigateTo(previousPage, false); // Don't add to history when going back
    } else {
        // No history, go to home
        navigateTo('home', false);
    }
}

// Product Details
async function openProductDetails(productId) {
    showLoading();
    try {
        // Use cache if available
        let product = _productCache[String(productId)];
        if (!product) {
            const response = await fetch(`${API_URL}/part/${productId}`);
            product = await response.json();
            _productCache[String(productId)] = product;
        }
        displayProductDetails(product); // not awaited — recommendations load async
        navigateTo('product-detail');
        history.pushState({ productId }, '', `#product-${productId}`);
        window.scrollTo(0, 0);
    } catch (error) {
        console.error('Error loading product:', error);
    } finally {
        hideLoading();
    }
}

async function displayProductDetails(product) {
    const section = document.getElementById('productDetailSection');
    const imageUrl = _imgUrl(product.web_image_url);
    const inStock = product.stock_qty == null || product.stock_qty > 0;
    const partName = product.part_name || 'Motorcycle spare part';
    const brand = product.bike_brand || '';
    const model = product.bike_model || '';
    const category = product.part_category || 'Motorcycle spare part';
    const price = Number(product.price);
    const displayPrice = Number.isFinite(price) ? price.toLocaleString('en-IN') : (product.price || '—');
    const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
    const fitment = [brand, model].filter(Boolean).join(' ');
    
    // Update meta tags for sharing
    updateMetaTags(product);
    
    // Build compact specs for inline display
    const specs = [];
    if (product.color) {
        specs.push(`Color: ${product.color}`);
    }
    
    section.innerHTML = `
        <div class="product-detail-page">
          <div class="product-detail-toolbar">
            <button class="product-back-button" onclick="goBack()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="20" height="20">
                    <path d="M19 12H5M12 19l-7-7 7-7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span>Back to parts</span>
            </button>
            <div class="product-detail-breadcrumb" aria-label="Product location">
              <span>Spare parts</span><span aria-hidden="true">›</span>
              <span>${escapeHtml(fitment || 'Motorcycle parts')}</span>
            </div>
            <button class="product-share-button" type="button" data-product-share>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="17" height="17" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.7 6.6-4.4M8.7 13.3l6.6 4.4" stroke-width="2" stroke-linecap="round"/></svg>
                <span>Share</span>
            </button>
          </div>

          <article class="product-detail-container">
            <div class="product-detail-gallery">
              <div class="product-detail-image-container">
                <img loading="lazy" src="${escapeHtml(imageUrl)}" alt="${escapeHtml(partName)}" class="product-detail-image" onerror="this.src='/placeholder.svg'">
              </div>
            </div>

            <div class="product-detail-info">
              <div class="product-detail-kicker">${escapeHtml(category)}</div>
              <h1 class="product-detail-title">${escapeHtml(partName)}</h1>
              ${fitment ? `<p class="product-detail-fitment">Fits <strong>${escapeHtml(fitment)}</strong>${product.year_from ? ` <span>·</span> ${escapeHtml(product.year_from)}${product.year_to ? `–${escapeHtml(product.year_to)}` : '+'}` : ''}</p>` : ''}

              <div class="product-detail-purchase-row">
                <div class="product-detail-price">₹${escapeHtml(displayPrice)}</div>
                ${inStock ? `<span class="product-detail-stock"><span aria-hidden="true">✓</span> In stock</span>` : `<span class="product-detail-stock is-out"><span aria-hidden="true">•</span> Out of stock</span>`}
              </div>

              ${specs.length ? `<div class="product-detail-specs">${specs.map((spec) => `<span class="product-detail-spec">${escapeHtml(spec)}</span>`).join('')}</div>` : ''}

              ${product.description ? `
                <div class="product-detail-description">
                  <h2>Product details</h2>
                  <p>${escapeHtml(product.description)}</p>
                </div>
              ` : ''}

              <div class="product-detail-actions">
                ${inStock ? `
                  <button class="btn-primary btn-large product-detail-add-button" type="button" data-product-add>
                    <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20" aria-hidden="true"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-1.99.9-1.99 2S15.9 22 17 22s2-.9 2-2-.9-2-2-2zM7.17 14h9.91c.75 0 1.4-.41 1.75-1.03l3.86-7.01A1 1 0 0 0 21.81 4H5.21L4.27 2H1v2h2l3.6 7.59-1.35 2.45C4.52 15.37 5.48 17 7 17h12v-2H7l.17-1zM6.16 6h13.96l-3.04 5.5H8.77L6.16 6z"/></svg>
                    Add to cart
                  </button>
                ` : '<button class="btn-primary btn-large product-detail-add-button" type="button" disabled>Currently unavailable</button>'}
                <p class="product-detail-help">Need help confirming fitment? <a href="tel:+919160201088">Call +91 91602 01088</a></p>
              </div>
            </div>
          </article>
        </div>
        
        <div class="recommendations-section product-recommendations">
            <div class="product-recommendations-heading"><h2 class="section-title">You may also like</h2><p>More parts for your bike</p></div>
            <div id="recommendationsGrid" class="products-grid"></div>
        </div>
    `;

    section.querySelector('[data-product-share]')?.addEventListener('click', () => {
        shareProduct(product.id, `${partName} — ${fitment}`);
    });
    section.querySelector('[data-product-add]')?.addEventListener('click', (clickEvent) => {
        addToCartFromDetail(product.id, clickEvent);
    });
    
    // Load recommendations async — don't block page render
    loadRecommendations(product.bike_brand, product.bike_model, product.id);
}

async function loadRecommendations(brand, model, currentProductId) {
    try {
        const response = await fetch(`${API_URL}/recommendations/${brand}/${model}/${currentProductId}`);
        const parts = await response.json();
        
        // Filter out current product and limit to 6 items
        const recommendations = parts
            .filter(p => p.id !== currentProductId)
            .slice(0, 6);
        
        const grid = document.getElementById('recommendationsGrid');
        grid.innerHTML = '';
        
        if (recommendations.length === 0) {
            grid.innerHTML = '<p style="text-align: center; color: #666;">No recommendations available</p>';
            return;
        }
        
        recommendations.forEach(product => {
            const card = createProductCard(product);
            grid.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading recommendations:', error);
    }
}

function addToCartFromDetail(productId, clickEvent) {
    const product = _productCache[String(productId)];
    addToCart(productId, product || null);
    const btn = clickEvent?.currentTarget;
    if (btn) {
        const orig = btn.innerHTML;
        btn.innerHTML = '✓ Added to Cart!';
        btn.style.background = '#28a745';
        setTimeout(() => { btn.innerHTML = orig; btn.style.background = ''; }, 2000);
    }
}

// Utilities
function showLoading() {
    document.getElementById('loadingOverlay').classList.add('show');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.remove('show');
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}


// Orders Functions
async function loadOrders() {

    const phone = localStorage.getItem("customer_phone");
    const orderId = localStorage.getItem("order_id");


    const container = document.getElementById("ordersContainer");

    // If no order stored yet
    if (!phone || !orderId) {
        container.innerHTML = `
            <div class="empty-state">
                <p>No orders yet</p>
                <p style="font-size:14px;color:#888">
                Place an order to see it here
                </p>
            </div>
        `;
        return;
    }

    showLoading();

    try {

        const response = await fetch(`${API_URL}/orders?phone=${phone}&order_id=${orderId}`);

        const data = await response.json();

        if (!Array.isArray(data)) {
            container.innerHTML = `
                <div class="empty-state">
                    <p>No orders found</p>
                </div>
            `;
            return;
        }

        displayOrders(data);

    } catch (error) {

        console.error("Error loading orders:", error);

        container.innerHTML = `
            <div class="empty-state">
                <p>Failed to load orders</p>
            </div>
        `;

    } finally {
        hideLoading();
    }
}

// Orders cache — populated when orders list is loaded
let _ordersCache = {};

function displayOrders(orders) {
    const container = document.getElementById('ordersContainer');
    
    if (!orders || orders.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="currentColor" width="64" height="64" style="color: #ccc; margin-bottom: 16px;">
                    <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                </svg>
                <p>No orders yet</p>
                <p style="font-size: 14px; color: #666;">Start shopping to see your orders here!</p>
            </div>
        `;
        return;
    }
    
    // Cache orders by ID for instant detail view
    _ordersCache = {};
    orders.forEach(o => { _ordersCache[o.order_id] = o; });
    
    container.innerHTML = orders.map(order => createOrderCard(order)).join('');
}

function createOrderCard(order) {
    const orderDate = new Date(order.created_at).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
    
    const statusColors = {
        'Pending': '#ff9800',
        'Confirmed': '#2196f3',
        'Shipped': '#9c27b0',
        'Delivered': '#4caf50',
        'Cancelled': '#f44336'
    };
    
    const statusColor = statusColors[order.status] || '#666';
    
    // Format payment method
    const paymentMethodDisplay = {
        'razorpay': 'Razorpay',
        'cod': 'Cash on Delivery',
        'upi': 'UPI',
        'card': 'Card',
        'netbanking': 'Net Banking'
    };
    const paymentMethod = paymentMethodDisplay[order.payment_method] || order.payment_method || 'COD';
    
    // Format payment status
    const paymentStatusDisplay = {
        'paid': 'Paid',
        'pending': 'Pending',
        'failed': 'Failed',
        'refunded': 'Refunded'
    };
    const paymentStatus = paymentStatusDisplay[order.payment_status] || order.payment_status || 'Pending';
    
    const paymentStatusColor = order.payment_status === 'paid' ? '#4caf50' : '#ff9800';
    
    const items = order.items || [];
    const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
    
    return `
        <div class="order-card" onclick="viewOrderDetails('${order.order_id}')" style="cursor: pointer;">
            <div class="order-header">
                <div>
                    <div class="order-id">Order #${order.order_id}</div>
                    <div class="order-date">${orderDate}</div>
                </div>
                <div class="order-status" style="background: ${statusColor}20; color: ${statusColor};">
                    ${order.status}
                </div>
            </div>
            <div class="order-items">
                ${items.slice(0, 3).map(item => `
                    <div class="order-item">
                        <span>${item.part_name}</span>
                        <span>×${item.quantity}</span>
                    </div>
                `).join('')}
                ${items.length > 3 ? `<div class="order-item-more">+${items.length - 3} more items</div>` : ''}
            </div>
            
            <div class="order-payment-info">
                <div class="payment-info-item">
                    <span style="color: rgba(255,255,255,0.6); font-size: 12px;">Payment:</span>
                    <span style="font-size: 13px; font-weight: 600;">${paymentMethod}</span>
                </div>
                <div class="payment-info-item">
                    <span style="color: rgba(255,255,255,0.6); font-size: 12px;">Status:</span>
                    <span style="font-size: 13px; font-weight: 600; color: ${paymentStatusColor};">${paymentStatus}</span>
                </div>
            </div>
            
            <div class="order-footer">
                <div class="order-total">
                    <span>${itemCount} item${itemCount > 1 ? 's' : ''}</span>
                    <span class="order-amount">₹${parseFloat(order.total_amount).toFixed(2)}</span>
                </div>
                <div style="color: rgba(255,255,255,0.5); font-size: 13px; display: flex; align-items: center; gap: 4px;">
                    <span>Tap to view details</span>
                    <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
                        <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/>
                    </svg>
                </div>
            </div>
        </div>
    `;
}

// Make viewOrderDetails globally accessible
window.viewOrderDetails = viewOrderDetails;

function viewOrderDetails(orderId) {
    // Use cached order if available — instant, no network call
    if (_ordersCache[orderId]) {
        displayOrderDetail(_ordersCache[orderId]);
        navigateTo('order-detail');
        return;
    }
    // Fallback: fetch if cache miss
    showLoading();
    const phone = localStorage.getItem("customer_phone");
    fetch(`${API_URL}/orders?phone=${phone}&order_id=${orderId}`)
        .then(res => res.json())
        .then(data => {
            const order = Array.isArray(data) ? data.find(o => o.order_id === orderId) : data;
            if (order) {
                _ordersCache[orderId] = order;
                displayOrderDetail(order);
                navigateTo('order-detail');
            }
        })
        .catch(error => console.error('Error loading order:', error))
        .finally(() => hideLoading());
}

function displayOrderDetail(order) {
    const container = document.getElementById('orderDetailContainer');
    
    const orderDate = new Date(order.created_at).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    const statusColors = {
        'Pending': '#ff9800',
        'Confirmed': '#2196f3',
        'Shipped': '#9c27b0',
        'Delivered': '#4caf50',
        'Cancelled': '#f44336'
    };
    const statusColor = statusColors[order.status] || '#666';
    
    // Format payment method
    const paymentMethodDisplay = {
        'razorpay': 'Razorpay',
        'cod': 'Cash on Delivery',
        'upi': 'UPI'
    };
    const paymentMethod = paymentMethodDisplay[order.payment_method] || order.payment_method || 'COD';
    
    // Format payment status
    const paymentStatusDisplay = {
        'paid': 'Paid',
        'pending': 'Pending',
        'failed': 'Failed'
    };
    const paymentStatus = paymentStatusDisplay[order.payment_status] || order.payment_status || 'Pending';
    const paymentStatusColor = order.payment_status === 'paid' ? '#4caf50' : '#ff9800';
    
    const items = order.items || [];
    
    container.innerHTML = `
        <div class="order-detail-card">
            <div class="order-detail-header">
                <div>
                    <h3 class="order-detail-id">Order #${order.order_id}</h3>
                    <p class="order-detail-date">${orderDate}</p>
                </div>
                <div class="order-detail-status" style="background: ${statusColor}20; color: ${statusColor};">
                    ${order.status}
                </div>
            </div>
            
            <div class="order-detail-section">
                <h4 class="section-heading">Items Ordered</h4>
                <div class="order-detail-items">
                    ${items.map(item => `
                        <div class="order-detail-item">
                            <div class="item-info">
                                <div class="item-name">${item.part_name}</div>
                                <div class="item-details">
                                    <span>${item.bike_brand} ${item.bike_model}</span>
                                    ${item.color ? `<span class="item-color">• Color: ${item.color}</span>` : ''}
                                </div>
                                <div class="item-quantity">Quantity: ${item.quantity}</div>
                            </div>
                            <div class="item-price">₹${(item.price * item.quantity).toFixed(2)}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="order-detail-section">
                <h4 class="section-heading">Delivery Address</h4>
                <div class="address-box">
                    <p class="customer-name">${order.full_name}</p>
                    <p class="customer-phone">${order.phone}</p>
                    <p class="customer-address">${order.delivery_address || order.address}</p>
                </div>
            </div>
            
            <div class="order-detail-section">
                <h4 class="section-heading">Payment Information</h4>
                <div class="payment-info-box">
                    <div class="info-row">
                        <span>Payment Method:</span>
                        <span class="info-value">${paymentMethod}</span>
                    </div>
                    <div class="info-row">
                        <span>Payment Status:</span>
                        <span class="info-value" style="color: ${paymentStatusColor}; font-weight: 700;">${paymentStatus}</span>
                    </div>
                    ${order.payment_id ? `
                        <div class="info-row">
                            <span>Transaction ID:</span>
                            <span class="info-value" style="font-size: 11px;">${order.payment_id}</span>
                        </div>
                    ` : ''}
                </div>
            </div>
            
            <div class="order-detail-section">
                <h4 class="section-heading">Price Details</h4>
                <div class="price-details-box">
                    <div class="price-row">
                        <span>Subtotal (${items.length} item${items.length > 1 ? 's' : ''}):</span>
                        <span>₹${parseFloat(order.subtotal || 0).toFixed(2)}</span>
                    </div>
                    <div class="price-row">
                        <span>Delivery Charge:</span>
                        <span>₹${parseFloat(order.delivery_charge || 0).toFixed(2)}</span>
                    </div>
                    <div class="price-row total-row">
                        <span>Total Amount:</span>
                        <span class="total-amount">₹${parseFloat(order.total_amount).toFixed(2)}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}


// Home Page Functions
async function loadPopularBrands() {
    try {
        const response = await fetch(`${API_URL}/brands`);
        const brands = await response.json();
        
        const container = document.getElementById('popularBrands');
        if (!container) return;
        
        const uniqueBrands = [...new Map((Array.isArray(brands) ? brands : [])
            .filter(brand => typeof brand === 'string' && brand.trim())
            .map(brand => [brand.trim().toLocaleLowerCase(), brand.trim()])).values()];
        const popularOrder = ['honda', 'hero', 'bajaj', 'tvs', 'yamaha', 'suzuki', 'royal enfield', 'ktm'];
        uniqueBrands.sort((a, b) => {
            const aRank = popularOrder.indexOf(a.toLocaleLowerCase());
            const bRank = popularOrder.indexOf(b.toLocaleLowerCase());
            return (aRank < 0 ? popularOrder.length : aRank) - (bRank < 0 ? popularOrder.length : bRank);
        });
        container.replaceChildren();
        uniqueBrands.slice(0, 8).forEach(brand => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'brand-card';
            button.setAttribute('aria-label', `Shop parts for ${brand}`);
            const icon = document.createElement('span');
            icon.className = 'brand-card-icon';
            icon.setAttribute('aria-hidden', 'true');
            icon.textContent = brand.charAt(0).toLocaleUpperCase();
            const name = document.createElement('span');
            name.className = 'brand-card-name';
            name.textContent = brand;
            button.append(icon, name);
            button.addEventListener('click', () => selectBrandQuick(brand));
            container.appendChild(button);
        });
    } catch (error) {
        console.error('Error loading popular brands:', error);
    }
}

async function loadAllCategories() {
    try {
        const response = await fetch(`${API_URL}/categories`);
        const categories = await response.json();
        
        const container = document.getElementById('categoriesGrid');
        if (!container) return;
        
        const displayNames = new Map([
            ['brake', 'Brakes'], ['brakes', 'Brakes'], ['break', 'Brakes'],
            ['chasis', 'Chassis'], ['chassis', 'Chassis']
        ]);
        const uniqueCategories = new Map();
        (Array.isArray(categories) ? categories : []).forEach(category => {
            if (typeof category !== 'string' || !category.trim()) return;
            const raw = category.trim();
            const label = displayNames.get(raw.toLocaleLowerCase()) || raw;
            const key = label.toLocaleLowerCase();
            if (!uniqueCategories.has(key)) uniqueCategories.set(key, { label, query: raw });
        });
        container.replaceChildren();
        uniqueCategories.forEach(({ label, query }) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'category-card';
            button.setAttribute('aria-label', `Browse ${label} parts`);
            const icon = document.createElement('span');
            icon.className = 'category-icon';
            icon.setAttribute('aria-hidden', 'true');
            icon.innerHTML = categoryIconSvg(label);
            const name = document.createElement('span');
            name.className = 'category-name';
            name.textContent = label;
            button.append(icon, name);
            button.addEventListener('click', () => quickSearch(query));
            container.appendChild(button);
        });
        
    } catch (error) {
        console.error('Error loading categories:', error);
        // Show fallback categories
        const container = document.getElementById('categoriesGrid');
        if (container) {
            const fallbackCategories = [
                { label: 'Brakes', query: 'brake' },
                { label: 'Chain', query: 'chain' },
                { label: 'Filters', query: 'filter' }
            ];
            container.replaceChildren();
            fallbackCategories.forEach(({ label, query }) => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'category-card';
                button.setAttribute('aria-label', `Browse ${label} parts`);
                const icon = document.createElement('span');
                icon.className = 'category-icon';
                icon.setAttribute('aria-hidden', 'true');
                icon.innerHTML = categoryIconSvg(label);
                const name = document.createElement('span');
                name.className = 'category-name';
                name.textContent = label;
                button.append(icon, name);
                button.addEventListener('click', () => quickSearch(query));
                container.appendChild(button);
            });
        }
    }
}

const CATEGORY_ICON_SHAPES = {
    brake: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2.1"/><path d="M17.9 6.1 20 8.2v4h-2.7M6.2 6.7l1.5 1.5M6.1 17.8l1.5-1.5M12 3.5v2"/>',
    chain: '<path d="m9.2 8.3 1.4-1.4a3.2 3.2 0 0 1 4.5 4.5l-1.4 1.4M14.8 15.7l-1.4 1.4a3.2 3.2 0 0 1-4.5-4.5l1.4-1.4M8.8 15.2l6.4-6.4"/>',
    filter: '<rect x="7" y="3.5" width="10" height="17" rx="2"/><path d="M7 7h10M7 10h10M7 13h10M7 16h10M9 20.5v1M15 20.5v1"/>',
    headlight: '<path d="M4 8h10l6 4-6 4H4z"/><path d="M3 9v6M20 8l1.5-1M21 12h2M20 16l1.5 1"/>',
    taillight: '<path d="M5 7h12l2 2v6l-2 2H5z"/><path d="M8 10v4M11 10v4M3 9v6"/>',
    battery: '<rect x="5" y="6" width="14" height="15" rx="2"/><path d="M9 6V4h6v2M9 12h2m-1-1v2m4-1h2"/>',
    body: '<path d="M4 14.5 7 9h8l5 3-2 5H7z"/><path d="m8 9 2-3h5l2 3M8 17v2m8-2v2"/>',
    engine: '<path d="M6 8h3l2-2h5l2 2h2v9H6z"/><path d="M8 8V6m8 2V6M8 12h8m-6 5v2m6-2v2M4 11v4"/>',
    clutch: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="5.5"/><path d="M12 4v3m0 10v3M4 12h3m10 0h3M6.3 6.3l2.1 2.1m7.2 7.2 2.1 2.1m0-11.4-2.1 2.1m-7.2 7.2-2.1 2.1"/>',
    suspension: '<path d="M8 3v3l4 2-4 2 4 2-4 2 4 2-4 2v3M16 3v3m0 12v3M8 3h8m-8 18h8"/>',
    electrical: '<path d="m13.5 2.5-8 11h6l-1 8 8-12h-6z"/>',
    exhaust: '<path d="M4 7h5v5h4l3 3v3h-5l-3-3H4z"/><path d="M16 15h3l2 2v1h-5"/>',
    fuel: '<path d="M6 21V5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v16z"/><path d="M9 7h5v5H9zM17 8h2l2 2v7a2 2 0 0 1-4 0v-4M4 21h14"/>',
    cooling: '<rect x="5" y="4" width="14" height="16" rx="1.5"/><path d="M8 7v10m4-10v10m4-10v10M3 8h2m14 0h2M3 16h2m14 0h2"/>',
    transmission: '<circle cx="9" cy="12" r="4.5"/><circle cx="16.5" cy="8" r="2.5"/><path d="M9 5v2m0 10v2m-7-7h2m10 0h2M5 8l1.5 1.5m5 5L13 16m0-9 1.5-1.5"/>',
    wheel: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.5"/><path d="m12 3 0 6m0 6v6M3 12h6m6 0h6M5.6 5.6l4.3 4.3m4.2 4.2 4.3 4.3m0-12.8-4.3 4.3m-4.2 4.2-4.3 4.3"/>',
    mirror: '<path d="M12 14v6m0-6-4 6m4-6 4 6"/><path d="M7 4h10l2 6a3 3 0 0 1-3 4H8a3 3 0 0 1-3-4z"/>',
    seat: '<path d="M5 14h3l2-5a3 3 0 0 1 3-2h3l3 7h1v3H7a3 3 0 0 1-3-3z"/><path d="M8 17v2m9-2v2"/>',
    handle: '<path d="M3 8h3l2 5h8l2-5h3M6 8l1-2h3m8 2-1-2h-3M12 13v6"/>',
    cable: '<path d="M5 4v3a7 7 0 0 0 14 0V4M5 4H3m2 0h2m12 0h2m-2 0h-2M12 14v6m-2 0h4"/>',
    bearing: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="5.5"/><circle cx="12" cy="12" r="2"/>',
    gasket: '<path d="M6 4h12l2 2v12l-2 2H6l-2-2V6z"/><circle cx="8" cy="8" r="1"/><circle cx="16" cy="8" r="1"/><circle cx="8" cy="16" r="1"/><circle cx="16" cy="16" r="1"/>',
    oil: '<path d="M12 3s-6 7-6 11a6 6 0 0 0 12 0c0-4-6-11-6-11z"/><path d="M9 15a3 3 0 0 0 3 3"/>',
    spark: '<path d="M9 3h6v4l2 2v3H7V9l2-2zM8 12v4h8v-4m-6 4v3h4v-3m-2-13v2"/>',
    horn: '<path d="M4 10h4l10-5v14L8 14H4z"/><path d="M8 10v4m9-8 2-2m0 14-2-2m4-5h2"/>',
    indicator: '<path d="M5 7h10l4 5-4 5H5z"/><path d="M3 9v6m18-6 2-1m-2 4h2m-2 4 2 1"/>',
    tank: '<path d="M6 8c0-2 2-4 5-4h4l3 4 2 2v6l-2 2H8l-2-3z"/><path d="M9 8h7m-8 8h9"/>',
    fender: '<path d="M3 16a9 9 0 0 1 18 0M6 16h12M5 18h2m10 0h2"/>',
    footrest: '<path d="M4 9h7v4H4zM11 11h4l3 4m-3-1 2 5m-7-7v5m0 0h3"/>',
    stand: '<path d="M7 4v5l7 4-5 8M7 21h7m-7-12H4m3 0h3"/>',
    lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3"/>',
    speedometer: '<path d="M4 18a9 9 0 1 1 16 0"/><path d="m12 13 4-4m-11 9h14M7 8l1.5 1.5M12 5v2m5-1-1.5 2"/><circle cx="12" cy="13" r="1"/>',
    switch: '<path d="M5 5v5m0-5h2m-2 0H3m2 5a3 3 0 0 0 6 0V8m0 0V5m0 3h2m-2 0H9m5 11h6m-6 0v-3m0 3v3"/>',
    wrench: '<path d="M14 6a5 5 0 0 0-6 6L3 17a2 2 0 0 0 3 3l5-5a5 5 0 0 0 6-6l-3 3-3-3z"/>'
};

const CATEGORY_ICON_RULES = [
    [['tail light', 'taillight', 'tail lamp', 'rear light', 'rear lamp'], 'taillight'],
    [['headlight', 'head light', 'headlamp', 'head lamp'], 'headlight'],
    [['switch gear', 'switchgear'], 'switch'],
    [['spark plug'], 'spark'],
    [['speedometer', 'speedo', 'meter'], 'speedometer'],
    [['suspension', 'shock absorber', 'front fork', 'fork'], 'suspension'],
    [['brake', 'break'], 'brake'],
    [['chain', 'sprocket'], 'chain'],
    [['air cleaner', 'filter'], 'filter'],
    [['battery'], 'battery'],
    [['clutch'], 'clutch'],
    [['transmission', 'gearbox', 'gear'], 'transmission'],
    [['engine'], 'engine'],
    [['exhaust', 'muffler'], 'exhaust'],
    [['cooling', 'radiator', 'coolant'], 'cooling'],
    [['carburetor', 'fuel', 'petrol', 'tank'], 'fuel'],
    [['wheel', 'tyre', 'tire', 'rim'], 'wheel'],
    [['bearing'], 'bearing'],
    [['mirror'], 'mirror'],
    [['seat'], 'seat'],
    [['handle', 'handlebar', 'grip'], 'handle'],
    [['cable'], 'cable'],
    [['gasket'], 'gasket'],
    [['oil', 'lubricant'], 'oil'],
    [['horn'], 'horn'],
    [['indicator', 'turn signal'], 'indicator'],
    [['light', 'lamp'], 'headlight'],
    [['fender', 'mudguard'], 'fender'],
    [['body', 'fairing', 'panel', 'cover'], 'body'],
    [['footrest', 'foot peg'], 'footrest'],
    [['stand', 'kickstand'], 'stand'],
    [['lock'], 'lock'],
    [['switch'], 'switch'],
    [['starter motor', 'electrical', 'electric', 'wiring', 'ignition', 'generator', 'alternator'], 'electrical']
];

function categoryIconSvg(category) {
    const normalized = String(category || '').toLocaleLowerCase().replace(/[_-]+/g, ' ');
    let iconKey = null;
    let longestMatch = 0;
    CATEGORY_ICON_RULES.forEach(([terms, key]) => {
        terms.forEach(term => {
            if (term.length > longestMatch && normalized.includes(term)) {
                iconKey = key;
                longestMatch = term.length;
            }
        });
    });
    const shape = CATEGORY_ICON_SHAPES[iconKey] || CATEGORY_ICON_SHAPES.wrench;
    return `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true">${shape}</svg>`;
}

function renderStaticCategoryIcons() {
    document.querySelectorAll('[data-category-icon]').forEach(icon => {
        icon.innerHTML = categoryIconSvg(icon.dataset.categoryIcon);
    });
}

async function loadHomepagePicks() {
    const section = document.getElementById('homePicksSection');
    const grid = document.getElementById('homePicksGrid');
    if (!section || !grid) return;

    try {
        const response = await fetch(`${API_URL}/parts?limit=8`);
        if (!response.ok) throw new Error(`Popular parts request failed (${response.status})`);
        const products = await response.json();
        if (!Array.isArray(products) || products.length === 0) {
            section.hidden = true;
            return;
        }

        grid.replaceChildren();
        products.slice(0, 8).forEach(product => {
            _productCache[String(product.id)] = product;
            grid.appendChild(createProductCard(product));
        });
        section.hidden = false;
    } catch (error) {
        section.hidden = true;
        console.error('Error loading homepage products:', error);
    }
}

let heroFullBodyProducts = [];
let heroFullBodyIndex = 0;
let heroFullBodyTimer = null;
let heroCarouselControlsTimer = null;
let heroTouchStart = null;
let heroSwipeConsumed = false;

async function loadHeroFullBodyShowcase() {
    const showcase = document.getElementById('heroProductShowcase');
    const bikeArt = document.getElementById('heroBikeArt');
    if (!showcase || !bikeArt) return;

    try {
        const response = await fetch(`${API_URL}/homepage/full-body-kits`);
        if (!response.ok) throw new Error(`Full body showcase request failed (${response.status})`);
        const results = await response.json();
        const matches = (Array.isArray(results) ? results : []).filter(product =>
            /full[\s-]*body/i.test(product.part_name || '') &&
            (product.web_image_url || product.image_url) &&
            (product.stock_qty == null || Number(product.stock_qty) > 0)
        );

        heroFullBodyProducts = spreadHeroProductsAcrossBrands(matches);
        if (!heroFullBodyProducts.length) return;

        heroFullBodyProducts.forEach(product => {
            _productCache[String(product.id)] = product;
        });

        showcase.hidden = false;
        bikeArt.hidden = true;
        renderHeroFullBodySlide();
        setupHeroFullBodyControls();
    } catch (error) {
        // Keep the decorative bike illustration visible if the catalog request fails.
        console.warn('Could not load full body showcase:', error);
    }
}

function spreadHeroProductsAcrossBrands(products) {
    const brandQueues = new Map();
    products.forEach(product => {
        const brand = String(product.bike_brand || 'Other').trim();
        const key = brand.toLocaleLowerCase();
        if (!brandQueues.has(key)) brandQueues.set(key, { brand, products: [] });
        brandQueues.get(key).products.push(product);
    });

    const spread = [];
    while (brandQueues.size) {
        for (const [key, queue] of brandQueues) {
            spread.push(queue.products.shift());
            if (!queue.products.length) brandQueues.delete(key);
        }
    }
    return spread;
}

function renderHeroFullBodySlide() {
    const slide = document.getElementById('heroProductSlide');
    const position = document.getElementById('heroCarouselPosition');
    const product = heroFullBodyProducts[heroFullBodyIndex];
    if (!slide || !product) return;

    const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, character => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
    const imageUrl = _imgUrl(product.web_image_url || product.image_url);
    const fitment = [product.bike_brand, product.bike_model].filter(Boolean).join(' ');
    const price = Number(product.price);
    const displayPrice = Number.isFinite(price) ? price.toLocaleString('en-IN') : (product.price || '—');
    const years = product.year_from
        ? `${product.year_from}${product.year_to ? `–${product.year_to}` : '+'}`
        : '';

    slide.innerHTML = `
      <article class="hero-product-card" role="link" tabindex="0" aria-label="Open details for ${escapeHtml(product.part_name)} for ${escapeHtml(fitment)}">
        <div class="hero-product-photo">
          <img src="${escapeHtml(imageUrl)}" alt="${escapeHtml(product.part_name)} for ${escapeHtml(fitment)}" loading="lazy" onerror="this.src='/placeholder.svg';this.onerror=null">
          <div class="hero-carousel-controls" id="heroCarouselControls" ${heroFullBodyProducts.length < 2 ? 'hidden' : ''} aria-label="Featured product navigation">
            <button class="hero-carousel-arrow" type="button" data-hero-direction="-1" aria-label="Previous full body kit">‹</button>
            <span class="hero-carousel-position" id="heroCarouselPosition" aria-live="polite"></span>
            <button class="hero-carousel-arrow" type="button" data-hero-direction="1" aria-label="Next full body kit">›</button>
          </div>
        </div>
        <div class="hero-product-copy">
          <span class="hero-product-label">Featured full body kit</span>
          <h3>${escapeHtml(product.part_name || 'Full Body')}</h3>
          <p>${escapeHtml(fitment || 'Motorcycle body parts')}${years ? ` <span>·</span> ${escapeHtml(years)}` : ''}</p>
          <div class="hero-product-buy-row">
            <strong>₹${escapeHtml(displayPrice)}</strong>
            <button class="hero-product-buy" type="button" aria-label="Buy ${escapeHtml(product.part_name)} for ${escapeHtml(fitment)}">Buy now <span aria-hidden="true">→</span></button>
          </div>
        </div>
      </article>
    `;

    const productCard = slide.querySelector('.hero-product-card');
    productCard?.addEventListener('click', event => {
        if (event.target.closest('button')) return;
        if (heroSwipeConsumed) {
            heroSwipeConsumed = false;
            return;
        }
        openProductDetails(product.id);
    });
    productCard?.addEventListener('keydown', event => {
        if (event.target !== productCard || event.key !== 'Enter') return;
        event.preventDefault();
        openProductDetails(product.id);
    });

    slide.querySelector('.hero-product-buy')?.addEventListener('click', () => {
        addToCart(product.id, product);
        updateCartSummary();
        navigateTo('checkout');
    });

    if (position) {
        position.textContent = `${heroFullBodyIndex + 1} / ${heroFullBodyProducts.length}`;
    }
}

function stopHeroFullBodyRotation() {
    if (heroFullBodyTimer) {
        clearInterval(heroFullBodyTimer);
        heroFullBodyTimer = null;
    }
}

function startHeroFullBodyRotation() {
    stopHeroFullBodyRotation();
    if (heroFullBodyProducts.length < 2 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    heroFullBodyTimer = setInterval(() => {
        heroFullBodyIndex = (heroFullBodyIndex + 1) % heroFullBodyProducts.length;
        renderHeroFullBodySlide();
    }, 6000);
}

function setupHeroFullBodyControls() {
    const showcase = document.getElementById('heroProductShowcase');
    if (!showcase || heroFullBodyProducts.length < 2 || showcase.dataset.controlsReady === 'true') return;
    showcase.dataset.controlsReady = 'true';

    showcase.addEventListener('click', event => {
        const arrow = event.target.closest('[data-hero-direction]');
        if (!arrow) return;
        event.preventDefault();
        event.stopPropagation();
        changeHeroFullBodySlide(Number(arrow.dataset.heroDirection));
        revealHeroCarouselControls();
    });

    showcase.addEventListener('pointerdown', event => {
        if (event.pointerType === 'mouse' || !event.target.closest('.hero-product-photo')) return;
        heroTouchStart = { x: event.clientX, y: event.clientY };
        stopHeroFullBodyRotation();
        revealHeroCarouselControls();
    });
    showcase.addEventListener('pointerup', event => {
        if (!heroTouchStart) return;
        const deltaX = event.clientX - heroTouchStart.x;
        const deltaY = event.clientY - heroTouchStart.y;
        heroTouchStart = null;
        if (Math.abs(deltaX) > 42 && Math.abs(deltaX) > Math.abs(deltaY)) {
            heroSwipeConsumed = true;
            changeHeroFullBodySlide(deltaX < 0 ? 1 : -1);
            revealHeroCarouselControls();
            setTimeout(() => { heroSwipeConsumed = false; }, 500);
        } else {
            startHeroFullBodyRotation();
        }
    });
    showcase.addEventListener('pointercancel', () => {
        heroTouchStart = null;
        startHeroFullBodyRotation();
    });
    let lastHeroWheelAt = 0;
    showcase.addEventListener('wheel', event => {
        if (Math.abs(event.deltaX) < 24 || Math.abs(event.deltaX) <= Math.abs(event.deltaY)) return;
        const now = Date.now();
        if (now - lastHeroWheelAt < 450) return;
        lastHeroWheelAt = now;
        changeHeroFullBodySlide(event.deltaX > 0 ? 1 : -1);
        revealHeroCarouselControls();
    }, { passive: true });

    showcase.addEventListener('mouseenter', stopHeroFullBodyRotation);
    showcase.addEventListener('mouseleave', startHeroFullBodyRotation);
    showcase.addEventListener('focusin', stopHeroFullBodyRotation);
    showcase.addEventListener('focusout', event => {
        if (!showcase.contains(event.relatedTarget)) startHeroFullBodyRotation();
    });
    startHeroFullBodyRotation();
}

function changeHeroFullBodySlide(direction) {
    if (heroFullBodyProducts.length < 2) return;
    heroFullBodyIndex = (heroFullBodyIndex + direction + heroFullBodyProducts.length) % heroFullBodyProducts.length;
    renderHeroFullBodySlide();
    startHeroFullBodyRotation();
}

function revealHeroCarouselControls() {
    const photo = document.querySelector('#heroProductSlide .hero-product-photo');
    if (!photo) return;
    photo.classList.add('controls-visible');
    clearTimeout(heroCarouselControlsTimer);
    heroCarouselControlsTimer = setTimeout(() => photo.classList.remove('controls-visible'), 2200);
}

function selectBrandQuick(brand) {
    document.getElementById('brandSelect').value = brand;
    handleBrandChange({ target: { value: brand } });
    
    // Scroll to filter section
    document.querySelector('.find-part-section').scrollIntoView({ behavior: 'smooth' });
}

function quickSearch(category) {
    searchParts(category);
    navigateTo('products');
}


// Bottom Navigation Auto-Hide
function setupScrollBehavior() {
    const header = document.querySelector('.header');
    const floatingCart = document.getElementById('floatingCart');
    let scrollTimeout;
    
    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        clearTimeout(scrollTimeout);
        
        // Hide header on scroll down, show on scroll up
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            header.classList.add('header-hidden');
        } else if (scrollTop < lastScrollTop) {
            header.classList.remove('header-hidden');
        }
        if (scrollTop < 50) {
            header.classList.remove('header-hidden');
        }

        // Floating cart: show when scrolled past header (~80px), hide at top
        if (floatingCart) {
            if (scrollTop > 80) {
                floatingCart.style.display = 'flex';
                requestAnimationFrame(() => floatingCart.classList.add('visible'));
            } else {
                floatingCart.classList.remove('visible');
                setTimeout(() => {
                    if (!floatingCart.classList.contains('visible')) floatingCart.style.display = 'none';
                }, 300);
            }
        }
        
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
        
        scrollTimeout = setTimeout(() => {
            header.classList.remove('header-hidden');
        }, 1000);
    }, { passive: true });
    
    // Show on touch/mouse interaction
    document.addEventListener('touchstart', () => {
        header.classList.remove('header-hidden');
    }, { passive: true });
}

// Animated Placeholder
function animatePlaceholder() {
    const searchInput = document.getElementById('searchInput');
    const placeholders = [
        'Search Brake Pads...',
        'Search Hero Splendor...',
        'Search Chain Sprocket...',
        'Search Honda Activa...',
        'Search Headlight...',
        'Search Yamaha FZ...',
        'Search Air Filter...',
        'Search Bajaj Pulsar...',
        'Search Clutch Plate...',
        'Search TVS Apache...',
        'Search Engine Oil...',
        'Search Royal Enfield...',
        'Search Spark Plug...',
        'Search KTM Duke...',
        'Search Mirrors...',
        'Search Suzuki Gixxer...'
    ];
    
    let currentIndex = 0;
    
    function updatePlaceholder() {
        if (searchInput && document.activeElement !== searchInput) {
            searchInput.placeholder = placeholders[currentIndex];
            currentIndex = (currentIndex + 1) % placeholders.length;
        }
    }
    
    // Update every 3 seconds
    setInterval(updatePlaceholder, 3000);
}

// ── Deep-link: open product from URL hash ─────────────────────────────────────
(function handleDeepLink() {
    const hash = window.location.hash;
    const match = hash.match(/^#product-([a-zA-Z0-9-]+)$/);
    if (!match) return;
    const productId = match[1];
    // If app already ready (e.g. hash changed after load), open immediately
    if (window._appReady) {
        openProductDetails(productId);
    } else {
        // Queue it — initializeApp will fire it once done
        window._pendingDeepLink = productId;
    }
})();

// Handle browser back/forward through product pages
window.addEventListener('popstate', (e) => {
    if (e.state?.productId) {
        openProductDetails(e.state.productId);
    } else if (!window.location.hash) {
        navigateTo('home');
    }
});

// ── Share product ─────────────────────────────────────────────────────────────
function shareProduct(productId, title) {
    // Use ?product= format for better compatibility with social media crawlers
    const url = `${location.origin}${location.pathname}?product=${productId}`;


    // Try native share (works on mobile Chrome/Safari over HTTPS)
    if (navigator.share) {
        navigator.share({ title: title, text: title, url: url })
            .then(() => {})
            .catch((err) => {
                // User cancelled or share failed — show manual menu
                if (err.name !== 'AbortError') showShareMenu(url, title);
            });
        return;
    }

    // Desktop or unsupported — show share menu
    showShareMenu(url, title);
}

function showShareMenu(url, title) {
    // Remove existing menu if any
    const existing = document.getElementById('shareMenu');
    if (existing) existing.remove();

    const encoded = encodeURIComponent(url);
    const encodedTitle = encodeURIComponent(title);

    const menu = document.createElement('div');
    menu.id = 'shareMenu';
    menu.style.cssText = `
        position:fixed;bottom:0;left:0;right:0;z-index:10000;
        background:#1C2128;border-radius:20px 20px 0 0;
        padding:20px 16px 32px;
        box-shadow:0 -8px 30px rgba(0,0,0,0.5);
        animation:slideUp 0.25s ease;
    `;

    menu.innerHTML = `
        <style>
            @keyframes slideUp { from { transform:translateY(100%); } to { transform:translateY(0); } }
            .share-grid { display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:20px 0; }
            .share-app { display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;text-decoration:none; }
            .share-app-icon { width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:26px; }
            .share-app span { font-size:11px;color:rgba(255,255,255,0.7);text-align:center; }
            .share-url-box { background:#0F1419;border-radius:10px;padding:12px;display:flex;align-items:center;gap:10px;margin-top:8px; }
            .share-url-text { flex:1;font-size:12px;color:rgba(255,255,255,0.5);overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }
            .share-copy-btn { background:#FF6700;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap; }
        </style>
        <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="font-size:16px;font-weight:700;color:#fff;">Share Product</span>
            <button onclick="document.getElementById('shareMenu').remove()" style="background:rgba(255,255,255,0.1);border:none;color:#fff;width:30px;height:30px;border-radius:50%;font-size:16px;cursor:pointer;">✕</button>
        </div>
        <div class="share-grid">
            <a class="share-app" href="https://wa.me/?text=${encodedTitle}%20${encoded}" target="_blank" rel="noopener">
                <div class="share-app-icon" style="background:#25D366;">
                    <svg viewBox="0 0 24 24" fill="white" width="28" height="28"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                </div>
                <span>WhatsApp</span>
            </a>
            <a class="share-app" href="https://t.me/share/url?url=${encoded}&text=${encodedTitle}" target="_blank" rel="noopener">
                <div class="share-app-icon" style="background:#2AABEE;">
                    <svg viewBox="0 0 24 24" fill="white" width="28" height="28"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
                </div>
                <span>Telegram</span>
            </a>
            <a class="share-app" href="https://www.facebook.com/sharer/sharer.php?u=${encoded}" target="_blank" rel="noopener">
                <div class="share-app-icon" style="background:#1877F2;">
                    <svg viewBox="0 0 24 24" fill="white" width="28" height="28"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                </div>
                <span>Facebook</span>
            </a>
            <a class="share-app" href="https://www.instagram.com/" target="_blank" rel="noopener" onclick="copyToClipboard('${url}');showCopyToast('Link copied! Paste in Instagram.');">
                <div class="share-app-icon" style="background:linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);">
                    <svg viewBox="0 0 24 24" fill="white" width="28" height="28"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/></svg>
                </div>
                <span>Instagram</span>
            </a>
        </div>
        <div class="share-url-box">
            <span class="share-url-text">${url}</span>
            <button class="share-copy-btn" onclick="copyToClipboard('${url}');showCopyToast('Link copied!');">Copy Link</button>
        </div>
    `;

    // Close on backdrop tap
    menu.addEventListener('click', (e) => { if (e.target === menu) menu.remove(); });
    document.body.appendChild(menu);
}

function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).catch(() => _fallbackCopy(text));
    } else {
        _fallbackCopy(text);
    }
}

function _fallbackCopy(text) {
    const el = document.createElement('textarea');
    el.value = text;
    el.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
    document.body.appendChild(el);
    el.focus(); el.select();
    try { document.execCommand('copy'); } catch(e) {}
    document.body.removeChild(el);
}

function showCopyToast(msg) {
    let toast = document.getElementById('shareToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'shareToast';
        toast.style.cssText = `
            position:fixed;bottom:80px;left:50%;transform:translateX(-50%);
            background:#333;color:#fff;padding:10px 20px;border-radius:20px;
            font-size:13px;z-index:99999;pointer-events:none;transition:opacity 0.3s;
        `;
        document.body.appendChild(toast);
    }
    toast.textContent = msg || '🔗 Link copied!';
    toast.style.opacity = '1';
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.style.opacity = '0', 2500);
}
