/**
 * service.js — Bike Service Booking frontend
 * Handles mode toggle + full 4-step booking flow + cancel flow.
 * Does NOT touch any existing app.js logic.
 */

// ─── State ────────────────────────────────────────────────────────────────────
const svcState = {
  selectedDate: null,
  selectedSlot: null,
  bookingRef: null,
  razorpayOrderId: null,
  razorpayKey: null,
  confirmedBooking: null,
};

// ─── Mode Toggle (Task 9.1) ───────────────────────────────────────────────────
function switchMode(mode) {
  const sparesSections = [
    'filterSection', 'productsSection', 'cartSection',
    'checkoutSection', 'paymentSection', 'confirmationSection',
    'helpSection', 'productDetailSection', 'ordersSection', 'orderDetailSection',
  ];
  const serviceSection = document.getElementById('serviceSection');
  const btnSpares = document.getElementById('btnSpares');
  const btnService = document.getElementById('btnService');
  const slider = document.getElementById('modeSlider');

  if (mode === 'service') {
    sparesSections.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
    serviceSection.style.display = 'block';
    btnService.classList.add('active');
    btnSpares.classList.remove('active');
    if (slider) slider.classList.add('right');
    renderServiceHome();
  } else {
    serviceSection.style.display = 'none';
    btnSpares.classList.add('active');
    btnService.classList.remove('active');
    if (slider) slider.classList.remove('right');
    // Restore spares default view
    const filterSection = document.getElementById('filterSection');
    if (filterSection) filterSection.style.display = 'block';
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function svcEl(id) { return document.getElementById(id); }

function svcShowStep(stepId) {
  ['svcStepDate', 'svcStepDetails', 'svcStepConfirm', 'svcStepCancel']
    .forEach(id => {
      const el = svcEl(id);
      if (el) el.style.display = id === stepId ? 'block' : 'none';
    });
}

function svcSetError(elId, msg) {
  const el = svcEl(elId);
  if (el) el.textContent = msg || '';
}

function svcShowLoading(show) {
  const overlay = document.getElementById('loadingOverlay');
  if (overlay) overlay.classList.toggle('show', show);
}

function svcFmtDate(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

function svcFmt12h(time24) {
  // Converts "09:00" → "9:00 AM", "13:00" → "1:00 PM"
  const [h, m] = time24.split(':').map(Number);
  const ampm = h < 12 ? 'AM' : 'PM';
  const h12 = h % 12 || 12;
  return `${h12}:${String(m).padStart(2, '0')} ${ampm}`;
}

function svcFmtSlot(slot) {
  // Converts "09:00-10:00" → "9:00 AM – 10:00 AM"
  const [start, end] = slot.split('-');
  return `${svcFmt12h(start)} – ${svcFmt12h(end)}`;
}

// ─── Render service home (Step 1 — date + slot) ───────────────────────────────
function renderServiceHome() {
  const section = svcEl('serviceSection');
  section.innerHTML = `
    <!-- Availability banner (populated by svcLoadAvailability) -->
    <div id="svcAvailabilityBanner"></div>

    <!-- Sub-tab bar -->
    <div style="display:flex;gap:0;margin-bottom:16px;border-radius:12px;overflow:hidden;border:1px solid var(--border-color);">
      <button id="svcTabBook" onclick="svcSubTab('book')"
        style="flex:1;padding:11px;background:var(--primary-color);color:white;border:none;font-size:13px;font-weight:700;cursor:pointer;">
        📅 Book Service
      </button>
      <button id="svcTabHistory" onclick="svcSubTab('history')"
        style="flex:1;padding:11px;background:white;color:var(--text-secondary);border:none;font-size:13px;font-weight:600;cursor:pointer;">
        📋 My Bookings
      </button>
    </div>

    <!-- Booking flow -->
    <div id="svcTabBookContent">
    <div class="service-card" id="svcStepDate">
      <div class="service-step-title">📅 Book a Service Slot</div>
      <p style="color:var(--text-secondary);font-size:14px;margin-bottom:16px;">
        Select a date and 1-hour slot. Pay ₹500 to confirm your appointment.
      </p>

      <div class="form-group">
        <label style="font-size:14px;font-weight:600;">Choose Date</label>
        <input type="date" id="svcDatePicker" class="filter-select" style="width:100%;margin-top:6px;"
          min="${new Date().toISOString().split('T')[0]}">
      </div>

      <div id="svcSlotContainer" style="display:none;">
        <label style="font-size:14px;font-weight:600;display:block;margin-bottom:8px;">Choose Time Slot</label>
        <div class="slot-grid" id="svcSlotGrid"></div>
        <p class="service-error" id="svcSlotError"></p>
      </div>

      <button class="btn-primary btn-large" id="svcBtnNext1" style="margin-top:16px;display:none;"
        onclick="svcGoToDetails()">Next →</button>
    </div>

    <!-- Step 2: Customer details -->
    <div class="service-card" id="svcStepDetails" style="display:none;">
      <button onclick="svcShowStep('svcStepDate')" style="background:none;border:none;color:#2196F3;font-size:14px;cursor:pointer;margin-bottom:12px;">← Back</button>
      <div class="service-step-title">👤 Your Details</div>

      <div class="form-group">
        <label>Full Name</label>
        <input type="text" id="svcName" class="filter-select" style="width:100%;" placeholder="e.g. Ravi Kumar">
        <p class="service-error" id="svcNameErr"></p>
      </div>
      <div class="form-group">
        <label>Phone Number</label>
        <input type="tel" id="svcPhone" class="filter-select" style="width:100%;" placeholder="10-digit mobile" maxlength="10">
        <p class="service-error" id="svcPhoneErr"></p>
      </div>
      <div class="form-group">
        <label>Bike Make</label>
        <input type="text" id="svcBikeMake" class="filter-select" style="width:100%;" placeholder="e.g. Honda">
        <p class="service-error" id="svcBikeMakeErr"></p>
      </div>
      <div class="form-group">
        <label>Bike Model</label>
        <input type="text" id="svcBikeModel" class="filter-select" style="width:100%;" placeholder="e.g. Activa 6G">
        <p class="service-error" id="svcBikeModelErr"></p>
      </div>
      <div class="form-group">
        <label>Telegram (optional — for booking updates)</label>
        <input type="text" id="svcTelegram" class="filter-select" style="width:100%;" placeholder="@username or leave blank">
        <p style="font-size:12px;color:var(--text-secondary);margin-top:4px;">If you've messaged our bot before, we'll send updates there. Otherwise we'll use your phone number.</p>
        <p class="service-error" id="svcTelegramErr"></p>
      </div>
      <div class="form-group">
        <label>Service Notes <span style="font-size:12px;font-weight:400;color:var(--text-secondary);">(optional)</span></label>
        <textarea id="svcNotes" class="filter-select" style="width:100%;min-height:90px;resize:vertical;font-family:inherit;font-size:14px;padding:10px 12px;line-height:1.5;" placeholder="Describe the problem, what needs checking or replacing…&#10;e.g. Engine noise, brake pads worn, oil change due, chain loose"></textarea>
      </div>

      <p class="service-error" id="svcDetailsErr"></p>
      <button class="btn-primary btn-large" onclick="svcInitiateBooking()">Pay ₹500 & Confirm Slot</button>
    </div>

    <!-- Step 3: Confirmation -->
    <div class="service-card" id="svcStepConfirm" style="display:none;">
      <div class="service-confirm-icon">✅</div>
      <div class="service-step-title" style="text-align:center;">Booking Confirmed!</div>
      <div class="service-confirm-ref" id="svcConfirmRef"></div>
      <div id="svcConfirmDetails" style="font-size:14px;color:var(--text-secondary);line-height:1.8;margin-bottom:20px;"></div>
      <button class="btn-primary btn-large" onclick="svcShowCancelFlow()">Cancel This Booking</button>
      <button class="btn-secondary btn-large" style="margin-top:10px;" onclick="switchMode('spares')">Back to Spares</button>
    </div>

    <!-- Cancel flow -->
    <div class="service-card" id="svcStepCancel" style="display:none;">
      <button onclick="svcShowStep('svcStepConfirm')" style="background:none;border:none;color:#2196F3;font-size:14px;cursor:pointer;margin-bottom:12px;">← Back</button>
      <div class="service-step-title">❌ Cancel Booking</div>
      <div class="form-group">
        <label>Booking Reference</label>
        <input type="text" id="svcCancelRef" class="filter-select" style="width:100%;" placeholder="SVC-YYYYMMDD-XXXX">
      </div>
      <div class="form-group">
        <label>Phone Number</label>
        <input type="tel" id="svcCancelPhone" class="filter-select" style="width:100%;" placeholder="10-digit mobile" maxlength="10">
      </div>
      <p class="service-error" id="svcCancelErr"></p>
      <p id="svcCancelSuccess" style="color:var(--success);font-size:14px;display:none;margin-bottom:12px;"></p>
      <button class="btn-primary btn-large" onclick="svcCancelBooking()" style="background:var(--danger);">Confirm Cancellation</button>
    </div>
    </div> <!-- /svcTabBookContent -->

    <!-- History tab -->
    <div id="svcTabHistoryContent" style="display:none;">
      <div class="service-card">
        <div class="service-step-title">📋 My Service History</div>
        <div class="form-group">
          <label style="font-size:14px;font-weight:600;">Enter your phone number</label>
          <input type="tel" id="svcHistoryPhone" class="filter-select" style="width:100%;margin-top:6px;"
            placeholder="10-digit mobile" maxlength="10">
          <p class="service-error" id="svcHistoryErr"></p>
        </div>
        <button class="btn-primary" onclick="svcLoadHistory()" style="width:100%;">View My Bookings</button>
      </div>
      <div id="svcHistoryResults"></div>
    </div>
  `;

  // Wire up date picker
  svcEl('svcDatePicker').addEventListener('change', svcOnDateChange);

  // Load availability banner + reviews
  svcLoadAvailability();
  svcLoadReviews();
}

// ─── Step 1: Date change → load slots (Task 9.2) ──────────────────────────────
async function svcOnDateChange() {
  const date = svcEl('svcDatePicker').value;
  if (!date) return;

  svcState.selectedDate = date;
  svcState.selectedSlot = null;

  const container = svcEl('svcSlotContainer');
  const grid = svcEl('svcSlotGrid');
  const nextBtn = svcEl('svcBtnNext1');

  container.style.display = 'none';
  nextBtn.style.display = 'none';
  grid.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">Loading slots…</p>';
  container.style.display = 'block';

  try {
    const res = await fetch(`/api/service/slots?date=${date}`);
    const slots = await res.json();

    if (!res.ok) {
      grid.innerHTML = `<p class="service-error">${slots.error || 'Failed to load slots.'}</p>`;
      return;
    }

    grid.innerHTML = '';
    slots.forEach(({ slot, available }) => {
      const btn = document.createElement('button');
      btn.className = 'slot-btn' + (available ? '' : ' unavailable');
      btn.textContent = svcFmtSlot(slot);
      btn.dataset.slot = slot; // keep raw value for API
      btn.disabled = !available;
      if (available) {
        btn.onclick = () => svcSelectSlot(slot, btn);
      }
      grid.appendChild(btn);
    });
  } catch (e) {
    grid.innerHTML = '<p class="service-error">Network error. Please try again.</p>';
  }
}

function svcSelectSlot(slot, btnEl) {
  svcState.selectedSlot = slot;
  document.querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
  btnEl.classList.add('selected');
  svcEl('svcBtnNext1').style.display = 'block';
  svcSetError('svcSlotError', '');
}

function svcGoToDetails() {
  if (!svcState.selectedSlot) {
    svcSetError('svcSlotError', 'Please select a time slot.');
    return;
  }
  svcShowStep('svcStepDetails');
}

// ─── Step 2: Validate + initiate booking (Task 9.3 + 9.4) ────────────────────
function svcValidateDetails() {
  let valid = true;

  const name = svcEl('svcName').value.trim();
  const phone = svcEl('svcPhone').value.trim();
  const bikeMake = svcEl('svcBikeMake').value.trim();
  const bikeModel = svcEl('svcBikeModel').value.trim();
  const telegram = svcEl('svcTelegram').value.trim();
  const notes = (svcEl('svcNotes')?.value || '').trim();

  svcSetError('svcNameErr', '');
  svcSetError('svcPhoneErr', '');
  svcSetError('svcBikeMakeErr', '');
  svcSetError('svcBikeModelErr', '');
  svcSetError('svcTelegramErr', '');
  svcSetError('svcDetailsErr', '');

  if (!name) { svcSetError('svcNameErr', 'Name is required.'); valid = false; }
  if (!/^[6-9]\d{9}$/.test(phone)) {
    svcSetError('svcPhoneErr', 'Enter a valid 10-digit Indian mobile number.');
    valid = false;
  }
  if (!bikeMake) { svcSetError('svcBikeMakeErr', 'Bike make is required.'); valid = false; }
  if (!bikeModel) { svcSetError('svcBikeModelErr', 'Bike model is required.'); valid = false; }
  if (!telegram || (!telegram.startsWith('@') && !/^\d+$/.test(telegram))) {
    // Telegram is optional — clear error, allow empty
    if (telegram && !telegram.startsWith('@') && !/^\d+$/.test(telegram)) {
      svcSetError('svcTelegramErr', 'Enter a Telegram @username or leave blank.');
      valid = false;
    }
  }

  return valid ? { name, phone, bikeMake, bikeModel, telegram, notes } : null;
}

async function svcInitiateBooking() {
  const fields = svcValidateDetails();
  if (!fields) return;

  svcShowLoading(true);
  try {
    const res = await fetch('/api/service/bookings/initiate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        date: svcState.selectedDate,
        time_slot: svcState.selectedSlot,
        customer_name: fields.name,
        phone: fields.phone,
        bike_make: fields.bikeMake,
        bike_model: fields.bikeModel,
        telegram_contact: fields.telegram,
        customer_notes: fields.notes || '',
      }),
    });
    const data = await res.json();
    svcShowLoading(false);

    if (!res.ok) {
      svcSetError('svcDetailsErr', data.error || 'Failed to initiate booking.');
      return;
    }

    svcState.bookingRef = data.booking_ref;
    svcState.razorpayOrderId = data.razorpay_order_id;
    svcState.razorpayKey = data.razorpay_key;
    svcState.customerNotes = fields.notes || '';

    svcOpenRazorpay(fields);
  } catch (e) {
    svcShowLoading(false);
    svcSetError('svcDetailsErr', 'Network error. Please try again.');
  }
}

// ─── Step 3: Razorpay checkout (Task 9.4) ─────────────────────────────────────
function svcOpenRazorpay(fields) {
  const options = {
    key: svcState.razorpayKey,
    amount: 50000,
    currency: 'INR',
    name: 'Lakshmi Motorcycle Spares',
    description: `Service Booking — ${svcState.selectedDate} ${svcFmtSlot(svcState.selectedSlot)}`,
    order_id: svcState.razorpayOrderId,
    prefill: {
      name: fields.name,
      contact: fields.phone,
    },
    theme: { color: '#FF6700' },
    handler: async function (response) {
      await svcVerifyPayment(response);
    },
    modal: {
      ondismiss: function () {
        svcSetError('svcDetailsErr', 'Payment cancelled. Your slot is still available.');
      },
    },
  };

  const rzp = new Razorpay(options);
  rzp.on('payment.failed', function () {
    svcSetError('svcDetailsErr', 'Payment failed. Please try again.');
  });
  rzp.open();
}

async function svcVerifyPayment(response) {
  svcShowLoading(true);
  try {
    const res = await fetch('/api/service/bookings/verify-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        booking_ref: svcState.bookingRef,
        razorpay_payment_id: response.razorpay_payment_id,
        razorpay_order_id: response.razorpay_order_id,
        razorpay_signature: response.razorpay_signature,
      }),
    });
    const data = await res.json();
    svcShowLoading(false);

    if (!res.ok) {
      svcSetError('svcDetailsErr', data.error || 'Payment verification failed.');
      return;
    }

    svcState.confirmedBooking = data;
    svcShowConfirmation(data);
  } catch (e) {
    svcShowLoading(false);
    svcSetError('svcDetailsErr', 'Network error during verification. Contact support with your booking ref.');
  }
}

// ─── Step 4: Confirmation screen (Task 9.5) ───────────────────────────────────
function svcShowConfirmation(booking) {
  svcEl('svcConfirmRef').textContent = booking.booking_ref;
  const notes = svcState.customerNotes;
  svcEl('svcConfirmDetails').innerHTML = `
    📅 <strong>Date:</strong> ${svcFmtDate(booking.date)}<br>
    ⏰ <strong>Time:</strong> ${svcFmtSlot(booking.time_slot)}<br>
    🏍️ <strong>Bike:</strong> ${booking.bike_make} ${booking.bike_model}<br>
    👤 <strong>Name:</strong> ${booking.customer_name}
    ${notes ? `<br><br>📝 <strong>Your Notes:</strong><br><span style="color:var(--text-secondary);font-size:13px;">${notes.replace(/\n/g,'<br>')}</span>` : ''}
  `;
  const cancelRef = svcEl('svcCancelRef');
  if (cancelRef) cancelRef.value = booking.booking_ref;
  svcShowStep('svcStepConfirm');
}

// ─── Cancel flow (Task 9.6) ───────────────────────────────────────────────────
function svcShowCancelFlow() {
  svcShowStep('svcStepCancel');
  svcSetError('svcCancelErr', '');
  const success = svcEl('svcCancelSuccess');
  if (success) success.style.display = 'none';
}

async function svcCancelBooking() {
  const bookingRef = svcEl('svcCancelRef').value.trim();
  const phone = svcEl('svcCancelPhone').value.trim();

  svcSetError('svcCancelErr', '');
  const success = svcEl('svcCancelSuccess');
  if (success) success.style.display = 'none';

  if (!bookingRef || !phone) {
    svcSetError('svcCancelErr', 'Both booking reference and phone are required.');
    return;
  }
  if (!/^[6-9]\d{9}$/.test(phone)) {
    svcSetError('svcCancelErr', 'Enter a valid 10-digit Indian mobile number.');
    return;
  }

  svcShowLoading(true);
  try {
    const res = await fetch('/api/service/bookings/cancel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ booking_ref: bookingRef, phone }),
    });
    const data = await res.json();
    svcShowLoading(false);

    if (!res.ok) {
      svcSetError('svcCancelErr', data.error || 'Cancellation failed.');
      return;
    }

    if (success) {
      success.textContent = 'Booking cancelled successfully. The slot is now free.';
      success.style.display = 'block';
    }
    svcSetError('svcCancelErr', '');
  } catch (e) {
    svcShowLoading(false);
    svcSetError('svcCancelErr', 'Network error. Please try again.');
  }
}

// ─── Reviews section ──────────────────────────────────────────────────────────
async function svcLoadReviews() {
  const section = svcEl('serviceSection');
  if (!section) return;

  // Append reviews container if not already there
  if (!svcEl('svcReviewsSection')) {
    const div = document.createElement('div');
    div.id = 'svcReviewsSection';
    div.className = 'service-card';
    div.innerHTML = '<div class="service-step-title">⭐ Customer Reviews</div><div id="svcReviewsList"><p style="color:var(--text-secondary);font-size:13px;">Loading reviews…</p></div>';
    section.appendChild(div);
  }

  try {
    const res = await fetch('/api/service/reviews');
    const reviews = await res.json();
    const list = svcEl('svcReviewsList');

    if (!reviews.length) {
      list.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">No reviews yet. Be the first!</p>';
      return;
    }

    list.innerHTML = reviews.map(r => {
      const stars = '⭐'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
      const date = new Date(r.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
      const photo = r.photo_url ? `<img src="${r.photo_url}" style="width:100%;border-radius:10px;margin-top:10px;max-height:200px;object-fit:cover;" alt="Service photo">` : '';
      const reviewText = r.review_text ? `<p style="font-size:14px;color:var(--text-primary);margin:8px 0 0 0;">"${r.review_text}"</p>` : '';
      return `
        <div style="border-bottom:1px solid var(--border-color);padding:14px 0;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
              <span style="font-size:15px;font-weight:700;">${r.customer_name || 'Customer'}</span>
              <span style="font-size:12px;color:var(--text-secondary);margin-left:8px;">${r.bike_make} ${r.bike_model}</span>
            </div>
            <span style="font-size:12px;color:var(--text-secondary);">${date}</span>
          </div>
          <div style="font-size:18px;margin:4px 0;">${stars}</div>
          ${reviewText}
          ${photo}
        </div>`;
    }).join('');
  } catch (e) {
    const list = svcEl('svcReviewsList');
    if (list) list.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">Could not load reviews.</p>';
  }
}

// ─── Live slot availability banner (Round 2) ─────────────────────────────────
async function svcLoadAvailability() {
  const banner = svcEl('svcAvailabilityBanner');
  if (!banner) return;

  try {
    const res = await fetch('/api/service/slots/summary');
    if (!res.ok) return;
    const data = await res.json();

    const todayAvail = data.today_available;
    const todayTotal = data.today_total;
    const nextDate = data.next_available_date;
    const nextSlot = data.next_available_slot;

    let cls, icon, title, sub, pill = '';

    if (todayAvail === 0) {
      cls = 'full';
      icon = '🔴';
      title = 'Fully booked today!';
      sub = 'No slots left for today.';
    } else if (todayAvail <= 2) {
      cls = 'urgent';
      icon = '🔥';
      title = `Only ${todayAvail} slot${todayAvail > 1 ? 's' : ''} left today!`;
      sub = 'Book now before it fills up.';
    } else {
      cls = 'ok';
      icon = '✅';
      title = `${todayAvail} slots available today`;
      sub = 'Pick a convenient time below.';
    }

    if (nextDate && nextSlot) {
      const isToday = nextDate === new Date().toISOString().split('T')[0];
      const isTomorrow = nextDate === new Date(Date.now() + 86400000).toISOString().split('T')[0];
      const label = isToday ? 'Today' : isTomorrow ? 'Tomorrow' : svcFmtDate(nextDate).split(',')[0];
      pill = `<div class="svc-next-slot-pill">Next available: ${label} ${svcFmtSlot(nextSlot)}</div>`;
    }

    banner.innerHTML = `
      <div class="svc-availability-banner ${cls}">
        <div class="svc-banner-icon">${icon}</div>
        <div class="svc-banner-text">
          <strong>${title}</strong>
          <span>${sub}</span>
          ${pill}
        </div>
      </div>`;
  } catch (e) {
    // Silently fail — banner is non-critical
  }
}

// ─── Sub-tab switcher ─────────────────────────────────────────────────────────
function svcSubTab(tab) {
  const bookContent = svcEl('svcTabBookContent');
  const histContent = svcEl('svcTabHistoryContent');
  const btnBook = svcEl('svcTabBook');
  const btnHist = svcEl('svcTabHistory');

  if (tab === 'book') {
    bookContent.style.display = 'block';
    histContent.style.display = 'none';
    btnBook.style.background = 'var(--primary-color)';
    btnBook.style.color = 'white';
    btnHist.style.background = 'white';
    btnHist.style.color = 'var(--text-secondary)';
  } else {
    bookContent.style.display = 'none';
    histContent.style.display = 'block';
    btnHist.style.background = 'var(--primary-color)';
    btnHist.style.color = 'white';
    btnBook.style.background = 'white';
    btnBook.style.color = 'var(--text-secondary)';
  }
}

// ─── Service history loader (Round 3) ────────────────────────────────────────
async function svcLoadHistory() {
  const phone = svcEl('svcHistoryPhone').value.trim();
  svcSetError('svcHistoryErr', '');
  const results = svcEl('svcHistoryResults');

  if (!/^[6-9]\d{9}$/.test(phone)) {
    svcSetError('svcHistoryErr', 'Enter a valid 10-digit Indian mobile number.');
    return;
  }

  results.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;padding:8px 0;">Loading…</p>';

  try {
    const res = await fetch(`/api/service/bookings/history?phone=${phone}`);
    const data = await res.json();

    if (!res.ok) {
      results.innerHTML = `<p class="service-error">${data.error}</p>`;
      return;
    }

    if (!data.length) {
      results.innerHTML = '<div class="service-card" style="text-align:center;color:var(--text-secondary);">No bookings found for this number.</div>';
      return;
    }

    const statusLabel = { confirmed: 'Confirmed', completed: 'Completed', cancelled: 'Cancelled', pending: 'Pending' };

    results.innerHTML = data.map(b => {
      const stars = b.review ? '⭐'.repeat(b.review.rating) : '';
      const reviewHtml = b.review
        ? `<div class="svc-history-review">${stars} ${b.review.review_text ? `"${b.review.review_text}"` : ''}</div>`
        : '';
      return `
        <div class="svc-history-card">
          <div class="svc-history-header">
            <span class="svc-history-ref">${b.booking_ref}</span>
            <span class="svc-history-status ${b.status}">${statusLabel[b.status] || b.status}</span>
          </div>
          <div class="svc-history-detail">
            📅 ${svcFmtDate(b.date)} &nbsp;⏰ ${svcFmtSlot(b.time_slot)}<br>
            🏍️ ${b.bike_make} ${b.bike_model}
          </div>
          ${reviewHtml}
        </div>`;
    }).join('');
  } catch (e) {
    results.innerHTML = '<p class="service-error">Network error. Please try again.</p>';
  }
}
